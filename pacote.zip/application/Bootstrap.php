<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    /**
     * Database init
     */
    protected function _initDbRegistry()
    {
        Zend_Registry::set('multidb', $this->getPluginResource('multidb'));
    }

    /**
     * Session init
     */
    protected function _initSession()
    {
        // $configIni = new Zend_Config_Ini(APPLICATION_PATH . '/configs/session.ini', APPLICATION_ENV);
        // Zend_Session::setOptions($configIni->toArray());

        // if (!isset($_SESSION)) {
        //     Zend_Session::start();
        // }
    }

    /**
     * Locale init
     */
    protected function _initLocale()
    {
        $locale = new Zend_Locale('pt_BR');
        Zend_Registry::set('Zend_Locale', $locale);
    }

    /**
     * ACL init
     */
    protected function _initAcl()
    {

        // $identity = Zend_Auth::getInstance()->getIdentity();
        // echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
        // print_r($identity);
        // echo "<br> ====================================== <br>";

        // Cria o objeto ACL
        $acl = new Zend_Acl();

        // Determina os papéis/perfis/roles
        $acl->addRole('usuario')
            // perfis usados no admin
            // ->addRole('usuario-comum',             array('usuario'))
            // ->addRole('usuario-agenda-comum',      array('usuario'))
            // ->addRole('usuario-agenda-particular', array('usuario'))
            // ->addRole('usuario-agenda-avancado',   array('usuario'))
            // ->addRole('editor',                    array('usuario'))
            // ->addRole('usuario-avancado',          array('usuario'))
            ->addRole('participante',              array('usuario'))
            ->addRole('administrador',             array('participante'))
            ->addRole('master',                    array('administrador'))

            // perfis usados no site
            ->addRole('site-usuario-comum',        array('usuario'))
            ->addRole('site-mantenedor',           array('usuario'));

        /*****************************************************************************************/
        /************************************* MÓDULO ADMIN **************************************/
        /*****************************************************************************************/


        $acl->addResource('admin-index');
        $acl->allow('usuario', 'admin-index', array('index',
                                                    'login',
                                                    'logout',
                                                    'acesso',
                                                    'sessao-expirada',
                                                    'home'));


        // Seta a ACL na registry
        Zend_Registry::set('acl', $acl);
    }
}
