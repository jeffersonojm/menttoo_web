<?php
class Site_CoachingController extends Base_Controller_Site
{
    public function finalizarAction(){
    }   


    public function solicitarAction(){
    	
    	$params = $this->_request->getParams();

        $mLogin = new Application_Model_DbTable_Base_Login();
        $rLogin = $mLogin->getUsuario($params);
        $this->view->usuario = $rLogin;

        $mCoaching  = new Application_Model_DbTable_Base_Coaching();
        $rSolicitacao = $mCoaching->getMySolicitacao( $params['id'] );
		
		$this->view->exist_solicitacao = $rSolicitacao->count();
		
		// echo $this->view->exist_solicitacao;
  //       echo "<pre>";
  //       print_r( $rSolicitacao );
  //       exit();

    }   


    public function solicitarSalvarAction(){
    	
        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();

		        if( Zend_Auth::getInstance()->hasIdentity() ) {  
		            $dados = Zend_Auth::getInstance()->hasIdentity();
		            $identity   = Zend_Auth::getInstance()->getIdentity();
		            $post['coachee_id']     = $identity->lgn_id;
		        }

                $mLogin = new Application_Model_DbTable_Base_Login();
                $rLogin = $mLogin->find($post["coach_id"])->current();
                $data_hoje = date("Y-m-d");
                $data_termino = date('Y-m-d', strtotime("+".$rLogin->lgn_duracao_media." month", strtotime( $data_hoje )));
                
                // echo $data_hoje;
                // echo " - ";
                $post["data_termino"] = $data_termino;


		        // echo "<pre>";
		        // print_r( $post );
		        // exit();

                $mCoaching  = new Application_Model_DbTable_Base_Coaching();
                $coaching_id = $mCoaching->salvar($post);

                $avatar = 'http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/avatar.png';
                if ( isset( $rLogin->lgn_avatar ) && $rLogin->lgn_avatar != "" && file_exists('portal/uploads/usuario/avatar/'.$rLogin->lgn_avatar ) ):
                    $avatar = 'http://'.$_SERVER['HTTP_HOST'].'/portal/uploads/usuario/avatar/' . $rLogin->lgn_avatar;
                endif;


                $html = '
                    <table border="0" cellspacing="" cellspacing="" width="680" bgcolor="#2A2B1D" background="img_bg.jpg" align="center">
                        <tr>
                            <td align="center">
                                <a href="" style="outline:none; margin: 40px 0 50px 0; display:inline-block;">
                                    <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/logo_bc.png">
                                </a>
                            </td>
                        </tr>

                        <tr>
                            <td align="center" style="font-family:Arial; font-weight: 700; font-size: 50px; text-transform: uppercase; color: #fdda6f;">
                                parabéns
                            </td>
                        </tr>

                        <tr>
                            <td align="center" style="font-family:Arial; font-weight: 100; font-size: 26px; text-transform: uppercase; color: #fdda6f; line-height: 26px;">
                                Você RECEBEU UMA SOLICITAÇÃO PARA INICIAR O processo de coaching DE:
                            </td>
                        </tr>

                        <tr>
                            <td align="center">
                                <div style="width:150px;height:150px; overflow: hidden; border-radius: 50%;margin: 35px auto 10px auto;border: 4px solid #fdda6f;"><img src="'.$avatar.'" style="margin: 0; width: 100%;"></div>
                            </td>
                        </tr>

                        <tr>
                            <td align="center" style="font-family:Arial; font-weight: 700; font-size: 40px; color: #fdda6f; line-height: 40px;">
                                '.$identity->lgn_nome.'
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <div style="width: 90%; margin: 20px 5% 60px 5%;">
                                    <table border="0" cellspacing="" cellspacing="" width="100%">
                                        <tr>
                                            <td align="center" style="padding: 15px 0; ">
                                                <a href="http://'.$_SERVER['HTTP_HOST'].'/usuario/avaliar-coachee/id/'.$coaching_id.'" style="display: inline-block; width: 100%; height: 60px; text-align: center; background-color: #FCD96F; border-radius: 4px; text-decoration: none; font-size: 22px; font-family:Arial; font-weight: 600; color: #2B2B1D; line-height: 60px;">VER A SOLICITAÇÃO</a>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </td>                       
                        </tr>

                        <tr>
                            <td bgcolor="#222538">
                                <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                    <tr>
                                        <td style="text-align: center; font-size: 18px; font-family:Arial; font-weight: 100; color: #2961FD; padding: 10px 0 0 0;">www.menttoo.com</td>
                                    </tr>
                                    <tr>
                                        <td align="center" style="text-align: center;">
                                            <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                                <tr>
                                                    <td align="center">
                                                        <a href="https://www.linkedin.com/company-beta/3589739/" style="outline:none; margin: 0 10px; display:inline-block;">
                                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_linkedin_az.png" style="">
                                                        </a>
                                                    </td>

                                                    <td align="center">
                                                        <a href="https://www.facebook.com/menttoo/?fref=ts" style="outline:none; margin: 0 5px; display:inline-block; border-left: 1px solid #275BE5; border-right: 1px solid #275BE5; padding:0 14px;">
                                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_facebook_az.png" style="">
                                                        </a>
                                                    </td>
                                                    <td align="center">
                                                        <a href="https://www.youtube.com/channel/UCY6ynwaxdfSC7e8SCTP4UTQ" style="outline:none; margin: 0 5px; display:inline-block;">
                                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_youtube_az.png" style="">
                                                        </a>
                                                    </td>
                                                </td>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                ';


                Base_Mail::mail(
                    $rLogin->lgn_email,
                    'menttoo::Solicitação de coaching',
                    $html,
                    'menttoo', 
                    'contato@inmais.com.br'
                );  

                $dados_notificaca = array(
                        "lgn_id"=>$post['coach_id'],
                        "coaching_id"=>$coaching_id,
                        "titulo"=>"Solicitação de coaching",
                        "texto"=>"Que tal começar agora?",
                        "tipo"=>4
                    );


                $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
                $rNotificacoes = $mNotificacoes->salvar($dados_notificaca);                


                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Solicitação enviada com sucesso.'));
                $this->redirect('coaching', 'solicitar', 'site', array('id' => $post["coach_id"] ));

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('coaching', 'solicitar', 'site', array('id' => $post["coach_id"] ));
            } else {
                $this->redirect('coaching', 'solicitar', 'site', array('id' => $post["coach_id"] ));
            }

        }

    }   

}



