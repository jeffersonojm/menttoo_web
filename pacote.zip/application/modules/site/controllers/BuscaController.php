<?php
class Site_BuscaController extends Base_Controller_Site
{
    public function indexAction(){
        // $this->_helper->layout()->disableLayout();
        // if (Zend_Auth::getInstance()->getIdentity() != null) {
        //     $this->redirect('index', 'home', 'site');
        // }


        $_SESSION["busca"] = array();
    }

    public function etapa2Action(){
        if ($this->_request->isPost()) {
            $post = $this->_request->getPost();
            $this->view->post = $post;
        }        


        // $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Solicitação enviada com sucesso.'));
        // $this->redirect('coaching', 'solicitar', 'site', array('id' => $post["coach_id"] ));        
    }    

    public function etapa3Action(){
        if ($this->_request->isPost()) {
            $post = $this->_request->getPost();
            $this->view->post = $post;
        }        

        // $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Solicitação enviada com sucesso.'));
        // $this->redirect('coaching', 'solicitar', 'site', array('id' => $post["coach_id"] ));        
    }    


    // public function pessoalEtapa3Action(){
    // }        

    // public function profissionalEtapa3Action(){
    // }            

    public function etapa4Action(){
        if ($this->_request->isPost()) {
            $post = $this->_request->getPost();
            $this->view->post = $post;



           // if( isset($post["uf"]) and $post["uf"] ){
            //     $mLogin = new Application_Model_DbTable_Base_Login();
            //     $rLogin = $mLogin->getBuscaCount($post);                

            //     if( !$rLogin->count() ){
            //         // $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Solicitação enviada com sucesso.'));
            //         $this->redirect('busca', 'etapa4-vazio', 'site', $post);      
            //     }



                echo "<pre>";
                // print_r($post);
                print_r($this->view->estados);
                exit();                
            // }

        }              
            $mEstado = new Application_Model_DbTable_Base_Estado();
            $this->view->estados = $mEstado->combo();

            unset( $this->view->estados[0] );


            // echo "<pre>";
            // // print_r($post);
            // print_r($this->view->estados);
            // exit();    

        // if( isset( $_SESSION["busca"]["processo_coaching"] ) and $_SESSION["busca"]["processo_coaching"] == "on" ){
        //     echo "string";
        // }

        
    }    

    public function etapa5Action(){
        if ($this->_request->isPost()) {
            $post = $this->_request->getPost();
            $this->view->post = $post;
        }   


        // Fluxo online
        if( $_SESSION["busca"]["processo_coaching"] == "on" or $_SESSION["busca"]["processo_coaching"] == "ambos" ){
            $this->redirect('busca', 'resultado', 'site');        
        }else{ // Fluxo presencial

            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->getBuscaResultados( $_SESSION["busca"] );
            $this->view->resultados = $rLogin;            

            if( !$rLogin->count() ){
                // echo "01";
                $this->redirect('busca', 'etapa-online', 'site');        
            }else{
                // echo "02";
                $this->redirect('busca', 'resultado', 'site', array('id' => $post["coach_id"] ));        
            }            
        }

        exit();


        // $mLogin = new Application_Model_DbTable_Base_Login();
        // $rLogin = $mLogin->getBuscaCount( $_SESSION["busca"] );                
        // $this->view->resultados = $rLogin;

        // // echo "<pre>";
        // // print_r( $_SESSION["busca"] );

        // if( !$rLogin->count() ){
        //     // unset( $_SESSION["busca"]["uf"] );
        //     // $_SESSION["busca"]["processo_coaching"] = "on";
        //     $this->redirect('busca', 'etapa-online', 'site');        
        // }else{
        //     $this->redirect('busca', 'resultado', 'site', array('id' => $post["coach_id"] ));        
        // }

    }  

    public function etapaOnlineAction(){
        $this->view->uf = $_SESSION["busca"]["uf"];
        // unset( $_SESSION["busca"]["uf"] );
        // $_SESSION["busca"]["processo_coaching"] = "on";        
        $mLogin = new Application_Model_DbTable_Base_Login();
        $rLogin = $mLogin->getBuscaCount( $_SESSION["busca"] );                
        $this->view->resultados = $rLogin;  

        $_SESSION["busca"]["ideal"] = 0;

    }

    public function etapa4VazioAction(){
        $params = $this->_request->getParams();
        $this->view->post = $params;
    }    

    public function resultadoAction(){
        if ($this->_request->isPost()) {
            $post = $this->_request->getPost();
            $this->view->post = $post;
        }         

        // echo "<pre>";
        // print_r($_SESSION["busca"]);
        // exit();


        // Fluxo online
        if( isset($_SESSION["busca"]["processo_coaching"]) and $_SESSION["busca"]["processo_coaching"] == "on" ){
            
            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->getBuscaResultados( $_SESSION["busca"] );
            $this->view->resultados = $rLogin;

            $processo = $_SESSION["busca"]["processo_coaching"];
            $tipo_coach = $_SESSION["busca"]["tipo_coach"];

            $rLogin = $mLogin->getBuscaResultadosSimilar( array( "processo_coaching"=>$processo, "tipo_coach"=>$tipo_coach ) );
            $this->view->resultados_similares = $rLogin;

        // Fluxo online
        }else if( isset($_SESSION["busca"]["processo_coaching"]) and $_SESSION["busca"]["processo_coaching"] == "ambos" ){
            
            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->getBuscaResultados( $_SESSION["busca"] );
            $this->view->resultados = $rLogin;

            $tipo_coach = $_SESSION["busca"]["tipo_coach"];

            $rLogin = $mLogin->getBuscaResultadosSimilar( array( "tipo_coach"=>$tipo_coach ) );
            $this->view->resultados_similares = $rLogin;
        }else{

            if( isset( $_SESSION["busca"]["nome"]) ){ // busca por nome
                $mLogin = new Application_Model_DbTable_Base_Login();
                $rLogin = $mLogin->getBuscaResultados( $_SESSION["busca"] );
                $this->view->resultados_nome = $rLogin;
            }else{
                $mLogin = new Application_Model_DbTable_Base_Login();
                $rLogin = $mLogin->getBuscaResultados( $_SESSION["busca"] );
                $this->view->resultados = $rLogin;

                $processo = $_SESSION["busca"]["processo_coaching"];
                $tipo_coach = $_SESSION["busca"]["tipo_coach"];

                if ( isset($_SESSION["busca"]["ideal"]) ) {
                    $processo = "on";
                }

                $rLogin = $mLogin->getBuscaResultadosSimilar( array( "processo_coaching"=>$processo, "tipo_coach"=>$tipo_coach ) );
                $this->view->resultados_similares = $rLogin;            
            }
        }




        // if ( isset($_SESSION["busca"]["ideal"]) ) { // Busca não ideial

        //     $mLogin = new Application_Model_DbTable_Base_Login();
        //     $rLogin = $mLogin->getBuscaCount( $_SESSION["busca"] );                
        //     $this->view->resultados_similares = $rLogin;

        // }else{  // Busca ideial com similares
        //     $mLogin = new Application_Model_DbTable_Base_Login();
        //     $rLogin = $mLogin->getBuscaCount( $_SESSION["busca"] );                
        //     $this->view->resultados = $rLogin;


        //     if( isset( $_SESSION["busca"]["segmento"] ) ){
        //         $rLogin = $mLogin->getBuscaCountSimilar( $_SESSION["busca"] );                
        //         $this->view->resultados_similares = $rLogin;
        //     }

        // }




        // echo "string";
        // exit();
     
    }  

    public function resultadoNegativoAction(){
    }  


    public function setarOpcoesAction(){

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

        $params = $this->_request->getParams();

        if ( isset( $params["etapa1"] ) and $params["etapa1"] ) {
            $_SESSION["busca"]["processo_coaching"] = $params["etapa1"];  
        }

        if ( isset( $params["etapa2"] ) and $params["etapa2"] ) {
            $_SESSION["busca"]["tipo_coach"] = $params["etapa2"];  
        }

        if ( isset( $params["etapa3"] ) and $params["etapa3"] ) {
            $_SESSION["busca"]["segmento"] = $params["etapa3"];  
        }

        if ( isset( $params["etapa4"] ) and $params["etapa4"] ) {
            $_SESSION["busca"]["uf"] = $params["etapa4"];  
        }

        if ( isset( $params["etapa5"] ) and $params["etapa5"] ) {
            $_SESSION["busca"]["preco"] = $params["etapa5"];  
        }                        


        if ( isset( $params["nome"] ) and $params["nome"] ) {
            if ( isset($_SESSION["busca"]["processo_coaching"]) ) { unset($_SESSION["busca"]["processo_coaching"]); }
            if ( isset($_SESSION["busca"]["tipo_coach"]) ) { unset($_SESSION["busca"]["tipo_coach"]); }
            if ( isset($_SESSION["busca"]["segmento"]) ) { unset($_SESSION["busca"]["segmento"]); }
            if ( isset($_SESSION["busca"]["uf"]) ) { unset($_SESSION["busca"]["uf"]); }
            if ( isset($_SESSION["busca"]["preco"]) ) { unset($_SESSION["busca"]["preco"]); }

            $_SESSION["busca"]["nome"] = $params["nome"];  
        }    

        // print_r($_SESSION["busca"]);

    }

}



