<?php

class Site_NotificacoesController extends Base_Controller_Site
{
    public function indexAction()
    {

        $params = $this->_request->getParams();

        $identity   = Zend_Auth::getInstance()->getIdentity();
       
        $idLogin     = $identity->lgn_id;

        $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();

        // Atuais
        $rNotificacoes = $mNotificacoes->getList( array("lgn_id"=>$idLogin, "status"=>0 ) );
        $this->view->notificacoes = $rNotificacoes;


        // Antigas
        $rNotificacoesAntigas = $mNotificacoes->getList( array("lgn_id"=>$idLogin, "status"=>1 ) );
        $this->view->notificacoes_antigas = $rNotificacoesAntigas;


    }


    public function detalheAction()
    {


        $params = $this->_request->getParams();

        //SOLICITAÇÃO
        $mEspecialidades  = new Application_Model_DbTable_Base_SolicitarCoaching();
        $rEspecialidades = $mEspecialidades->find( $params["id"] )->current();;
        $dados = $this->view->solicitacao = $rEspecialidades;



        $id_coach = $this->view->solicitacao->id_coach;//ID DO COACH
        //DADOS DO COACH        
        $mCoach  = new Application_Model_DbTable_Base_Login();
        $rCoach  = $mCoach ->find( $id_coach )->current();
        $this->view->coach  = $rCoach ;

        $id_coachee = $this->view->solicitacao->lgn_id;//ID DO COACHEE
        //DADOS DO COACHEE     
        $mCoachee  = new Application_Model_DbTable_Base_Login();
        $rCoachee  = $mCoachee ->find( $id_coachee )->current();
        $this->view->coachee  = $rCoachee ;
        
    }

    public function coachContatoAction()
    {

        $params = $this->_request->getParams();


        if (isset($params["id"]) ) {
            $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
            $rNotificacoes = $mNotificacoes->find( $params["id"] )->current();
            $rNotificacoes->status = 1;
            $rNotificacoes->save();
        }

        $mCoaching  = new Application_Model_DbTable_Base_Coaching();
        $rCoaching = $mCoaching->getMyCoachees( array("id"=>$params["coaching_id"] ) )->current();
        $this->view->coaching = $rCoaching;

        $identity   = Zend_Auth::getInstance()->getIdentity();

        // echo "<pre>";
        // print_r($identity);
        // exit();

        $idLogin    = $identity->lgn_id;
        
        $mCoach  = new Application_Model_DbTable_Base_Login();
        if( $rCoaching->coach_id == $idLogin){
            //DADOS DO COACHEE
            $rCoach  = $mCoach ->find( $rCoaching->coachee_id )->current();
            $this->view->usuario  = $rCoach ;
        }else{
            //DADOS DO COACH             
            $mCoachee  = new Application_Model_DbTable_Base_Login();
            $rCoachee  = $mCoachee ->find(  $rCoaching->coach_id )->current();
            $this->view->usuario  = $rCoachee ;
        }

        // echo "<pre>";
        // print_r( $this->view->usuario );
        // exit();
        
    }

    public function coachDadosAction()
    {

        $params = $this->_request->getParams();

        if ( isset($params["id"]) ) {
            $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
            $rNotificacoes = $mNotificacoes->find( $params["id"] )->current();
            $rNotificacoes->status = 1;
            $rNotificacoes->save();            
        }

        
        $mCoaching  = new Application_Model_DbTable_Base_Coaching();
        $rCoaching = $mCoaching->getMyCoachees( array("id"=>$params["coaching_id"] ) )->current();
        $this->view->coaching = $rCoaching;
        $this->view->params = $params;

        // echo "<pre>";
        // // print_r( $this->view->usuario );
        // print_r( $params );
        // exit();

        $identity   = Zend_Auth::getInstance()->getIdentity();
        $idLogin    = $identity->lgn_id;
        
        $mCoach  = new Application_Model_DbTable_Base_Login();
        if( $rCoaching->coach_id == $idLogin){
            //DADOS DO COACHEE
            $rCoach  = $mCoach->find( $rCoaching->coachee_id )->current();
            $this->view->usuario  = $rCoach ;
        }else{
            //DADOS DO COACH             
            $mCoachee  = new Application_Model_DbTable_Base_Login();
            $rCoachee  = $mCoach->find(  $rCoaching->coach_id )->current();
            $this->view->usuario  = $rCoachee ;
        }

        // echo "<pre>";
        // // print_r( $this->view->usuario );
        // print_r( $rCoaching );
        // exit();
        
    }

    public function coachFinishAction()
    {

        $params = $this->_request->getParams();
        
        $mEspecialidades  = new Application_Model_DbTable_Base_SolicitarCoaching();
        $rEspecialidades = $mEspecialidades->readOne($params["id"]);
        $dados = $this->view->solicitacao = $rEspecialidades;


        //SELECIONA O COACH
        $id_coach = '';

        foreach ($dados as $key => $value){

            $id_coach = $value->id_coach;

            $this->view->id_solicitacao = $value->id;

        }

        //DADOS DO USUÁRIO        
        $mLogin  = new Application_Model_DbTable_Base_Login();
        $rUsuario = $mLogin->find( $id_coach )->current();
        $this->view->usuario = $rUsuario;
        
    }


    public function coachFinishSalvarAction()
    {

        try {

            $params = $this->_request->getParams();
            
            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();

                //SALVA MENSAGEM
                $mSolicitacao = new Application_Model_DbTable_Base_SolicitarCoaching();
                $mSolicitacao->salvar($post);
                
            }
            
            $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Enviado com sucesso.'));
            $this->redirect('notificacoes', 'coach-avaliacao', 'site', array('id' => $post["id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('notificacoes', 'coach-avaliacao', 'site', array('id' => $post["id"] ));
        }

    }



    public function coachAvaliacaoAction()
    {

        $params = $this->_request->getParams();
        
        $mEspecialidades  = new Application_Model_DbTable_Base_SolicitarCoaching();
        $rEspecialidades = $mEspecialidades->readOne($params["id"]);
        $dados = $this->view->solicitacao = $rEspecialidades;


        $id_coach = $lgn_id = '';;

        foreach ($dados as $key => $value){

            $this->view->id_coach = $value->id_coach;

            $this->view->lgn_id = $value->lgn_id;

            $this->view->id_solicitacao = $value->id;

        }




        //DADOS DO USUÁRIO        
        $mLogin  = new Application_Model_DbTable_Base_Login();
        $rUsuario = $mLogin->find( $id_coach )->current();
        $this->view->usuario = $rUsuario;
        
    }



    public function coachAvaliacaoSalvarAction()
    {

        try {

            $params = $this->_request->getParams();
            
            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();

                //SALVA MENSAGEM
                $mAvaliacao = new Application_Model_DbTable_Base_AvaliacaoSistema();
                $mAvaliacao->salvar($post);
                
            }
            
            $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Enviado com sucesso.'));
            $this->redirect('coach', 'coaching-convites', 'site');//, array('id' => $post["id"] )

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('coach', 'coaching-convites', 'site');//, array('id' => $post["id"] )
        }
        
    }

    public function coachEncerraSalvarAction()
    {

        try {

            $params = $this->_request->getParams();

            $params['encerrado'] = '1';

            $mSolicitacao = new Application_Model_DbTable_Base_SolicitarCoaching();
            $mSolicitacao->salvar($params);
            
            $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Enviado com sucesso.'));
            $this->redirect('notificacoes', 'coach-dados', 'site', array('id' => $params["id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('notificacoes', 'coach-dados', 'site', array('id' => $params["id"] ));
        }
        
    }






    public function coachExtenderSalvarAction()
    {

        try {

            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();


                $data_extender = $post['data_termino'];
                $data_extender = explode("/", $data_extender);
                $post['data_termino'] = $data_extender[2].'-'.$data_extender[1].'-'.$data_extender[0];

                // echo "<pre>";
                // print_r($post);
                // exit();

                $mSolicitacao = new Application_Model_DbTable_Base_Coaching();
                $mSolicitacao->salvar($post);

                if ( isset($params["notif_id"]) ) {
                    $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
                    $rNotificacoes = $mNotificacoes->find( $params["notif_id"] )->current();
                    $rNotificacoes->status = 1;
                    $rNotificacoes->save();
                }
                
            }
            
            $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Enviado com sucesso.'));
            $this->redirect('notificacoes', 'coach-dados', 'site', array('coaching_id' => $post["id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('notificacoes', 'coach-dados', 'site', array('coaching_id' => $post["id"] ));
        }
        
    }



    

    public function mensagemAction()
    {

        $params = $this->_request->getParams();

        //SOLICITAÇÃO
        $mMensagens  = new Application_Model_DbTable_Base_Mensagens();
        $rMensagens = $mMensagens->find( $params["id"] )->current();;
        $this->view->mensagens = $rMensagens;

        if( !empty($this->view->mensagens->coach_id) ){

            $id_coach = $this->view->mensagens->coach_id;//ID DO COACH
            //DADOS DO COACH        
            $mCoach  = new Application_Model_DbTable_Base_Login();
            $rCoach  = $mCoach ->find( $id_coach )->current();
            $this->view->coach  = $rCoach ;

        }

        $id_coachee = $this->view->mensagens->user_id;//ID DO COACHEE
        //DADOS DO COACHEE     
        $mCoachee  = new Application_Model_DbTable_Base_Login();
        $rCoachee  = $mCoachee ->find( $id_coachee )->current();
        $this->view->coachee  = $rCoachee ;

        
    }  



     public function mensagemSalvarAction()
     {


        try {

            if ($this->_request->isPost()) {
                
                $post = $this->_request->getPost();

                $post['data_resposta'] = date("Y-m-d H:i:s");

                
                $mMensagens = new Application_Model_DbTable_Base_Mensagens();
                $mMensagens->salvar($post);
                
            }
            
            $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Enviado com sucesso.'));
            $this->redirect('notificacoes', 'mensagem', 'site', array('id' => $post["id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('notificacoes', 'mensagem', 'site', array('id' => $post["id"] ));
        }

        exit();
     }



    public function atualizarAction()
    {

        // $params = $this->_request->getParams();
        $identity   = Zend_Auth::getInstance()->getIdentity();
        $idLogin    = $identity->lgn_id;
        

        $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
        $rNotificacoes  = $mNotificacoes->getCount( array( "lgn_id"=> $idLogin, "status"=>0 ) )->current();

        echo $rNotificacoes->quantidade;
        exit();
        
    }

}


