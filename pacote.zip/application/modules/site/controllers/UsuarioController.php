<?php
class Site_UsuarioController extends Base_Controller_Site
{

    
    // 
    public function cadastroCoachConviteAction(){
        
        $params = $this->_request->getParams();

        $mSegmentoTipoCoach = new Application_Model_DbTable_Base_SegmentoTipoCoach();
        $rSegmentoLifeCoach = $mSegmentoTipoCoach->pesquisar(array("tipo_coach"=>1));
        $rSegmentoExecutive = $mSegmentoTipoCoach->pesquisar(array("tipo_coach"=>2));            

        $this->view->seg_life = $rSegmentoLifeCoach;
        $this->view->seg_executive = $rSegmentoExecutive;
        // echo "<pre>";
        // print_r($rSegmentoExecutive);
        // exit();

        $mEstado = new Application_Model_DbTable_Base_Estado();
        $this->view->estados = $mEstado->combo();

        if (isset($params['id'])) {
            
            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->getUsuario($params);
            $this->view->usuario = $rLogin;
            // $rLogin['segmentos']
            // echo "<pre>";
            // print_r($rLogin);
            // exit();
        }        
    }




    public function cadastroCoachConviteSalvarAction(){
        try {
            if ($this->_request->isPost()) {

                
                $post = $this->_request->getPost();




                $files      = new Zend_File_Transfer_Adapter_Http();
                $filesInfo  = $files->getFileInfo();
                // echo "<pre>";
                // print_r($filesInfo);
                // exit();
     



                // =============== Salva os dados pessoais
                $arrDadosPessoais = array();

                if (isset($post['id']) && $post['id']) {
                    $arrDadosPessoais['id'] = $post['id'];
                    $idLogin = $post['id'];
                }
                
                // if ( $_SESSION["SOU"]=='coach'  ) {
                    $arrDadosPessoais['perfil'] = 2;
                // }else if(  $_SESSION["SOU"]=='coachee' ){
                //     $arrDadosPessoais['perfil'] = 3;
                // }
                $arrDadosPessoais['nome']       = $post['nome'];
                $arrDadosPessoais['email']      = $post['email'];
                $arrDadosPessoais['ddd']        = $post['ddd'];
                $arrDadosPessoais['telefone']   = $post['telefone'];
                $arrDadosPessoais['nascimento'] = $post['nascimento'];
                $arrDadosPessoais['uf']         = strtoupper($post['uf']);
                $arrDadosPessoais['cidade']     = ucfirst( strtolower($post['cidade']) );

                $mLogin        = new Application_Model_DbTable_Base_Login();
                $idLogin       = $mLogin->salvar($arrDadosPessoais);

                // echo "<pre>";
                // print_r( $arrDadosPessoais );
                // exit();


                // =============== Salva os dados do diploma

                $mDiploma        = new Application_Model_DbTable_Base_Diploma();
                $arrDadosDiploma = array();


                $uploadPathDiploma = PUBLIC_PATH . '/portal/uploads/usuario/diploma/';
                if (!file_exists($uploadPathDiploma)) {
                    if (!mkdir($uploadPathDiploma, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPathDiploma, 0777);
                }

                $count_diploma = 0;
                foreach ($filesInfo as $fieldname => $fileinfo) {
                    
                    // Arquivos diploma
                    if( substr($fieldname, 0,12) == 'diploma_file' and $fileinfo['name'] ){

                        $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                        $nomeArquivo          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                        $filePath                    = $uploadPathDiploma . $nomeArquivo;
                        $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                        $files->receive($fileinfo['name']);
                        chmod($filePath, 0777);


                        $arrDadosDiploma['user_id'] = $idLogin;
                        $arrDadosDiploma['arquivo'] = $nomeArquivo;

                        if( !empty( $post['diploma_data'][$count_diploma] ) and strlen($post['diploma_data'][$count_diploma] ) == 10 ){
                            $data = explode("/", $post['diploma_data'][$count_diploma] );
                            $data = $data[2].'-'.$data[1].'-'.$data[0];
                        }

                        $arrDadosDiploma['data_encerramento'] = $data;
                        $arrDadosDiploma['nome_escola'] = $post['diploma_nome_escola'][$count_diploma];
                        $idDiploma       = $mDiploma->salvar($arrDadosDiploma);

                        $count_diploma++;                        
                        
                    }
                    // fim - Arquivos diploma
                }
      


                // =============== Salva os segmentos
                if( isset($post["segmento_item"]) and count($post["segmento_item"]) ){
                    $mSegmentoLogin       = new Application_Model_DbTable_Base_SegmentoLogin();
                    $arrDadosSemento = array();
                    foreach ($post["segmento_item"] as $dado) {
                        $item = explode("-", $dado);
                        $arrDadosSemento['user_id']       = $idLogin;
                        $arrDadosSemento['tipo_id']       = $item[0];
                        $arrDadosSemento['segmento_id']   = $item[1];
                        $idSegmentoLogin       = $mSegmentoLogin->salvar($arrDadosSemento);
                    }
                }


                // =============== Subir credencial
                $mCredencial        = new Application_Model_DbTable_Base_Credencial();
                $arrDadosCredencial = array();

                $uploadPathCredencial = PUBLIC_PATH . '/portal/uploads/usuario/credencial/';
                if (!file_exists($uploadPathCredencial)) {
                    if (!mkdir($uploadPathCredencial, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPathCredencial, 0777);
                }

                $count_credencial = 0;
                foreach ($filesInfo as $fieldname => $fileinfo) {

                    // Arquivos credencial
                    if( substr($fieldname, 0,15) == 'credencial_file' and $fileinfo['name'] ){

                        $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                        $nomeArquivo          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                        $filePath             = $uploadPathCredencial . $nomeArquivo;

                        $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                        $files->receive($fileinfo['name']);
                        chmod($filePath, 0777);


                        $arrDadosCredencial['user_id'] = $idLogin;
                        $arrDadosCredencial['arquivo'] = $nomeArquivo;


                        if( !empty( $post['credencial_data'][$count_credencial] ) and strlen( $post['credencial_data'][$count_credencial] ) == 10 ){
                            $data = explode("/", $post['credencial_data'][$count_credencial] );
                            $data = $data[2].'-'.$data[1].'-'.$data[0];
                        }

                        $arrDadosCredencial['data_validade'] = $data;
                        $arrDadosCredencial['titulo'] = $post['credencial_titulo'][$count_credencial];
                        $idCredencial       = $mCredencial->salvar($arrDadosCredencial);

                        $count_credencial++;                        
                        
                    }
                    // fim - Arquivos credencial

                }
      



                // =============== Subir comprovante
                $mComprovante        = new Application_Model_DbTable_Base_Comprovante();
                $arrDadosComprovante = array();

                $uploadPathComprovante = PUBLIC_PATH . '/portal/uploads/usuario/comprovante/';
                if (!file_exists($uploadPathComprovante)) {
                    if (!mkdir($uploadPathComprovante, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPathComprovante, 0777);
                }

                $count_comprovante = 0;
                foreach ($filesInfo as $fieldname => $fileinfo) {

                    // Arquivos comprovante
                    if( substr($fieldname, 0,16) == 'comprovante_file' and $fileinfo['name'] ){

                        $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                        $nomeArquivo          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                        $filePath             = $uploadPathComprovante . $nomeArquivo;

                        $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                        $files->receive($fileinfo['name']);
                        chmod($filePath, 0777);


                        $arrDadosComprovante['user_id'] = $idLogin;
                        $arrDadosComprovante['arquivo'] = $nomeArquivo;
                        $arrDadosComprovante['horas'] = $post['comprovante_hora'][$count_comprovante];
                        $idComprovante       = $mComprovante->salvar($arrDadosComprovante);

                        $count_comprovante++;                        
                        
                    }
                    // fim - Arquivos comprovante

                }


                // =============== Salva clientes
                if( isset($post["cliente_nome"]) and count($post["cliente_nome"]) ){
                    $mClienteIndicado       = new Application_Model_DbTable_Base_ClienteIndicado();
                    $arrDadosCliente = array();

                    foreach ($post["cliente_nome"] as $key => $dado) {
                   
                        $arrDadosCliente['user_id']   = $idLogin;
                        $arrDadosCliente['nome']      = $post["cliente_nome"][$key];
                        $arrDadosCliente['email']     = $post["cliente_email"][$key];
                        $arrDadosCliente['ddd']       = $post["cliente_ddd"][$key];
                        $arrDadosCliente['telefone']  = $post["cliente_telefone"][$key];

                        $idClienteIndicado       = $mClienteIndicado->salvar($arrDadosCliente);
                    }
                }


                // =============== Salva curriculo
                if( isset($post["link_curriculo"]) and count($post["link_curriculo"]) ){
                    $mCurriculo       = new Application_Model_DbTable_Base_Curriculo();
                    $arrDadosCurriculo = array();

                    foreach ($post["link_curriculo"] as $key => $dado) {
                        $arrDadosCurriculo['user_id']   = $idLogin;
                        $arrDadosCurriculo['url']       = $dado;
                        $idCurriculo       = $mCurriculo->salvar($arrDadosCurriculo);
                    }
                }

                $mensagem = "<p>link usuario:";
                $mensagem .= "<a href='http://".$_SERVER['HTTP_HOST']."/usuario/cadastro-coach-convite/id/" . $idLogin . "' />verificar solicitação</a></p>";
                $mensagem .= "<br />";
                $mensagem .= "<p>link para gerar o código convite:";
                $mensagem .= "<a href='http://".$_SERVER['HTTP_HOST']."/usuario/gerar-convite-coach/id/" . $idLogin . "' />gerar código convite</a></p>";


                Base_Mail::mail(
                    'fabiano@menttoo.com',
                    'menttoo::Solicitação de convite coaching',
                    $mensagem,
                    'menttoo', 
                    'contato@inmais.com.br'
                );                


                
                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Solicitação enviada com sucesso.'));
                $this->redirect('usuario', 'cadastro-coach', 'site', array('id' => $idLogin));
            } else {
                $this->setErrorMessage(Base_Message::ERROR_FORM, array('Erro ao submeter o formulário.'));
                $this->redirect('usuario', 'cadastro-coach-convite', 'site');
            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmConvite', $this->getRequest()->getPost());
            if (isset($idLogin) && $idLogin) {
                $this->redirect('usuario', 'cadastro-coach-convite', 'site', array('id' => $idLogin));
            } else {
                $this->redirect('usuario', 'cadastro-coach-convite', 'site');
            }
        }     
        
        // exit();
    }


    public function verificarSolicitacaoAction(){
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

        try {
            if ($this->_request->isPost()) {

                // echo "<pre>";
                $post = $this->_request->getPost();

                $mLogin        = new Application_Model_DbTable_Base_Login();
                $rsLogin       = $mLogin->pesquisar( $post );
                $rsLogin       = $rsLogin->current();
                // echo $rsLogin->coun;
                if( $rsLogin ){
                    echo "1";
                }else{
                    echo "2";
                }
                // exit();

                
                
                $this->setErrorMessage(Base_Message::ERROR_FORM, array('Já existe uma solicitação para esse e-mail, favor aguardar.'));
                // $this->redirect('usuario', 'cadastro-coach', 'site', array('id' => $idLogin));
            } else {
                // $this->setErrorMessage(Base_Message::ERROR_FORM, array('Erro ao submeter o formulário.'));
                // $this->redirect('usuario', 'cadastro-coach-convite', 'site');
            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($idLogin) && $idLogin) {
                $this->redirect('usuario', 'cadastro-coach-convite', 'site', array('id' => $idLogin));
            } else {
                $this->redirect('usuario', 'cadastro-coach-convite', 'site');
            }
        }     

    }       

    public function gerarConviteCoachAction(){

        try {
            $params                  = $this->_request->getParams();
            if ( isset($params['id']) ) {

                $mLogin        = new Application_Model_DbTable_Base_Login();
                $rsLogin       = $mLogin->find( $params['id'] )->current();

                if ( $rsLogin ) {
                    $rsLogin->lgn_status = 'A';
                    $rsLogin->lgn_codigo_convite = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 6 )  );
                    $rsLogin->save();
                }

                $this->view->usuario = $rsLogin;


                $html = '';

                    $html .= '<table border="0" cellspacing="" cellspacing="" width="680" bgcolor="#2A2B1D" background="img_bg.jpg" align="center">';
                        $html .= '<tr>';
                            $html .= '<td align="center">';
                                $html .= '<a href="" style="outline:none; margin: 40px 0 50px 0; display:inline-block;">';
                                    $html .= '<img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/logo_bc.png" style="">';
                                $html .= '</a>';
                            $html .= '</td>';
                        $html .= '</tr>';
                        $html .= '<tr>';
                            $html .= '<td align="center" style="font-family:Arial; font-weight: 700; font-size: 50px; text-transform: uppercase; color: #fdda6f;">';
                                $html .= 'parabéns<br /> <br />';
                            $html .= '</td>';
                        $html .= '</tr>';
                        $html .= '<tr>';
                            $html .= '<td align="center" style="font-family:Arial; font-weight: 100; font-size: 26px; text-transform: uppercase; color: #fdda6f; line-height: 26px;">';
                                $html .= 'Você recebeu um convite:';
                            $html .= '</td>';
                        $html .= '</tr>';
                        $html .= '<tr>';
                            $html .= '<td align="center" style="font-family:Arial; font-weight: 100; font-size: 39px; color: #fdda6f; line-height: 26px; padding: 40px 0 10px 0;">';
                                $html .= '<br /><br />sua senha de acesso<br />';
                            $html .= '</td>';
                        $html .= '</tr>';
                        $html .= '<tr>';
                            $html .= '<td>';
                                $html .= '<div style="border-radius: 5px; border: 3px solid #fdda6f; width: 90%; margin: 20px 5% 0 5%;">';
                                    $html .= '<table border="0" cellspacing="" cellspacing="" width="100%">';
                                        $html .= '<tr>';
                                            $html .= '<td align="center" style="font-family:Arial; font-weight: 600; font-size: 28px; padding: 15px 0; color: #fdda6f; line-height: 18px;">';
                                                $html .= $rsLogin->lgn_codigo_convite;
                                            $html .= '</td>';
                                        $html .= '</tr>';
                                    $html .= '</table>';
                                $html .= '</div>';
                            $html .= '</td>';
                        $html .= '</tr>';
                        $html .= '<tr>';
                            $html .= '<td>';
                                $html .= '<br /><br />';
                                $html .= '<div style="width: 90%; margin: 20px 5% 60px 5%;">';
                                    $html .= '<table border="0" cellspacing="" cellspacing="" width="100%">';
                                        $html .= '<tr>';
                                            $html .= '<td align="center" style="padding: 15px 0; ">';
                                                $html .= '<a href="http://'.$_SERVER['HTTP_HOST'].'/usuario/cadastro-coach/codigo/' . $rsLogin->lgn_codigo_convite. '" style="display: inline-block; width: 100%; height: 60px; text-align: center; background-color: #FCD96F; border-radius: 4px; text-decoration: none; font-size: 22px; font-family:Arial; font-weight: 600; color: #2B2B1D; line-height: 60px;">CADASTRE-SE AGORA</a>';
                                            $html .= '</td>';
                                        $html .= '</tr>';
                                    $html .= '</table>';
                                $html .= '</div>';
                            $html .= '</td>';
                        $html .= '</tr>';
                        $html .= '<tr>';
                            $html .= '<td bgcolor="#222538">';
                                $html .= '<table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">';
                                    $html .= '<tr>';
                                        $html .= '<td  style="text-align: center; font-size: 28px; font-family:Arial; font-weight: 600; color: #2961FD;">Não sabe o que é a Menttoo? </td>';
                                    $html .= '</tr>';
                                    $html .= '<tr>';
                                        $html .= '<td style="text-align: center; font-size: 22px; font-family:Arial; font-weight: 100; color: #2961FD;">Acesse o site e nossas redes e saiba mais:</td>';
                                    $html .= '</tr>';
                                    $html .= '<tr>';
                                        $html .= '<td style="text-align: center; font-size: 18px; font-family:Arial; font-weight: 100; color: #2961FD; padding: 50px 0 0 0;">www.menttoo.com</td>';
                                    $html .= '</tr>';
                                    $html .= '<tr>';
                                        $html .= '<td align="center" style="text-align: center;">
                                                <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                                    <tr>
                                                        <td align="center">
                                                            <a href="https://www.linkedin.com/company-beta/3589739/" style="outline:none; margin: 0 10px; display:inline-block;">
                                                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_linkedin_az.png" style="">
                                                            </a>
                                                        </td>

                                                        <td align="center">
                                                            <a href="https://www.facebook.com/menttoo/?fref=ts" style="outline:none; margin: 0 5px; display:inline-block; border-left: 1px solid #275BE5; border-right: 1px solid #275BE5; padding:0 14px;">
                                                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_facebook_az.png" style="">
                                                            </a>
                                                        </td>
                                                        <td align="center">
                                                            <a href="https://www.youtube.com/channel/UCY6ynwaxdfSC7e8SCTP4UTQ" style="outline:none; margin: 0 5px; display:inline-block;">
                                                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_youtube_az.png" style="">
                                                            </a>
                                                        </td>
                                                    </td>
                                                </table>
                                        </td>';
                                    $html .= '</tr>';
                                $html .= '</table>';
                            $html .= '</td>';
                        $html .= '</tr>';
                    $html .= '</table>'; 

                Base_Mail::mail(
                    $rsLogin->lgn_email,
                    'menttoo::Codigo convite',
                    $html,
                    'menttoo', 
                    'contato@inmais.com.br'
                );                      
                
            } else {
                $this->redirect('usuario', 'cadastro-coach-convite', 'site');
            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($idLogin) && $idLogin) {
                $this->redirect('usuario', 'gerar-convite-coach', 'site', array('id' => $idLogin));
            } else {
                $this->redirect('usuario', 'gerar-convite-coach', 'site');
            }
        }     

    }   

    public function cadastroCoachAction(){
        $params                  = $this->_request->getParams();
        // $this->view->codigo_convite = '';

        $_SESSION["SOU"] = 'coach';

        if ( isset($params['codigo']) ) { 
            // $this->view->codigo_convite = $params['codigo'];
            
            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->pesquisar($params)->current();
            $this->view->usuario = $rLogin;  

            // echo "<pre>";          
            // print_r($rLogin);
            // exit();
        }
    }

    public function cadastroCoachSalvarAction(){
        if ($this->_request->isPost()) {

            // echo "<pre>";
            $post = $this->_request->getPost();

            $mLogin        = new Application_Model_DbTable_Base_Login();
            $rsLogin       = $mLogin->find( $post['id'] )->current();

            if ( $rsLogin ) {
                $rsLogin->lgn_senha = md5( $post["senha"] );
                $rsLogin->save();
                $idLogin = $rsLogin->lgn_id;

                $mLogin->autenticar( array( "login"=>$post["email"],"senha"=>$post["senha"] ) );
            }


            $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Cadastro realizado com sucesso, favor completar o cadastro.'));
            $this->redirect('usuario', 'cadastro-coach-completar', 'site', array('id' => $idLogin));  

            // echo "<pre>";
            // print_r( $rsLogin );
            // exit();

        }    
    }



    // 
    public function cadastroCoachCompletarAction(){

        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $idLogin = $params["id"];
        }else if( Zend_Auth::getInstance()->hasIdentity() ) {  
            $dados = Zend_Auth::getInstance()->hasIdentity();
            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin     = $identity->lgn_id;
        }



        if ( isset($idLogin) ) {
            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->getUsuario(array("id"=>$idLogin));
            $this->view->usuario = $rLogin;            
        }
            

        $mEstado = new Application_Model_DbTable_Base_Estado();
        $this->view->estados = $mEstado->combo();

        $mSegmentoTipoCoach = new Application_Model_DbTable_Base_SegmentoTipoCoach();
        $rSegmentoLifeCoach = $mSegmentoTipoCoach->pesquisar(array("tipo_coach"=>1));
        $rSegmentoExecutive = $mSegmentoTipoCoach->pesquisar(array("tipo_coach"=>2));            

        $this->view->seg_life = $rSegmentoLifeCoach;
        $this->view->seg_executive = $rSegmentoExecutive;

        // echo "<pre>";
        // print_r( $rLogin);


    }    

    public function cadastroCoachCompletarSalvarAction(){
        try {
            if ($this->_request->isPost()) {

                // echo "<pre>";
                $post = $this->_request->getPost();


                $files      = new Zend_File_Transfer_Adapter_Http();
                $filesInfo  = $files->getFileInfo();
                // print_r($filesInfo);
                // exit();
                // echo "<br>====================<br>";

                // print_r($post);

                // echo "<br>====================<br>";
                // exit();


                // =============== Salva os dados pessoais
                $arrDadosPessoais = array();

                if (isset($post['id']) && $post['id']) {
                    $arrDadosPessoais['id'] = $post['id'];
                    $idLogin = $post['id'];
                }

                // $dados = Zend_Auth::getInstance()->hasIdentity();
                if ( Zend_Auth::getInstance()->hasIdentity() ) {
                    $identity   = Zend_Auth::getInstance()->getIdentity();
                    // $perfil     = $identity->perfil;
                    $arrDadosPessoais['perfil'] = $identity->lgn_lgp_id;
                }else{
                    $arrDadosPessoais['perfil'] = 3;
                }



                // $arrDadosPessoais['nome']       = $post['nome'];
                // $arrDadosPessoais['email']      = $post['email'];
                $arrDadosPessoais['ddd']        = $post['ddd'];
                $arrDadosPessoais['telefone']   = $post['telefone'];
                $arrDadosPessoais['nascimento'] = $post['nascimento'];
                $arrDadosPessoais['uf']         = strtoupper($post['uf']);
                $arrDadosPessoais['cidade']     = ucfirst( strtolower($post['cidade']) );
                $arrDadosPessoais['processo_coaching'] = isset($post['processo_coaching']) ? $post['processo_coaching'] : '';
                $arrDadosPessoais['duracao_media'] = isset($post['duracao_media']) ? $post['duracao_media'] : '';
                $arrDadosPessoais['preco_sessao'] = isset($post['preco_sessao']) ? $post['preco_sessao'] : '';
                $arrDadosPessoais['bio'] = $post['bio'];
                $arrDadosPessoais['cadastro_completo'] = 1;
                



                $uploadPathDiploma = PUBLIC_PATH . '/portal/uploads/usuario/avatar/';
                if (!file_exists($uploadPathDiploma)) {
                    if (!mkdir($uploadPathDiploma, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPathDiploma, 0777);
                }

                foreach ($filesInfo as $fieldname => $fileinfo) {
                    
                    // Arquivos avatar
                    if( $fieldname == 'avatar' ){

                        if( $fileinfo['name'] ){
                            $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                            $nomeArquivo          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                            $filePath                    = $uploadPathDiploma . $nomeArquivo;
                            $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                            $files->receive($fileinfo['name']);
                            chmod($filePath, 0777);
                            
                            $arrDadosPessoais['avatar'] = $nomeArquivo;
                        }
                       
                    }
                    // fim - Avatar
                }

                $mLogin        = new Application_Model_DbTable_Base_Login();
                $idLogin       = $mLogin->salvar($arrDadosPessoais);






                // =============== Salva os dados do diploma

                $mDiploma        = new Application_Model_DbTable_Base_Diploma();
                $arrDadosDiploma = array();


                $uploadPathDiploma = PUBLIC_PATH . '/portal/uploads/usuario/diploma/';
                if (!file_exists($uploadPathDiploma)) {
                    if (!mkdir($uploadPathDiploma, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPathDiploma, 0777);
                }

                $count_diploma = 0;
                foreach ($filesInfo as $fieldname => $fileinfo) {
                    
                    // Arquivos diploma
                    if( substr($fieldname, 0,12) == 'diploma_file' ){


                        if( $fileinfo['name'] ){
                            $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                            $nomeArquivo          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                            $filePath                    = $uploadPathDiploma . $nomeArquivo;
                            $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                            $files->receive($fileinfo['name']);
                            chmod($filePath, 0777);


                            if( isset( $post['diploma_id'][$count_diploma] ) ){
                                $arrDadosDiploma['id'] = $post['diploma_id'][$count_diploma];
                            }

                            $arrDadosDiploma['arquivo'] = $nomeArquivo;
                            $arrDadosDiploma['user_id'] = $idLogin;



                            if( !empty( $post['diploma_data'][$count_diploma] ) and strlen( $post['diploma_data'][$count_diploma] ) == 10 ){
                                $data = explode("/", $post['diploma_data'][$count_diploma] );
                                $data = $data[2].'-'.$data[1].'-'.$data[0];
                            }                            
                            $arrDadosDiploma['data_encerramento'] = $data;
                            $arrDadosDiploma['nome_escola'] = $post['diploma_nome_escola'][$count_diploma];
                            $idDiploma       = $mDiploma->salvar($arrDadosDiploma);  
                            // print_r($arrDadosDiploma);
                        }else if( $post['diploma_nome_escola'][$count_diploma] ){
                            if( isset( $post['diploma_id'][$count_diploma] ) ){
                                $arrDadosDiploma['id'] = $post['diploma_id'][$count_diploma];
                            }else{
                                if ( isset( $arrDadosDiploma['id'] ) ) {
                                    unset($arrDadosDiploma['id']);
                                }
                            }
                            if( isset( $arrDadosDiploma['arquivo'] ) ){ unset($arrDadosDiploma['arquivo']); }
                            $arrDadosDiploma['user_id'] = $idLogin;


                            if( !empty( $post['diploma_data'][$count_diploma] ) and strlen( $post['diploma_data'][$count_diploma] ) == 10 ){
                                $data = explode("/", $post['diploma_data'][$count_diploma] );
                                $data = $data[2].'-'.$data[1].'-'.$data[0];
                            }

                            $arrDadosDiploma['data_encerramento'] = $data;
                            $arrDadosDiploma['nome_escola'] = $post['diploma_nome_escola'][$count_diploma];
                            $idDiploma       = $mDiploma->salvar($arrDadosDiploma);   
                            // print_r($arrDadosDiploma);
                            // echo "string 2 <br />";
                        }

                        $count_diploma++;                        
                        
                    }
                    // fim - Arquivos diploma
                }





                // =============== Salva os segmentos
                if( isset($post["segmento_item"]) and count($post["segmento_item"]) ){
                    $mSegmentoLogin       = new Application_Model_DbTable_Base_SegmentoLogin();
                    $mSegmentoLogin->delete( "user_id=" . $idLogin );
                    
                    $arrDadosSemento = array();
                    foreach ($post["segmento_item"] as $dado) {
                        $item = explode("-", $dado);
                        $arrDadosSemento['user_id']       = $idLogin;
                        $arrDadosSemento['tipo_id']       = $item[0];
                        $arrDadosSemento['segmento_id']   = $item[1];
                        $idSegmentoLogin       = $mSegmentoLogin->salvar($arrDadosSemento);
                    }
                }




                // =============== Salva os dados do credencial

                $mCredencial        = new Application_Model_DbTable_Base_Credencial();
                $arrDadosCredencial = array();


                $uploadPathCredencial = PUBLIC_PATH . '/portal/uploads/usuario/credencial/';
                if (!file_exists($uploadPathCredencial)) {
                    if (!mkdir($uploadPathCredencial, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPathCredencial, 0777);
                }

                $count_credencial = 0;
                foreach ($filesInfo as $fieldname => $fileinfo) {
                    
                    // Arquivos credencial
                    if( substr($fieldname, 0,15) == 'credencial_file' ){


                        if( $fileinfo['name'] ){
                            $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                            $nomeArquivo          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                            $filePath                    = $uploadPathCredencial . $nomeArquivo;
                            $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                            $files->receive($fileinfo['name']);
                            chmod($filePath, 0777);


                            if( isset( $post['credencial_id'][$count_credencial] ) ){
                                $arrDadosCredencial['id'] = $post['credencial_id'][$count_credencial];
                            }

                            $arrDadosCredencial['arquivo'] = $nomeArquivo;
                            $arrDadosCredencial['user_id'] = $idLogin;
                            

                            if( !empty( $post['credencial_data'][$count_credencial] ) and strlen( $post['credencial_data'][$count_credencial] ) == 10 ){
                                $data = explode("/", $post['credencial_data'][$count_credencial] );
                                $data = $data[2].'-'.$data[1].'-'.$data[0];
                            }

                            $arrDadosCredencial['data_validade'] = $data;
                            $arrDadosCredencial['titulo'] = $post['credencial_titulo'][$count_credencial];
                            $idCredencial       = $mCredencial->salvar($arrDadosCredencial);  
                            // print_r($arrDadosCredencial);
                        }else if( $post['credencial_titulo'][$count_credencial] ){
                            if( isset( $post['credencial_id'][$count_credencial] ) ){
                                $arrDadosCredencial['id'] = $post['credencial_id'][$count_credencial];
                            }else{
                                if ( isset( $arrDadosCredencial['id'] ) ) {
                                    unset($arrDadosCredencial['id']);
                                }
                            }
                            if( isset( $arrDadosCredencial['arquivo'] ) ){ unset($arrDadosCredencial['arquivo']); }
                            $arrDadosCredencial['user_id'] = $idLogin;

                            if( !empty( $post['credencial_data'][$count_credencial] ) and strlen( $post['credencial_data'][$count_credencial] ) == 10 ){
                                $data = explode("/", $post['credencial_data'][$count_credencial] );
                                $data = $data[2].'-'.$data[1].'-'.$data[0];
                            }

                            $arrDadosCredencial['data_validade'] = $data;
                            $arrDadosCredencial['titulo'] = $post['credencial_titulo'][$count_credencial];
                            $idCredencial       = $mCredencial->salvar($arrDadosCredencial);   
                        }

                        $count_credencial++;                        
                        
                    }
                    // fim - Arquivos credencial
                }




                // =============== Salva os dados do comprovante

                $mComprovante        = new Application_Model_DbTable_Base_Comprovante();
                $arrDadosComprovante = array();


                $uploadPathComprovante = PUBLIC_PATH . '/portal/uploads/usuario/comprovante/';
                if (!file_exists($uploadPathComprovante)) {
                    if (!mkdir($uploadPathComprovante, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPathComprovante, 0777);
                }

                $count_comprovante = 0;
                foreach ($filesInfo as $fieldname => $fileinfo) {
                    
                    // Arquivos comprovante
                    if( substr($fieldname, 0,16) == 'comprovante_file' ){


                        if( $fileinfo['name'] ){
                            $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                            $nomeArquivo          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                            $filePath             = $uploadPathComprovante . $nomeArquivo;
                            $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                            $files->receive($fileinfo['name']);
                            chmod($filePath, 0777);


                            if( isset( $post['comprovante_id'][$count_comprovante] ) ){
                                $arrDadosComprovante['id'] = $post['comprovante_id'][$count_comprovante];
                            }

                            $arrDadosComprovante['arquivo'] = $nomeArquivo;
                            $arrDadosComprovante['user_id'] = $idLogin;
                            $arrDadosComprovante['horas']   = $post['comprovante_hora'][$count_comprovante];
                            $idComprovante                  = $mComprovante->salvar($arrDadosComprovante);  
                            // print_r($arrDadosComprovante);
                            //echo "1";
                        }else if( $post['comprovante_hora'][$count_comprovante] ){
                            if( isset( $post['comprovante_id'][$count_comprovante] ) ){
                                $arrDadosComprovante['id']  = $post['comprovante_id'][$count_comprovante];
                            }else{
                                if ( isset( $arrDadosComprovante['id'] ) ) {
                                    unset($arrDadosComprovante['id']);
                                }
                            }

                            if( isset( $arrDadosComprovante['arquivo'] ) ){ unset($arrDadosComprovante['arquivo']); }
                            $arrDadosComprovante['user_id'] = $idLogin;
                            $arrDadosComprovante['horas']   = $post['comprovante_hora'][$count_comprovante];
                            $idComprovante                  = $mComprovante->salvar($arrDadosComprovante);   
                            //echo "2";
                        }

                        $count_comprovante++;                        
                        
// /                        print_r($arrDadosComprovante);
                    }
                    // fim - Arquivos comprovante
                }



                // =============== Salva curriculo
                if( isset($post["link_curriculo"]) and count($post["link_curriculo"]) ){
                    $mCurriculo       = new Application_Model_DbTable_Base_Curriculo();
                    $mCurriculo->delete( "user_id=" . $idLogin );
                    $arrDadosCurriculo = array();

                    foreach ($post["link_curriculo"] as $key => $dado) {
                        $arrDadosCurriculo['user_id']   = $idLogin;
                        $arrDadosCurriculo['url']       = $dado;
                        $idCurriculo       = $mCurriculo->salvar($arrDadosCurriculo);
                    }
                }




                // =============== Salva os dados do curso

                $mCursos        = new Application_Model_DbTable_Base_Cursos();
                $arrDadosCursos = array();


                $uploadPathCursos = PUBLIC_PATH . '/portal/uploads/usuario/cursos/';
                if (!file_exists($uploadPathCursos)) {
                    if (!mkdir($uploadPathCursos, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPathCursos, 0777);
                }

                $count_cursos = 0;
                foreach ($filesInfo as $fieldname => $fileinfo) {
                    
                    // Arquivos cursos
                    if( substr($fieldname, 0,11) == 'cursos_file' ){


                        if( $fileinfo['name'] ){
                            $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                            $nomeArquivo          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                            $filePath                    = $uploadPathCursos . $nomeArquivo;
                            $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                            $files->receive($fileinfo['name']);
                            chmod($filePath, 0777);


                            if( isset( $post['cursos_id'][$count_cursos] ) ){
                                $arrDadosCursos['id'] = $post['cursos_id'][$count_cursos];
                            }

                            $arrDadosCursos['arquivo'] = $nomeArquivo;
                            $arrDadosCursos['user_id'] = $idLogin;

                            if( !empty( $post['cursos_data1'][$count_cursos] ) and strlen( $post['cursos_data1'][$count_cursos] ) == 10 ){
                                $data = explode("/", $post['cursos_data1'][$count_cursos] );
                                $data = $data[2].'-'.$data[1].'-'.$data[0];
                            }
                            
                            $arrDadosCursos['data_inicio'] = $data ;

                            if( !empty( $post['cursos_data2'][$count_cursos] ) and strlen( $post['cursos_data2'][$count_cursos] ) == 10 ){
                                $data = explode("/", $post['cursos_data2'][$count_cursos] );
                                $data = $data[2].'-'.$data[1].'-'.$data[0];
                            }                            
                            $arrDadosCursos['data_fim'] = $data;

                            $arrDadosCursos['nome_escola'] = $post['cursos_nome_escola'][$count_cursos];
                            $idCursos       = $mCursos->salvar($arrDadosCursos);  
                            // print_r($arrDadosCursos);
                        }else if( $post['cursos_nome_escola'][$count_cursos] ){
                            if( isset( $post['cursos_id'][$count_cursos] ) ){
                                $arrDadosCursos['id'] = $post['cursos_id'][$count_cursos];
                            }else{
                                if ( isset( $arrDadosCursos['id'] ) ) {
                                    unset($arrDadosCursos['id']);
                                }
                            }
                            if( isset( $arrDadosCursos['arquivo'] ) ){ unset($arrDadosCursos['arquivo']); }
                            $arrDadosCursos['user_id'] = $idLogin;

                            if( !empty( $post['cursos_data1'][$count_cursos] ) and strlen( $post['cursos_data1'][$count_cursos] ) == 10 ){
                                $data = explode("/",$post['cursos_data1'][$count_cursos]);
                                $data = $data[2].'-'.$data[1].'-'.$data[0];
                            }

                            $arrDadosCursos['data_inicio'] = $data;

                            if( !empty( $post['cursos_data2'][$count_cursos]) and strlen( $post['cursos_data2'][$count_cursos]) == 10 ){
                                $data = explode("/", $post['cursos_data2'][$count_cursos]);
                                $data = $data[2].'-'.$data[1].'-'.$data[0];
                            }
                            $arrDadosCursos['data_fim'] = $data;
                            $arrDadosCursos['nome_escola'] = $post['cursos_nome_escola'][$count_cursos];
                            $idCursos       = $mCursos->salvar($arrDadosCursos);   
                            // print_r($arrDadosCursos);
                            // echo "string 2 <br />";
                        }

                        $count_cursos++;                        
                        
                    }
                    // fim - Arquivos curso
                }







                // =============== Salva videos
                if( isset($post["link_videos"]) and count($post["link_videos"]) ){
                    $mVideos       = new Application_Model_DbTable_Base_Videos();
                    $mVideos->delete( "user_id=" . $idLogin );
                    $arrDadosVideos = array();

                    foreach ($post["link_videos"] as $key => $dado) {
                        $arrDadosVideos['user_id']   = $idLogin;
                        $arrDadosVideos['url']       = $dado;
                        $idVideos       = $mVideos->salvar($arrDadosVideos);
                    }
                }



                
                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Dados inseridos com sucesso.'));
                $this->redirect('usuario', 'meus-coachees', 'site', array('id' => $idLogin));
            } else {
                $this->setErrorMessage(Base_Message::ERROR_FORM, array('Erro ao submeter o formulário.'));
                $this->redirect('usuario', 'cadastro-coach-completar', 'site');
            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($idLogin) && $idLogin) {
                $this->redirect('usuario', 'cadastro-coach-completar', 'site', array('id' => $idLogin));
            } else {
                $this->redirect('usuario', 'cadastro-coach-completar', 'site');
            }
        }  
    }

    public function removerDiplomaAction(){
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $mDiploma        = new Application_Model_DbTable_Base_Diploma();
            $mDiploma->exclusao_fisica($params["id"]);
        }

        print_r($params);
        exit();        
    }

    public function perfilDeleteDiplomaAction(){
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $mDiploma        = new Application_Model_DbTable_Base_Diploma();
            $mDiploma->exclusao_fisica($params["id"]);
        }

        $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Item excluído com sucesso.'));
        $this->redirect('usuario', 'perfil-editar', 'site');

        print_r($params);
        exit();        
    }

    public function removerCredencialAction(){
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $mCredencial        = new Application_Model_DbTable_Base_Credencial();
            $mCredencial->exclusao_fisica($params["id"]);
        }

        print_r($params);
        exit();        
    }

    public function removerComprovanteAction(){
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $mComprovante        = new Application_Model_DbTable_Base_Comprovante();
            $mComprovante->exclusao_fisica($params["id"]);
        }

        print_r($params);
        exit();        
    }


    public function removerClienteAction(){
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $mClienteIndicado        = new Application_Model_DbTable_Base_ClienteIndicado();
            $mClienteIndicado->exclusao_fisica($params["id"]);
        }

        print_r($params);
        exit();        
    }

    public function removerCurriculoAction(){
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $mCurriculo        = new Application_Model_DbTable_Base_Curriculo();
            $mCurriculo->exclusao_fisica($params["id"]);
        }

        print_r($params);
        exit();        
    }

    public function removerCursosAction(){
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $mCursos        = new Application_Model_DbTable_Base_Cursos();
            $mCursos->exclusao_fisica($params["id"]);
        }

        print_r($params);
        exit();        
    }


    public function perfilAction(){

        $identity   = Zend_Auth::getInstance()->getIdentity();
        // echo "usuario <pre>";
        // print_r($identity);
        // exit();



        $params = $this->_request->getParams();

        if( isset($params["id"]) and $params["id"] ){
            $idLogin = $params["id"];
        }else if( Zend_Auth::getInstance()->hasIdentity() ) {  
            // $dados = Zend_Auth::getInstance()->hasIdentity();
            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin     = $identity->lgn_id;
        }

        if( !$idLogin){
            $this->setErrorMessage(Base_Message::ERROR_FORM, array( 'Usuario não encontrado.' ));
            $this->redirect('usuario', 'meus-coachees', 'site');            
            exit();
        }

        $mLogin = new Application_Model_DbTable_Base_Login();
        $rLogin = $mLogin->getUsuario(array("id"=>$idLogin));
        $this->view->usuario = $rLogin;


        $mMensagens = new Application_Model_DbTable_Base_Mensagens();
        $rMensagens = $mMensagens->pesquisar(array("coach_id"=>$idLogin));
        $this->view->msg_enviada = $rMensagens->count();

        // echo "<pre>";
        // print_r( $rMensagens->count() );
        // exit();

    }

    public function enviarMensagemCoachAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();        
        try {

            $params = $this->_request->getParams();
            
            if ( count($params) ) {

                //SALVA MENSAGEM
                $mMensagens = new Application_Model_DbTable_Base_Mensagens();
                $mensagen_id = $mMensagens->salvar($params);
                
                echo "OK";    


                // $mLogin = new Application_Model_DbTable_Base_Login();
                $identity   = Zend_Auth::getInstance()->getIdentity();

                $dados_notificaca = array(
                        "lgn_id"=>$params['coach_id'],
                        "msg_id"=>$mensagen_id,
                        "titulo"=>$identity->lgn_nome,
                        "texto"=>"Você não respondeu uma mensagem de " . $identity->lgn_nome . "! Não deixe seus coachees na mão :)",
                        "tipo"=>6
                    );


                $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
                $rNotificacoes = $mNotificacoes->salvar($dados_notificaca);


            }
            
            // $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Enviado com sucesso.'));
            // $this->redirect('usuario', 'perfil', 'site', array('id' => $post["coach_id"] ));

        } catch (Base_Exception $e) {
            // $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            // $this->redirect('usuario', 'perfil', 'site', array('id' => $post["coach_id"] ));
        }

    }    

    public function salvarPerfilAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();        
        try {

            $params = $this->_request->getParams();
            
            if ( count($params) ) {

                //SALVA PERFIL
                $mPerfisSalvo = new Application_Model_DbTable_Base_PerfisSalvo();
                $mPerfisSalvo->delete( "user_id=" . $params['user_id'] . " and perfil_id=" . $params['perfil_id'] );
                $mPerfisSalvo->salvar($params);
                
                echo "OK";    
                exit();
            }


            
            // $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Enviado com sucesso.'));
            // $this->redirect('usuario', 'perfil', 'site', array('id' => $post["coach_id"] ));

        } catch (Base_Exception $e) {
            // $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            // $this->redirect('usuario', 'perfil', 'site', array('id' => $post["coach_id"] ));
        }

    }  



    public function perfilEditarAction(){
        $params = $this->_request->getParams();
        $mLogin  = new Application_Model_DbTable_Base_Login();
        if (isset($params["id"])) {
            $rUsuario = $mLogin->find( $params["id"] )->current();
            $this->view->usuario = $rUsuario;
            $idLogin = $params["id"];
            $this->view->usuario2 = $mLogin->getUsuario(array("id"=>$idLogin ));
        }else if( Zend_Auth::getInstance()->getIdentity() != null ){    
            $rUsuario = $mLogin->find( Zend_Auth::getInstance()->getIdentity()->lgn_id )->current();
            $this->view->usuario = $rUsuario;            
            $this->view->usuario2 = $mLogin->getUsuario(array("id"=> Zend_Auth::getInstance()->getIdentity()->lgn_id  ));

            $idLogin = Zend_Auth::getInstance()->getIdentity()->lgn_id ;
        }else{
            $this->view->usuario2 = array();
            $this->view->usuario = array();
        }

        
        // SEGMENTOS
        $mSegmentoTipoCoach = new Application_Model_DbTable_Base_SegmentoTipoCoach();
        $rSegmentoLifeCoach = $mSegmentoTipoCoach->pesquisar(array("tipo_coach"=>1));
        $rSegmentoExecutive = $mSegmentoTipoCoach->pesquisar(array("tipo_coach"=>2));            

        $this->view->seg_life = $rSegmentoLifeCoach;
        $this->view->seg_executive = $rSegmentoExecutive;   


        // //EXPERIÊNCIA
        $mExperiencia  = new Application_Model_DbTable_Base_Experiencia();
        $rExperiencia = $mExperiencia->pesquisar($idLogin);
        $this->view->experiencia = $rExperiencia;


        // //PRÊMIOS
        $mPremios  = new Application_Model_DbTable_Base_Premios();
        $rPremios = $mPremios->pesquisar($idLogin);
        $this->view->premios = $rPremios;


        // //PORTFOLIO
        $mPortfolio  = new Application_Model_DbTable_Base_Portfolio();
        $rPortfolio = $mPortfolio->pesquisar($idLogin);
        $this->view->portfolio = $rPortfolio;


        // //DIPLOMA
        $mDiploma  = new Application_Model_DbTable_Base_Diploma();
        $rDiploma = $mDiploma->pesquisar_edit($idLogin);
        $this->view->diplomas = $rDiploma;


        //VIDEO
        $mVideo  = new Application_Model_DbTable_Base_Videos();
        $rVideo = $mVideo->pesquisar_edit($idLogin);
        $this->view->videos = $rVideo;


        //CURSOS
        $mCursos  = new Application_Model_DbTable_Base_Cursos();
        $rCursos = $mCursos->pesquisar_edit($idLogin);
        $this->view->cursos = $rCursos;


        //CREDENCIAL
        $mCredencial  = new Application_Model_DbTable_Base_Credencial();
        $rCredencial = $mCredencial->pesquisar_edit($idLogin);
        $this->view->credencial = $rCredencial;


        //COMPROVANTE
        $mComprovante  = new Application_Model_DbTable_Base_Comprovante();
        $rComprovante = $mComprovante->pesquisar_edit($idLogin)->current();
        $this->view->comprovante = $rComprovante;


        $mEstado = new Application_Model_DbTable_Base_Estado();
        $this->view->estados = $mEstado->combo();


        // data de aleração
        $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>1 ))->current();
        if ($rDataAlteracoes) { $this->view->da_pessoal = $rDataAlteracoes->data; }
        
        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>2 ))->current();
        if ($rDataAlteracoes) { $this->view->da_formacao = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>3 ))->current();
        if ($rDataAlteracoes) { $this->view->da_credencial = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>4 ))->current();
        if ($rDataAlteracoes) { $this->view->da_processo = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>5 ))->current();
        if ($rDataAlteracoes) { $this->view->da_limite = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>6 ))->current();
        if ($rDataAlteracoes) { $this->view->da_preco = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>7 ))->current();
        if ($rDataAlteracoes) { $this->view->da_video = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>8 ))->current();
        if ($rDataAlteracoes) { $this->view->da_experiencia = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>9 ))->current();
        if ($rDataAlteracoes) { $this->view->da_curso = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>10 ))->current();
        if ($rDataAlteracoes) { $this->view->da_projetos = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>11 ))->current();
        if ($rDataAlteracoes) { $this->view->da_reconhecimento = $rDataAlteracoes->data; }

        $rDataAlteracoes       = $mDataAlteracoes->pesquisar(array( "user_id"=>$idLogin, "area_id"=>13 ))->current();
        if ($rDataAlteracoes) { $this->view->da_segmentos = $rDataAlteracoes->data; }


        // echo "<pre>";
        // print_r($this->view->estados);
        // exit();

        // //VIDEO APRESENTAÇÃO
        // $mVideos  = new Application_Model_DbTable_Base_Videos();
        // $rVideos = $mVideos->pesquisar_edit($idLogin);
        // $this->view->cursos = $rVideos;

        // echo "<pre>";
        // print_r($rDataAlteracoes);
        // exit();

    }

    public function perfilEditarPessoaisSalvarAction()
    {

            if ($this->_request->isPost()) {

                // echo "<pre>";
                $post = $this->_request->getPost();


                $files      = new Zend_File_Transfer_Adapter_Http();
                $filesInfo  = $files->getFileInfo();
                // print_r($filesInfo);
                // exit();
                // echo "<br>====================<br>";

                // print_r($post);

                // echo "<br>====================<br>";
                // exit();


                // =============== Salva os dados pessoais
                $arrDadosPessoais = array();

                if (isset($post['id']) && $post['id']) {
                    $arrDadosPessoais['id'] = $post['id'];
                    $idLogin = $post['id'];
                }

                // $dados = Zend_Auth::getInstance()->hasIdentity();
                if ( Zend_Auth::getInstance()->hasIdentity() ) {
                    $identity   = Zend_Auth::getInstance()->getIdentity();
                    // $perfil     = $identity->perfil;
                    $arrDadosPessoais['perfil'] = $identity->lgn_lgp_id;
                }else{
                    $arrDadosPessoais['perfil'] = 3;
                }



                $arrDadosPessoais['nome']       = $post['nome'];
                // $arrDadosPessoais['email']      = $post['email'];
                $arrDadosPessoais['ddd']        = $post['ddd'];
                $arrDadosPessoais['telefone']   = $post['telefone'];
                $arrDadosPessoais['nascimento'] = $post['nascimento'];
                $arrDadosPessoais['uf']         = strtoupper($post['uf']);
                $arrDadosPessoais['cidade']     = ucfirst( strtolower($post['cidade']) );
                $arrDadosPessoais['bio']        = $post['bio'];


                $uploadPathDiploma = PUBLIC_PATH . '/portal/uploads/usuario/avatar/';
                if (!file_exists($uploadPathDiploma)) {
                    if (!mkdir($uploadPathDiploma, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPathDiploma, 0777);
                }

                foreach ($filesInfo as $fieldname => $fileinfo) {
                    
                    // Arquivos avatar
                    if( $fieldname == 'avatar' ){

                        if( $fileinfo['name'] ){
                            $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                            $nomeArquivo          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                            $filePath                    = $uploadPathDiploma . $nomeArquivo;
                            $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                            $files->receive($fileinfo['name']);
                            chmod($filePath, 0777);
                            
                            $arrDadosPessoais['avatar'] = $nomeArquivo;
                        }
                       
                    }
                    // fim - Avatar
                }

                $mLogin        = new Application_Model_DbTable_Base_Login();
                $idLogin       = $mLogin->salvar($arrDadosPessoais);

                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=1" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>1 ));



                
                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Dados inseridos com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $idLogin));
            } else {
                $this->setErrorMessage(Base_Message::ERROR_FORM, array('Erro ao submeter o formulário.'));
                $this->redirect('usuario', 'perfil-editar', 'site');
            }

    }

    public function perfilEditarSegmentosAction()
    {

        if ($this->_request->isPost()) {

            // echo "<pre>";
            $post = $this->_request->getPost();

            if (isset($post['lgn_id']) && $post['lgn_id']) {
                $idLogin = $post['lgn_id'];
            }

            $mSegmentoLogin       = new Application_Model_DbTable_Base_SegmentoLogin();
            $mSegmentoLogin->delete( "user_id=" . $idLogin );


            // =============== Salva os segmentos
            if( isset($post["segmento_item"]) and count($post["segmento_item"]) ){
               
                $arrDadosSemento = array();
                foreach ($post["segmento_item"] as $dado) {
                    $item = explode("-", $dado);
                    $arrDadosSemento['user_id']       = $idLogin;
                    $arrDadosSemento['tipo_id']       = $item[0];
                    $arrDadosSemento['segmento_id']   = $item[1];
                    $idSegmentoLogin       = $mSegmentoLogin->salvar($arrDadosSemento);
                }

                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=13" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>13 ));                
            }
        }

        $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Segmentos atualizado com sucesso.'));
        $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));

    }


    public function perfilEditarExperienciaAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();

                //se não selecionou coloca o valor como 0
                if( !isset($post['atual']) or empty($post['atual']) ){
                    $post['atual'] = 0;
                }

                $de = explode("/", $post["de"]);
                $post["de"] = $de[2].'-'.$de[1].'-'.$de[0];

                $ate = explode("/", $post["ate"]);
                $post["ate"] = $ate[2].'-'.$ate[1].'-'.$ate[0];

                $mExperiencia  = new Application_Model_DbTable_Base_Experiencia();
                $mExperiencia->salvar($post);

                $idLogin = $post['lgn_id'];

                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=8" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>8 ));

                if( isset($post["id"]) and !empty($post["id"]) ){

                    $rUsuario = $mExperiencia->find( $post["id"] )->current();    

                }

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Experiencia atualizada com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
            }

        }


    }   



    public function perfilDeleteExperienciaAction()
    {

        try {
            $params = $this->_request->getParams();
            if (isset($params['id']) and isset($params['lgn_id'])) {

                $mDados = new Application_Model_DbTable_Base_Experiencia();
                $mDados->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Experiência excluída.'));
            }
            
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $params["lgn_id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
        }

    }



    public function perfilEditarPortfolioAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();



                $files      = new Zend_File_Transfer_Adapter_Http();
                $filesInfo  = $files->getFileInfo();
                $uploadPath = PUBLIC_PATH . '/portal/uploads/usuario/portfolio/';
                if (!file_exists($uploadPath)) {
                    if (!mkdir($uploadPath, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPath, 0777);
                }


                //SALVA A IMAGEM NA PASTA
                foreach ($filesInfo as $fieldname => $fileinfo) {

                    if ($fieldname == 'imagem_portfolio' && $fileinfo['name'] != '') {
                        

                        $extensaoArquivo               = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                        $imagem_portfolio          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;

                        $filePath                      = $uploadPath . $imagem_portfolio;
                        $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                        $files->receive($fileinfo['name']); // cria o arquivo
                        chmod($filePath, 0777); // da permissão de leitura e escrita ao arquivo

                        $post["imagem"] = $imagem_portfolio;//PEGA O NOVO NOME DA IMAGEM  
                    }
                } 



                //SALVA DADOS
                $mPortfolio  = new Application_Model_DbTable_Base_Portfolio();
                $mPortfolio->salvar($post);
                $idLogin = $post['lgn_id'];

                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=10" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>10 ));

                // if( isset($post["id"]) and !empty($post["id"]) ){
                //     $rPortfolio = $mPortfolio->find( $post["id"] )->current();    
                // }  
                                   
                // echo "<pre>";
                // print_r($post);
                // exit(); 

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Portfolio atualizado com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            }

        }


    } 




    public function perfilRemoverImgPortfolioAction()
    {

        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        $params = $this->_request->getParams();
        if ( isset($params['id']) ) {
            
            $mPortfolio          = new Application_Model_DbTable_Base_Portfolio();
            $rsPortfolio         = $mPortfolio->find( $params['id'] )->current();
            $rsPortfolio->imagem = "";
            $rsPortfolio->save();
        }

        exit();
    } 




    public function perfilDeletePortfolioAction()
    {

        try {
            $params = $this->_request->getParams();
            if (isset($params['id']) and isset($params['lgn_id'])) {

                $mDados = new Application_Model_DbTable_Base_Portfolio();
                $mDados->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Portfolio excluído com sucesso!'));
            }
            
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $params["lgn_id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
        }

    }




    public function perfilEditarPremioAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();

                if( !empty($post["data"]) and strlen($post["data"]) == 10 ){
                    $data = explode("/", $post["data"]);
                    $post["data"] = $data[2].'-'.$data[1].'-'.$data[0];
                }

                $mPremios  = new Application_Model_DbTable_Base_Premios();
                $mPremios->salvar($post);
                $idLogin = $post['lgn_id'];

                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=11" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>11 ));

                if( isset($post["id"]) and !empty($post["id"]) ){

                    $rUsuario = $mPremios->find( $post["id"] )->current();    

                }                

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Prêmio atualizado com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            }

        }


    } 





    public function perfilDeletePremioAction()
    {

        try {
            $params = $this->_request->getParams();
            if (isset($params['id']) and isset($params['lgn_id'])) {

                $mDados = new Application_Model_DbTable_Base_Premios();
                $mDados->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Premio excluído.'));
            }
            
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $params["lgn_id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
        }

    }





    public function perfilEditarCursoAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();



                $files      = new Zend_File_Transfer_Adapter_Http();
                $filesInfo  = $files->getFileInfo();
                $uploadPath = PUBLIC_PATH . '/portal/uploads/usuario/curso/';
                if (!file_exists($uploadPath)) {
                    if (!mkdir($uploadPath, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPath, 0777);
                }


                //SALVA A IMAGEM NA PASTA
                foreach ($filesInfo as $fieldname => $fileinfo) {

                    if ($fieldname == 'imagem_curso' && $fileinfo['name'] != '') {
                        

                        $extensaoArquivo               = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                        $imagem_curso          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;

                        $filePath                      = $uploadPath . $imagem_curso;
                        $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                        $files->receive($fileinfo['name']); // cria o arquivo
                        chmod($filePath, 0777); // da permissão de leitura e escrita ao arquivo

                        $post["arquivo"] = $imagem_curso;//PEGA O NOVO NOME DA IMAGEM  
                    }
                } 


                $post["user_id"] = $post["lgn_id"];

                if (isset($post['data_inicio']) && $post['data_inicio']) {
                    $post['data_inicio'] = Base_Date::view2Db($post['data_inicio']);
                }   

                if (isset($post['data_fim']) && $post['data_fim']) {
                    $post['data_fim'] = Base_Date::view2Db($post['data_fim']);
                }   

                //SALVA DADOS
                $mCursos  = new Application_Model_DbTable_Base_Cursos();
                $mCursos->salvar($post);
                $idLogin = $post['lgn_id'];


                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=9" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>9 ));

                // if( isset($post["id"]) and !empty($post["id"]) ){
                //     $rPortfolio = $mPortfolio->find( $post["id"] )->current();    
                // }  
                                   
                // echo "<pre>";
                // print_r($post);
                // exit(); 

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Curso atualizado com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            }

        }


    } 


    public function perfilDeleteCursoAction()
    {

        try {
            $params = $this->_request->getParams();
            if (isset($params['id']) and isset($params['lgn_id'])) {

                $mCursos = new Application_Model_DbTable_Base_Cursos();
                $mCursos->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Curso excluído.'));
            }
            
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $params["lgn_id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
        }

    }


    public function perfilEditarVideoAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();

                $post["user_id"] = $post["lgn_id"];

                $mVideo  = new Application_Model_DbTable_Base_Videos();
                $mVideo->salvar($post);
                $idLogin = $post['lgn_id'];

                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=7" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>7 ));

                if( isset($post["id"]) and !empty($post["id"]) ){

                    $rVideo = $mVideo->find( $post["id"] )->current();    

                }  
                           

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Video alterado com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            }

        }


    } 





    public function perfilDeleteVideoAction()
    {

        try {
            $params = $this->_request->getParams();
            if (isset($params['id']) and isset($params['lgn_id'])) {

                $mDados = new Application_Model_DbTable_Base_Videos();
                $mDados->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Excluído com sucesso!'));
            }
            
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $params["lgn_id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
        }

    }


    public function perfilEditarDiplomaAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();


        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();




                $files      = new Zend_File_Transfer_Adapter_Http();
                $filesInfo  = $files->getFileInfo();
                $uploadPath = PUBLIC_PATH . '/portal/uploads/usuario/diploma/';
                if (!file_exists($uploadPath)) {
                    if (!mkdir($uploadPath, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPath, 0777);
                }

                foreach ($filesInfo as $fieldname => $fileinfo) {

                    if ($fieldname == 'diploma_file' && $fileinfo['name'] != '') {
                        
                        $extensaoArquivo               = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                        $post["arquivo"] = $url_lgn_diploma_file          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;

                        $filePath                      = $uploadPath . $url_lgn_diploma_file;
                        $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                        $files->receive($fileinfo['name']); // cria o arquivo
                        chmod($filePath, 0777); // da permissão de leitura e escrita ao arquivo


                    }
                } 

                if( !empty($post["data_encerramento"]) and strlen($post["data_encerramento"]) == 10 ){

                    $data_encerramento = explode("/", $post["data_encerramento"]);
                    $post["data_encerramento"] = $data_encerramento[2].'-'.$data_encerramento[1].'-'.$data_encerramento[0];

                }

                $post["user_id"] = $post["lgn_id"];
                $idLogin = $post["lgn_id"];

                $mDiploma  = new Application_Model_DbTable_Base_Diploma();
                $mDiploma->salvar($post);


                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=2" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>2 ));

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Diploma atualizado com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            }

        }


    } 




    public function editarPerfilDeleteDiplomaAction()
    {

        try {
            $params = $this->_request->getParams();
            if (isset($params['id']) and isset($params['lgn_id'])) {

                $mDados = new Application_Model_DbTable_Base_Diploma();
                $mDados->excluir($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Diploma excluído com sucesso!'));
                
            }
            
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $params["lgn_id"] ));

        } catch (Base_Exception $e) {echo 'erro';
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
        }

    }







    public function perfilEditarCredencialAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();



                $files      = new Zend_File_Transfer_Adapter_Http();
                $filesInfo  = $files->getFileInfo();
                $uploadPath = PUBLIC_PATH . '/portal/uploads/usuario/credencial/';
                if (!file_exists($uploadPath)) {
                    if (!mkdir($uploadPath, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPath, 0777);
                }


                //SALVA A IMAGEM NA PASTA
                foreach ($filesInfo as $fieldname => $fileinfo) {

                    if ($fieldname == 'imagem_credencial' && $fileinfo['name'] != '') {
                        

                        $extensaoArquivo               = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                        $imagem_curso          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;

                        $filePath                      = $uploadPath . $imagem_curso;
                        $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                        $files->receive($fileinfo['name']); // cria o arquivo
                        chmod($filePath, 0777); // da permissão de leitura e escrita ao arquivo

                        $post["arquivo"] = $imagem_curso;//PEGA O NOVO NOME DA IMAGEM  
                    }
                } 


                $post["user_id"] = $post["lgn_id"];

                if (isset($post['data_validade']) && $post['data_validade']) {
                    $post['data_validade'] = Base_Date::view2Db($post['data_validade']);
                }   

                // echo "<pre>";
                // print_r($post);
                // exit(); 

                //SALVA DADOS
                $mCredencial  = new Application_Model_DbTable_Base_Credencial();
                $mCredencial->salvar($post);
                $idLogin = $post['lgn_id'];

                                             // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=3" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>3 ));      
                // echo "<pre>";
                // print_r($post);
                // exit(); 

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Credencial atualizado com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            }

        }


    } 


    public function perfilDeleteCredencialAction()
    {

        try {
            $params = $this->_request->getParams();
            if (isset($params['id']) and isset($params['lgn_id'])) {

                $mCredencial = new Application_Model_DbTable_Base_Credencial();
                $mCredencial->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Credencial excluído.'));
            }
            
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $params["lgn_id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
        }

    }









    public function perfilEditarComprovanteAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();



                $files      = new Zend_File_Transfer_Adapter_Http();
                $filesInfo  = $files->getFileInfo();
                $uploadPath = PUBLIC_PATH . '/portal/uploads/usuario/comprovante/';
                if (!file_exists($uploadPath)) {
                    if (!mkdir($uploadPath, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPath, 0777);
                }


                //SALVA A IMAGEM NA PASTA
                foreach ($filesInfo as $fieldname => $fileinfo) {

                    if ($fieldname == 'imagem_horas' && $fileinfo['name'] != '') {
                        

                        $extensaoArquivo               = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                        $imagem_curso          = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;

                        $filePath                      = $uploadPath . $imagem_curso;
                        $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                        $files->receive($fileinfo['name']); // cria o arquivo
                        chmod($filePath, 0777); // da permissão de leitura e escrita ao arquivo

                        $post["arquivo"] = $imagem_curso;//PEGA O NOVO NOME DA IMAGEM  
                    }
                } 


                $post["user_id"] = $post["lgn_id"];

                // if (isset($post['data_validade']) && $post['data_validade']) {
                //     $post['data_validade'] = Base_Date::view2Db($post['data_validade']);
                // }   


                //SALVA DADOS
                $mComprovante  = new Application_Model_DbTable_Base_Comprovante();
                $mComprovante->salvar($post);
                $idLogin = $post['lgn_id'];

                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=4" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>4 ));
                // echo "<pre>";
                // print_r($post);
                // exit(); 

                                   
                // echo "<pre>";
                // print_r($post);
                // exit(); 

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Comprovante atualizado com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            }

        }


    } 


    public function perfilDeleteComprovantelAction()
    {

        try {
            $params = $this->_request->getParams();
            if (isset($params['id']) and isset($params['lgn_id'])) {

                $mComprovante  = new Application_Model_DbTable_Base_Comprovante();
                $mComprovante->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('comprovante excluído.'));
            }
            
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $params["lgn_id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"] ));
        }

    }




    public function perfilEditarPrecoAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();



                $post["id"] = $post["lgn_id"];



                //SALVA DADOS
                $mLogin  = new Application_Model_DbTable_Base_Login();
                $mLogin->salvar($post);
                $idLogin = $post['lgn_id'];

                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=6" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>6 ));

                // echo "<pre>";
                // print_r($post);
                // exit(); 

                                   
                // echo "<pre>";
                // print_r($post);
                // exit(); 

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Preço atualizado com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            }

        }


    } 


    public function perfilEditarDuracaoAction()
    {


        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {

            if ($this->_request->isPost()) {

                $post = $this->_request->getPost();



                $post["id"] = $post["lgn_id"];



                //SALVA DADOS
                $mLogin  = new Application_Model_DbTable_Base_Login();
                $mLogin->salvar($post);
                $idLogin = $post['lgn_id'];

                // salva a data de aleração
                $mDataAlteracoes        = new Application_Model_DbTable_Base_DataAlteracoes();
                $mDataAlteracoes->delete( "user_id='$idLogin' and area_id=5" );
                $idDataAlteracoes       = $mDataAlteracoes->salvar(array( "user_id"=>$idLogin, "area_id"=>5 ));

                // echo "<pre>";
                // print_r($post);
                // exit(); 

                                   
                // echo "<pre>";
                // print_r($post);
                // exit(); 

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Duração atualizado com sucesso.'));
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );

            }

        } catch (Base_Exception $e) {

            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('frmCadastro', $this->getRequest()->getPost());
            if (isset($id) && $$id) {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            } else {
                $this->redirect('usuario', 'perfil-editar', 'site', array('id' => $post["lgn_id"]) );
            }

        }


    } 

    public function meusCoacheesAction(){

        $mCoaching  = new Application_Model_DbTable_Base_Coaching();
        $rCoachees = $mCoaching->getMyCoachees(array("solicitacao"=>"s"));        
        $this->view->solicitacoes = $rCoachees;

        $rCoacheesEnc = $mCoaching->getMyCoachees(array("encerrado"=>"s"));        
        $this->view->encerrados = $rCoacheesEnc;

        // echo "<pre>";
        // // // print_r($rCoachees);

        // print_r($rCoacheesEnc);
        // exit();


        // $identity   = Zend_Auth::getInstance()->getIdentity();
        // $idLogin     = $identity->lgn_id;
        // echo "<pre>";
        // print_r($identity);
        // exit();
    }    

 

    public function avaliarCoacheeAction(){

        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $mCoaching  = new Application_Model_DbTable_Base_Coaching();
            $rSolicitacao = $mCoaching->getCoaching($params)->current();
            $this->view->solicitacao = $rSolicitacao;


            
            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->getUsuario(array("id"=>$rSolicitacao->lgn_id));
            $this->view->usuario = $rLogin; 

            // echo "<pre>";
            // print_r($rSolicitacao);
            // // print_r($rLogin);
            // exit();

            if ( isset($params['notif_id']) ) {
                $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
                $rNotificacoes = $mNotificacoes->find( $params["notif_id"] )->current();
                $rNotificacoes->status = 1;
                $rNotificacoes->save();        
            }
    
        }

    } 

    // fabiano@sanromadesign.com
    // sanromdesign@gmail.com     

    public function avaliarCoacheeAceitarAction(){
        
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $mensagem = "";
            if( isset($params['mensagem'])  ){
                $mensagem = $params['mensagem'];
            }

            $mCoaching  = new Application_Model_DbTable_Base_Coaching();
            $rSolicitacao = $mCoaching->find($params['id'])->current();
            $rSolicitacao->mensagem_boas_vindas = $mensagem;
            $rSolicitacao->status = 'A';
            $rSolicitacao->save();


            $mLogin = new Application_Model_DbTable_Base_Login();
            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin    = $identity->lgn_id;
            $rsLogin    = $mLogin->find( $idLogin )->current();


            

            if($rSolicitacao->coach_id == $rsLogin->lgn_id){
                $dados_enviar    = $mLogin->find( $rSolicitacao->coachee_id )->current();
            }else{
                $dados_enviar    = $mLogin->find( $rSolicitacao->coach_id )->current();
            }
            

            


            $mSegmentoLogin = new Application_Model_DbTable_Base_SegmentoLogin();
            $rSegmentoLogin = $mSegmentoLogin->pesquisar( array('user_id'=> $idLogin) )->toArray();

            $life_coahing = '';
            $executive_coahing = '';

            if ( count($rSegmentoLogin) ) {
                $key_life = array_search( 1 , array_column( $rSegmentoLogin, 'tipo_id'));
                $key_executive = array_search( 2 , array_column( $rSegmentoLogin, 'tipo_id'));
                if ( false !== $key_life ){ $life_coahing = 'Life Coaching'; }
                if ( false !== $key_executive ){ $executive_coahing = ' :: Executive Coaching'; }
            }



            $html = '

                <table border="0" cellspacing="" cellspacing="" width="680" bgcolor="#2A2B1D" background="img_bg.jpg" align="center">
                    <tr>
                        <td align="center">
                            <a href="" style="outline:none; margin: 40px 0 50px 0; display:inline-block;">
                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/logo_bc.png" style="">
                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 50px; text-transform: uppercase; color: #fdda6f;">
                            parabéns
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 26px; text-transform: uppercase; color: #fdda6f; line-height: 26px;">
                            Você iniciará o processo de coaching com:
                        </td>
                    </tr>

                    <tr>
                        <td align="center">
                            <div style="width:150px;height:150px; overflow: hidden; border-radius: 50%;margin: 35px auto 10px auto;border: 4px solid #fdda6f;"><img src="http://'.$_SERVER['HTTP_HOST'].'/portal/uploads/usuario/avatar/'.$rsLogin->lgn_avatar.'" style="margin: 0; width: 100%;"></div>
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 40px; color: #fdda6f; line-height: 40px;">
                            '.$rsLogin ->lgn_nome.'
                        </td>
                    </tr>


                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 20px; color: #fdda6f; line-height: 26px;">
                            Coach em '.$life_coahing.$executive_coahing.'
                        </td>
                    </tr>


                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 39px; color: #fdda6f; line-height: 26px; padding: 40px 0 10px 0;">
                            SEGUE OS CONTATOS:
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <div style="border-radius: 5px; border: 3px solid #fdda6f; width: 90%; margin: 20px 5% 60px 5%;">
                                <table border="0" cellspacing="" cellspacing="" width="100%">
                                    <tr>
                                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 18px; color: #fdda6f; line-height: 18px; padding-top: 20px;">
                                            TELEFONE
                                        </td>
                                    </tr>

                                    <tr>
                                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 30px; color: #fdda6f; line-height: 30px; padding-bottom: 10px;">
                                            '.$rsLogin ->lgn_ddd. '-' .$rsLogin ->lgn_telefone.'
                                        </td>
                                    </tr>

                                    <tr>
                                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 18px; color: #fdda6f; line-height: 18px; padding-top: 10px;">
                                            E-MAIL
                                        </td>
                                    </tr>

                                    <tr>
                                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 30px; color: #fdda6f; line-height: 30px; padding-bottom: 10px;">
                                            '.$rsLogin ->lgn_email.'
                                        </td>
                                    </tr>

                                </table>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td bgcolor="#222538">
                            <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                <tr>
                                    <td align="center">
                                        <a href="https://www.linkedin.com/company-beta/3589739/" style="outline:none; margin: 0 10px; display:inline-block;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_linkedin_az.png" style="">
                                        </a>
                                    </td>

                                    <td align="center">
                                        <a href="https://www.facebook.com/menttoo/?fref=ts" style="outline:none; margin: 0 5px; display:inline-block; border-left: 1px solid #275BE5; border-right: 1px solid #275BE5; padding:0 14px;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_facebook_az.png" style="">
                                        </a>
                                    </td>
                                    <td align="center">
                                        <a href="https://www.youtube.com/channel/UCY6ynwaxdfSC7e8SCTP4UTQ" style="outline:none; margin: 0 5px; display:inline-block;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_youtube_az.png" style="">
                                        </a>
                                    </td>
                                </td>
                            </table>
                        </td>
                    </tr>
                </table>


            ';

            Base_Mail::mail(
                $dados_enviar->lgn_email,
                'menttoo::Solicitação aceita',
                $html,
                'menttoo', 
                'contato@inmais.com.br'
            );  


            $dados_notificaca = array(
                    "lgn_id"=>$dados_enviar->lgn_id,
                    "coaching_id"=>$params['id'],
                    "titulo"=>"Parabéns! Processo de coaching iniciado",
                    "texto"=>"Agora você pode ter acesso aos contatos pessoais do coaching e falar diretamente com ele. CLIQUE AQUI E VEJA",
                    "tipo"=>2
                );

            // print_r($html);
            // echo "<pre>";
            // print_r($dados_enviar);
            // exit();

            $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
            $rNotificacoes = $mNotificacoes->salvar($dados_notificaca);

            // $mLogin = new Application_Model_DbTable_Base_Login();
            // $rLogin = $mLogin->getUsuario(array("id"=>$rSolicitacao->lgn_id));
            // $this->view->usuario = $rLogin; 


        }        
    }

    public function avaliarCoacheeRecusarAction(){
        
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $mCoaching  = new Application_Model_DbTable_Base_Coaching();
            $rSolicitacao = $mCoaching->find($params['id'])->current();
            $rSolicitacao->justificativa_recusa = $params['mensagem'];
            $rSolicitacao->status = 'R';
            $rSolicitacao->save();


            $mLogin = new Application_Model_DbTable_Base_Login();
            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin    = $identity->lgn_id;
            $rsLogin    = $mLogin->find( $idLogin )->current();


            

            if($rSolicitacao->coach_id == $rsLogin->lgn_id){
                $dados_enviar    = $mLogin->find( $rSolicitacao->coachee_id )->current();
            }else{
                $dados_enviar    = $mLogin->find( $rSolicitacao->coach_id )->current();
            }




            


            $mSegmentoLogin = new Application_Model_DbTable_Base_SegmentoLogin();
            $rSegmentoLogin = $mSegmentoLogin->pesquisar( array('user_id'=> $idLogin) )->toArray();

            $life_coahing = '';
            $executive_coahing = '';

            if ( count($rSegmentoLogin) ) {
                $key_life = array_search( 1 , array_column( $rSegmentoLogin, 'tipo_id'));
                $key_executive = array_search( 2 , array_column( $rSegmentoLogin, 'tipo_id'));
                if ( false !== $key_life ){ $life_coahing = 'Life Coaching'; }
                if ( false !== $key_executive ){ $executive_coahing = ' :: Executive Coaching'; }
            }



            $html = '

                <table border="0" cellspacing="" cellspacing="" width="680" bgcolor="#2A2B1D" background="img_bg.jpg" align="center">
                    <tr>
                        <td align="center">
                            <a href="" style="outline:none; margin: 40px 0 50px 0; display:inline-block;">
                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/logo_bc.png" style="">
                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 50px; text-transform: uppercase; color: #fdda6f;">
                            Que pena
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 26px; text-transform: uppercase; color: #fdda6f; line-height: 26px;">
                            Seu processo de coaching foi negado.
                        </td>
                    </tr>

                    <tr>
                        <td align="center">
                            <div style="width:150px;height:150px; overflow: hidden; border-radius: 50%;margin: 35px auto 10px auto;border: 4px solid #fdda6f;"><img src="http://'.$_SERVER['HTTP_HOST'].'/portal/uploads/usuario/avatar/'.$rsLogin ->lgn_avatar.'" style="margin: 0; width: 100%;"></div>
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 40px; color: #fdda6f; line-height: 40px;">
                            '.$rsLogin ->lgn_nome.'
                        </td>
                    </tr>


                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 20px; color: #fdda6f; line-height: 26px;">
                            Coach em '.$life_coahing.$executive_coahing.'
                        </td>
                    </tr>

                    <tr>
                        <td bgcolor="#222538">
                            <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                <tr>
                                    <td align="center">
                                        <a href="https://www.linkedin.com/company-beta/3589739/" style="outline:none; margin: 0 10px; display:inline-block;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_linkedin_az.png" style="">
                                        </a>
                                    </td>

                                    <td align="center">
                                        <a href="https://www.facebook.com/menttoo/?fref=ts" style="outline:none; margin: 0 5px; display:inline-block; border-left: 1px solid #275BE5; border-right: 1px solid #275BE5; padding:0 14px;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_facebook_az.png" style="">
                                        </a>
                                    </td>
                                    <td align="center">
                                        <a href="https://www.youtube.com/channel/UCY6ynwaxdfSC7e8SCTP4UTQ" style="outline:none; margin: 0 5px; display:inline-block;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_youtube_az.png" style="">
                                        </a>
                                    </td>
                                </td>
                            </table>
                        </td>
                    </tr>
                </table>


            ';

            Base_Mail::mail(
                $dados_enviar->lgn_email,
                'menttoo::Solicitação recusada',
                $html,
                'menttoo', 
                'contato@inmais.com.br'
            );  


            
            $dados_notificaca = array(
                    "lgn_id"=>$dados_enviar->lgn_id,
                    "coaching_id"=>$params['id'],
                    "titulo"=>"O coachee não topou o processo de coaching",
                    "texto"=>"Não topou fazer o coaching. Veja o motivo!",
                    "tipo"=>5
                );


            $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
            $rNotificacoes = $mNotificacoes->salvar($dados_notificaca);
        }        
    }


    public function encerrarCoachingAction(){
        $this->view->params = $this->_request->getParams();
    }      


    public function encerrarCoachingSalvarAction(){
        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin     = $identity->lgn_id;

            $mCoaching  = new Application_Model_DbTable_Base_Coaching();
            $rSolicitacao = $mCoaching->find($params['id'])->current();
            $rSolicitacao->mensagem_encerramento = $params['mensagem'];
            $rSolicitacao->status = 'E';
            $rSolicitacao->user_closed = $idLogin;
            $rSolicitacao->data_closed = Base_Date::getDateTime();
            $rSolicitacao->save();


            $mLogin  = new Application_Model_DbTable_Base_Login();


            if($rSolicitacao->coach_id == $idLogin){
                $dados_enviar    = $mLogin->find( $rSolicitacao->coachee_id )->current();
            }else{
                $dados_enviar    = $mLogin->find( $rSolicitacao->coach_id )->current();
            }


            $html = '

                <table border="0" cellspacing="" cellspacing="" width="680" bgcolor="#2A2B1D" background="img_bg.jpg" align="center">
                    <tr>
                        <td align="center">
                            <a href="" style="outline:none; margin: 40px 0 50px 0; display:inline-block;">
                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/logo_bc.png" style="">
                            </a>
                        </td>
                    </tr>


                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 40px; color: #fdda6f; line-height: 40px;">
                            '.$identity->lgn_nome.'
                        </td>
                    </tr>


                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 20px; color: #fdda6f; line-height: 26px;">
                            Mensagem de encerramento:<br /> '.$params['mensagem'].' <br /><br /> 

                        </td>
                    </tr>

                    <tr>
                        <td bgcolor="#222538">
                            <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                <tr>
                                    <td align="center">
                                        <a href="https://www.linkedin.com/company-beta/3589739/" style="outline:none; margin: 0 10px; display:inline-block;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_linkedin_az.png" style="">
                                        </a>
                                    </td>

                                    <td align="center">
                                        <a href="https://www.facebook.com/menttoo/?fref=ts" style="outline:none; margin: 0 5px; display:inline-block; border-left: 1px solid #275BE5; border-right: 1px solid #275BE5; padding:0 14px;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_facebook_az.png" style="">
                                        </a>
                                    </td>
                                    <td align="center">
                                        <a href="https://www.youtube.com/channel/UCY6ynwaxdfSC7e8SCTP4UTQ" style="outline:none; margin: 0 5px; display:inline-block;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_youtube_az.png" style="">
                                        </a>
                                    </td>
                                </td>
                            </table>
                        </td>
                    </tr>
                </table>

            ';



            Base_Mail::mail(
                $dados_enviar->lgn_email,
                'menttoo::Mensagem Encerramento',
                $html,
                'menttoo', 
                'contato@inmais.com.br'
            );                      
                



            $dados_notificaca = array(
                    "lgn_id"=>$dados_enviar->lgn_id,
                    "coaching_id"=>$params['id'],
                    "titulo"=>"Coaching encerrado. Faça a sua avaliação",
                    "texto"=>"O coaching foi encerrado. Faça sua avaliação",
                    "tipo"=>3
                );


            $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
            $rNotificacoes = $mNotificacoes->salvar($dados_notificaca);



            $this->redirect('usuario', 'encerrar-coaching-avaliacao', 'site', array('id' => $params["id"]) );
        }        
    }  

    public function encerrarCoachingAvaliacaoAction(){

        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $mCoaching = new Application_Model_DbTable_Base_Coaching();
            $rCoaching = $mCoaching->getCoaching(array( "id"=>$params['id'] ))->current();
            $this->view->coaching = $rCoaching;

            if ( isset($params["notif_id"]) ) {
                $mNotificacoes = new Application_Model_DbTable_Base_Notificacoes();
                $rNotificacoes = $mNotificacoes->find( $params["notif_id"] )->current();
                $rNotificacoes->status = 1;
                $rNotificacoes->save();
            }

        }        
    }   


    public function encerrarCoachingAvaliacaoSalvarAction(){

        $params = $this->_request->getParams();
        if (isset($params['coaching_id']) ) {


            $mAvaliacao  = new Application_Model_DbTable_Base_Avaliacao();
            $mAvaliacao->salvar($params);

            $mLogin  = new Application_Model_DbTable_Base_Login();

            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin     = $identity->lgn_id;

            if($params["user_id_avaliando"] == $idLogin){
                $dados_enviar    = $mLogin->find( $params["user_id_avaliado"] )->current();
            }else{
                $dados_enviar    = $mLogin->find( $params["user_id_avaliando"] )->current();
            }


            $html = '
                <table border="0" cellspacing="" cellspacing="" width="680" bgcolor="#2A2B1D" background="img_bg.jpg" align="center">
                    <tr>
                        <td align="center">
                            <a href="" style="outline:none; margin: 40px 0 50px 0; display:inline-block;">
                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/logo_bc.png" style="">
                            </a>
                        </td>
                    </tr>


                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 40px; color: #fdda6f; line-height: 40px;">
                            '.$identity->lgn_nome.'
                        </td>
                    </tr>


                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 20px; color: #fdda6f; line-height: 26px;">
                            Mensagem de agradecimento:<br /> '.$params['agradecimento'].' <br /><br /> 

                        </td>
                    </tr>

                    <tr>
                        <td bgcolor="#222538">
                            <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                <tr>
                                    <td align="center">
                                        <a href="https://www.linkedin.com/company-beta/3589739/" style="outline:none; margin: 0 10px; display:inline-block;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_linkedin_az.png" style="">
                                        </a>
                                    </td>

                                    <td align="center">
                                        <a href="https://www.facebook.com/menttoo/?fref=ts" style="outline:none; margin: 0 5px; display:inline-block; border-left: 1px solid #275BE5; border-right: 1px solid #275BE5; padding:0 14px;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_facebook_az.png" style="">
                                        </a>
                                    </td>
                                    <td align="center">
                                        <a href="https://www.youtube.com/channel/UCY6ynwaxdfSC7e8SCTP4UTQ" style="outline:none; margin: 0 5px; display:inline-block;">
                                            <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_youtube_az.png" style="">
                                        </a>
                                    </td>
                                </td>
                            </table>
                        </td>
                    </tr>
                </table>
            ';

            Base_Mail::mail(
                $dados_enviar->lgn_email,
                'menttoo::Mensagem Agradecimento',
                $html,
                'menttoo', 
                'contato@inmais.com.br'
            );                      

            $this->redirect('usuario', 'encerrar-coaching-avaliacao-menttoo', 'site', array('id' => $params["coaching_id"]) );
        }        
    } 


    public function encerrarCoachingAvaliacaoMenttooAction(){
        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $mCoaching = new Application_Model_DbTable_Base_Coaching();
            $rCoaching = $mCoaching->getCoaching(array( "id"=>$params['id'] ))->current();
            $this->view->coaching = $rCoaching;

            // echo "<pre>";
            // print_r($rCoaching);
            // exit();
        }           
    }              


    public function encerrarCoachingAvaliacaoMenttooSalvarAction(){
        $params = $this->_request->getParams();
        if (isset($params['coaching_id']) ) {

            $mAvaliacaoMenttoo = new Application_Model_DbTable_Base_AvaliacaoMenttoo();
            $mAvaliacaoMenttoo->salvar($params);

            $this->redirect('usuario', 'meus-coachees', 'site' );
        }           
    } 


    public function visualizarCoachingAvaliacaoAction(){

        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $mAvaliacao  = new Application_Model_DbTable_Base_Avaliacao();
            $rAvaliacao = $mAvaliacao->getAvaliacao(array( "id"=>$params['id'] ))->current();
            $this->view->avaliacao = $rAvaliacao;

            // echo "<pre>";
            // print_r($rAvaliacao);
            // exit();
        }
    }   

    public function visualizarCoachingAvaliacaoMenttooAction(){
        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $mAvaliacaoMenttoo  = new Application_Model_DbTable_Base_AvaliacaoMenttoo();
            $rAvaliacaoMenttoo = $mAvaliacaoMenttoo->getAvaliacao(array( "coaching_id"=>$params['id'] ))->current();
            $this->view->avaliacao = $rAvaliacaoMenttoo;

            // echo "<pre>";
            // print_r($rAvaliacaoMenttoo);
            // exit();
        }        
    }  

    public function mensagemRecusaCoachingAction(){
        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $mCoaching = new Application_Model_DbTable_Base_Coaching();
            $rCoaching = $mCoaching->getCoaching(array( "id"=>$params['id'], "recusado"=>"S" ))->current();
            $this->view->coaching = $rCoaching;

            $mLogin = new Application_Model_DbTable_Base_Login();
            $this->view->usuario    = $mLogin->find( $rCoaching->coach_id )->current();


            if ( isset($params['notif_id']) ) {
                $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
                $rNotificacoes = $mNotificacoes->find( $params["notif_id"] )->current();
                $rNotificacoes->status = 1;
                $rNotificacoes->save();        
            }
            // echo "<pre>";
            // print_r($rCoaching);
            // exit();
        }          
    }   


    public function mensagemAction(){
        $params = $this->_request->getParams();
        if (isset($params['id']) ) {

            $mMensagem = new Application_Model_DbTable_Base_Mensagens();
            $rMensagem = $mMensagem->find( $params['id'] )->current();
            $this->view->mensagem = $rMensagem;

            // $identity   = Zend_Auth::getInstance()->getIdentity();
            // $idLogin     = $identity->lgn_id;


            $mLogin = new Application_Model_DbTable_Base_Login();

            $this->view->usuario    = $mLogin->find( $rMensagem->user_id )->current();
            $this->view->coach    = $mLogin->find( $rMensagem->coach_id )->current();


            if ( isset($params["notif_id"]) ) {
                $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
                $rNotificacoes = $mNotificacoes->find( $params["notif_id"] )->current();
                $rNotificacoes->status = 1;
                $rNotificacoes->save();
            }

            // $rCoaching = $mCoaching->getCoaching(array( "id"=>$params['id'], "recusado"=>"S" ))->current();
            // $this->view->coaching = $rCoaching;

            // $mLogin = new Application_Model_DbTable_Base_Login();
            // $this->view->usuario    = $mLogin->find( $rCoaching->coach_id )->current();

            // echo "<pre>";
            // print_r( $rMensagem );
            // exit();
        }          
    }   




     public function mensagemSalvarAction()
     {


        try {

            if ($this->_request->isPost()) {
                
                $post = $this->_request->getPost();

                $post['data_resposta'] = date("Y-m-d H:i:s");

                $identity   = Zend_Auth::getInstance()->getIdentity();
                
                $mMensagens = new Application_Model_DbTable_Base_Mensagens();
                $rMensagem = $mMensagens->find( $post["id"] )->current();

                $idMsg = $mMensagens->salvar($post);

                $dados_notificaca = array(
                        "lgn_id"=>$rMensagem->user_id,
                        "msg_id"=>$post["id"],
                        "titulo"=>$identity->lgn_nome,
                        "texto"=>"Respondeu sua mensagem",
                        "tipo"=>6
                    );


                $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
                $rNotificacoes = $mNotificacoes->salvar($dados_notificaca);
                
            }
            
            $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('Enviado com sucesso.'));
            $this->redirect('usuario', 'mensagem', 'site', array('id' => $post["id"] ));

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('usuario', 'mensagem', 'site', array('id' => $post["id"] ));
        }

        exit();
    }

    public function notificacoesAction(){
    }    

    public function notificacoesMensagemAction(){
    }   

    public function dadosCoachAction(){
    }      


    public function convidarCoachAction(){

        $identity   = Zend_Auth::getInstance()->getIdentity();
        $idLogin    = $identity->lgn_id;

        $mCoachIndicado = new Application_Model_DbTable_Base_CoachIndicado();
        $rCoachIndicado = $mCoachIndicado->pesquisar( array("user_id"=>$idLogin) );
        $this->view->indicados = $rCoachIndicado;

        // echo "<pre>";
        // print_r($rCoachIndicado);
        // exit();

    }

    public function convidarCoachSalvarAction(){

        if ($this->_request->isPost()) {
            $post = $this->_request->getPost();


            if( isset($post['email']) and $post['email'] ){

                $mLogin = new Application_Model_DbTable_Base_Login();
                $ja_cadastrado = $mLogin->findByEmail($post['email']);
                if( $ja_cadastrado->count() ){
                    $this->setErrorMessage(Base_Message::ERROR_FORM, array('Usuário já convidade ou já cadastrado na plataforma.'));
                    $this->redirect('usuario', 'convidar-coach', 'site');                    
                    exit();
                }


                $post['codigo_convite'] = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 6 )  );
                
                $idLoginIndicado = $mLogin->salvar($post);
            

                $identity   = Zend_Auth::getInstance()->getIdentity();
                $idLogin    = $identity->lgn_id;
                $rsLogin    = $mLogin->find( $idLogin )->current();

                $arrIndicado = array("user_id"=>$idLogin, "coach_id"=>$idLoginIndicado);

                $mCoachIndicado = new Application_Model_DbTable_Base_CoachIndicado();
                $rCoachIndicado = $mCoachIndicado->salvar( $arrIndicado );


                $mSegmentoLogin = new Application_Model_DbTable_Base_SegmentoLogin();
                $rSegmentoLogin = $mSegmentoLogin->pesquisar( array('user_id'=> $idLogin) )->toArray();

                $life_coahing = '';
                $executive_coahing = '';

                if ( count($rSegmentoLogin) ) {
                    $key_life = array_search( 1 , array_column( $rSegmentoLogin, 'tipo_id'));
                    $key_executive = array_search( 2 , array_column( $rSegmentoLogin, 'tipo_id'));
                    if ( false !== $key_life ){ $life_coahing = 'Life Coaching'; }
                    if ( false !== $key_executive ){ $executive_coahing = ' :: Executive Coaching'; }
                }


                $html = '<table border="0" cellspacing="" cellspacing="" width="680" bgcolor="#2A2B1D" background="img_bg.jpg" align="center">
                    <tr>
                        <td align="center">
                            <a href="" style="outline:none; margin: 40px 0 50px 0; display:inline-block;">
                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/logo_bc.png" style="">
                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 50px; text-transform: uppercase; color: #fdda6f;">
                            parabéns
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 26px; text-transform: uppercase; color: #fdda6f; line-height: 26px;">
                            Você recebeu um convite de:
                        </td>
                    </tr>

                    <tr>
                        <td align="center">
                            <div style="width:150px;height:150px; overflow: hidden; border-radius: 50%;margin: 35px auto 10px auto;border: 4px solid #fdda6f;"><img src="http://'.$_SERVER['HTTP_HOST'].'/portal/uploads/usuario/avatar/'.$rsLogin ->lgn_avatar.'" style="margin: 0; width: 100%;"></div>
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 40px; color: #fdda6f; line-height: 40px;">
                            '.$rsLogin->lgn_nome.'
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 20px; color: #fdda6f; line-height: 26px;">
                            Coach em '.$life_coahing.$executive_coahing.'
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 39px; color: #fdda6f; line-height: 26px; padding: 40px 0 10px 0;">
                            sua senha de acesso
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <div style="border-radius: 5px; border: 3px solid #fdda6f; width: 90%; margin: 20px 5% 0 5%;">
                                <table border="0" cellspacing="" cellspacing="" width="100%">
                                    <tr>
                                        <td align="center" style="font-family:Arial; font-weight: 600; font-size: 28px; padding: 15px 0; color: #fdda6f; line-height: 18px;">
                                            '.$post['codigo_convite'].'
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>


                    <tr>
                        <td>
                            <div style="width: 90%; margin: 20px 5% 60px 5%;">
                                <table border="0" cellspacing="" cellspacing="" width="100%">
                                    <tr>
                                        <td align="center" style="padding: 15px 0; ">
                                            <a href="http://'.$_SERVER['HTTP_HOST'].'/usuario/cadastro-coach/codigo/'. $post['codigo_convite'] .'" style="display: inline-block; width: 100%; height: 60px; text-align: center; background-color: #FCD96F; border-radius: 4px; text-decoration: none; font-size: 22px; font-family:Arial; font-weight: 600; color: #2B2B1D; line-height: 60px;">CADASTRE-SE AGORA</a>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>                       
                    </tr>

                    <tr>
                        <td bgcolor="#222538">
                            <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                <tr>
                                    <td  style="text-align: center; font-size: 28px; font-family:Arial; font-weight: 600; color: #2961FD;">Não sabe o que é a Menttoo? </td>
                                </tr>

                                <tr>
                                    <td style="text-align: center; font-size: 22px; font-family:Arial; font-weight: 100; color: #2961FD;">Acesse o site e nossas redes e saiba mais:</td>
                                </tr>

                                <tr>
                                    <td style="text-align: center; font-size: 18px; font-family:Arial; font-weight: 100; color: #2961FD; padding: 50px 0 0 0;">www.menttoo.com</td>
                                </tr>

                                <tr>
                                    <td align="center" style="text-align: center;">
                                        <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                            <tr>
                                                <td align="center">
                                                    <a href="https://www.linkedin.com/company-beta/3589739/" style="outline:none; margin: 0 10px; display:inline-block;">
                                                        <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_linkedin_az.png" style="">
                                                    </a>
                                                </td>

                                                <td align="center">
                                                    <a href="https://www.facebook.com/menttoo/?fref=ts" style="outline:none; margin: 0 5px; display:inline-block; border-left: 1px solid #275BE5; border-right: 1px solid #275BE5; padding:0 14px;">
                                                        <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_facebook_az.png" style="">
                                                    </a>
                                                </td>
                                                <td align="center">
                                                    <a href="https://www.youtube.com/channel/UCY6ynwaxdfSC7e8SCTP4UTQ" style="outline:none; margin: 0 5px; display:inline-block;">
                                                        <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_youtube_az.png" style="">
                                                    </a>
                                                </td>
                                            </td>
                                        </table>
                                    </td>
                                </tr>

                            </table>

                        </td>
                    </tr>
                </table>';


                Base_Mail::mail(
                    $post['email'],
                    'menttoo::Convite para ser coach',
                    $html,
                    'menttoo', 
                    'contato@inmais.com.br'
                );   
                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Convite realizado com sucesso.'));
                $this->redirect('usuario', 'convidar-coach', 'site' );
            }else{
                $this->setErrorMessage(Base_Message::ERROR_FORM, array('Favor preencher todos os campos.'));
                $this->redirect('usuario', 'convidar-coach', 'site');
            }

            
        }else{
            $this->setErrorMessage(Base_Message::ERROR_FORM, array('Por favor, tente novamente mais tarde.'));
            $this->redirect('usuario', 'convidar-coach', 'site');            
        }

        exit();
    }

    public function perfisSalvosAction(){


        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $idLogin = $params["id"];
        }else if( Zend_Auth::getInstance()->hasIdentity() ) {  
            $dados = Zend_Auth::getInstance()->hasIdentity();
            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin     = $identity->lgn_id;
        }
        $mPerfisSalvo  = new Application_Model_DbTable_Base_PerfisSalvo();
        $rPerfisSalvo = $mPerfisSalvo->pesquisar(array("user_id"=>$idLogin));
        $this->view->perfis = $rPerfisSalvo;  

    }

    
    public function esqueciSenhaAction(){
        
    }       


    public function esqueciSenhaEnviarAction() {
     

        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        try {
            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();



                $mLogin  = new Application_Model_DbTable_Base_Login();
                $senha = $mLogin->recuperar_senha( $post["email"] );

              
                if ( $senha ) {
                    $mensagem = "<p>Senha Redefinida</p>";

                    $mensagem .= "<p>Nova senha: " . $senha . "</p>";

                    // Envia o e-mail de confirmação
                    // $destinatario = "jeffersonojm@gmail.com";
                    $destinatario = $post["email"];

                    // echo rand();
                    // echo "<br/>";
                    // Envia o e-mail de confirmação
                    Base_Mail::mail(
                        $destinatario,
                        'Redefinição de senha' ,
                        $mensagem,
                        'menttoo',
                        'menttoo@menttoo.com'
                    );     

                    $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Envio realizado com sucesso.'));
                    $this->redirect('usuario', 'esqueci-senha-positivo', 'site', array("email"=>$post["email"]));

                }else{
                    $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Envio realizado com sucesso.'));
                    $this->redirect('usuario', 'esqueci-senha-negativo', 'site');
                }

            } else {
                $this->redirect('usuario', 'esqueci-senha-negativo', 'site');
            }
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('form-cadastro-usuario', $this->getRequest()->getPost());
            if (isset($idLogin) && $idLogin) {
                $this->redirect('usuario', 'esqueci-senha-negativo', 'site');
            } else {
                $this->redirect('usuario', 'esqueci-senha-negativo', 'site');
            }
        }        
    }


    public function esqueciSenhaPositivoAction(){
        $this->view->params = $this->_request->getParams();
    }  

    public function esqueciSenhaNegativoAction(){
        $this->view->params = $this->_request->getParams();
    }          

    
    public function cadastroCoacheeAction(){
        // $this->redirect('index', 'index', 'site');
        // exit();
        $_SESSION["SOU"] = 'coachee';
    }

    public function cadastroCoacheeSalvarAction(){
    
        if ($this->_request->isPost()) {

            
            $post = $this->_request->getPost();


            $arrDadosPessoais['nome']       = $post['nome'];
            $arrDadosPessoais['email']      = $post['email'];
            $arrDadosPessoais['senha']      = $post['senha'];


            $mLogin        = new Application_Model_DbTable_Base_Login();
            $ja_cadastrado = $mLogin->findByEmail($post['email']);
            if( $ja_cadastrado->count() ){
                $this->setErrorMessage(Base_Message::ERROR_FORM, array('Usuário já cadastrado na plataforma.'));
                $this->redirect('usuario', 'cadastro-coachee', 'site');                    
                exit();
            }




            $idLogin       = $mLogin->salvar($arrDadosPessoais);

            // echo "<pre>";
            // print_r($post);
            // exit().
            // if ( $rsLogin ) {
            //     $rsLogin->lgn_senha = md5( $post["senha"] );
            //     $rsLogin->save();
            //     $idLogin = $rsLogin->lgn_id;

            //     // $mLogin->autenticar( array( "login"=>$post["email"],"senha"=>$post["senha"] ) );
            // }




                $html = '<table border="0" cellspacing="" cellspacing="" width="680" bgcolor="#2A2B1D" background="img_bg.jpg" align="center">
                    <tr>
                        <td align="center">
                            <a href="" style="outline:none; margin: 40px 0 50px 0; display:inline-block;">
                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/logo_bc.png" style="">
                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 50px; text-transform: uppercase; color: #03a9f4;">
                            parabéns
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 26px; text-transform: uppercase; color: #03a9f4; line-height: 26px;">
                            Você se cadastrou na menttoo, clique no link abaixo para validar sua conta:
                        </td>
                    </tr>





                    <tr>
                        <td>
                            <div style="width: 90%; margin: 20px 5% 60px 5%;">
                                <table border="0" cellspacing="" cellspacing="" width="100%">
                                    <tr>
                                        <td align="center" style="padding: 15px 0; ">
                                            <a href="http://'.$_SERVER['HTTP_HOST'].'/usuario/cadastro-coachee-validar-salvar/id/'. $idLogin .'" style="display: inline-block; width: 100%; height: 60px; text-align: center; background-color: #03a9f4; border-radius: 4px; text-decoration: none; font-size: 22px; font-family:Arial; font-weight: 600; color: #fff; line-height: 60px;">VALIDAR CADASTRO</a>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>                       
                    </tr>

                    <tr>
                        <td bgcolor="#222538">
                            <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                <tr>
                                    <td  style="text-align: center; font-size: 28px; font-family:Arial; font-weight: 600; color: #2961FD;">Não sabe o que é a Menttoo? </td>
                                </tr>

                                <tr>
                                    <td style="text-align: center; font-size: 22px; font-family:Arial; font-weight: 100; color: #2961FD;">Acesse o site e nossas redes e saiba mais:</td>
                                </tr>

                                <tr>
                                    <td style="text-align: center; font-size: 18px; font-family:Arial; font-weight: 100; color: #2961FD; padding: 50px 0 0 0;"><a href="http://www.menttoo.com">http://www.menttoo.com</a></td>
                                </tr>

                                <tr>
                                    <td align="center" style="text-align: center;">
                                        <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                            <tr>
                                                <td align="center">
                                                    <a href="https://www.linkedin.com/company-beta/3589739/" style="outline:none; margin: 0 10px; display:inline-block;">
                                                        <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_linkedin_az.png" style="">
                                                    </a>
                                                </td>

                                                <td align="center">
                                                    <a href="https://www.facebook.com/menttoo/?fref=ts" style="outline:none; margin: 0 5px; display:inline-block; border-left: 1px solid #275BE5; border-right: 1px solid #275BE5; padding:0 14px;">
                                                        <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_facebook_az.png" style="">
                                                    </a>
                                                </td>
                                                <td align="center">
                                                    <a href="https://www.youtube.com/channel/UCY6ynwaxdfSC7e8SCTP4UTQ" style="outline:none; margin: 0 5px; display:inline-block;">
                                                        <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_youtube_az.png" style="">
                                                    </a>
                                                </td>
                                            </td>
                                        </table>
                                    </td>
                                </tr>

                            </table>

                        </td>
                    </tr>
                </table>';


                Base_Mail::mail(
                    $post['email'],
                    'menttoo::Validar cadastro',
                    $html,
                    'menttoo', 
                    'contato@inmais.com.br'
                );   



            // $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Cadastro realizado com sucesso, favor completar o cadastro.'));
            $this->redirect('usuario', 'cadastro-coachee-validar', 'site', array('id' => $idLogin));  

            // echo "<pre>";
            // print_r( $arrDadosPessoais );
            // exit();

        }      
    }

    public function cadastroCoacheeValidarAction(){
        $params = $this->_request->getParams();

        if ( $params['id'] ) {
         
            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->getUsuario($params);
            $this->view->usuario = $rLogin;

            // echo "<pre>";
            // print_r( $rLogin );
            // exit();
        }
    }

    public function cadastroCoacheeValidarEnviarAction(){

        $params = $this->_request->getParams();

        if ( $params['id'] ) {
         
            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->find($params["id"])->current();
            $this->view->usuario = $rLogin;




                $html = '<table border="0" cellspacing="" cellspacing="" width="680" bgcolor="#2A2B1D" background="img_bg.jpg" align="center">
                    <tr>
                        <td align="center">
                            <a href="" style="outline:none; margin: 40px 0 50px 0; display:inline-block;">
                                <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/logo_bc.png" style="">
                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 700; font-size: 50px; text-transform: uppercase; color: #03a9f4;">
                            parabéns
                        </td>
                    </tr>

                    <tr>
                        <td align="center" style="font-family:Arial; font-weight: 100; font-size: 26px; text-transform: uppercase; color: #03a9f4; line-height: 26px;">
                            Você se cadastrou na menttoo, clique no link abaixo para validar sua conta:
                        </td>
                    </tr>





                    <tr>
                        <td>
                            <div style="width: 90%; margin: 20px 5% 60px 5%;">
                                <table border="0" cellspacing="" cellspacing="" width="100%">
                                    <tr>
                                        <td align="center" style="padding: 15px 0; ">
                                            <a href="http://'.$_SERVER['HTTP_HOST'].'/usuario/cadastro-coachee-validar-salvar/id/'. $params['id'] .'" style="display: inline-block; width: 100%; height: 60px; text-align: center; background-color: #03a9f4; border-radius: 4px; text-decoration: none; font-size: 22px; font-family:Arial; font-weight: 600; color: #fff; line-height: 60px;">VALIDAR CADASTRO</a>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>                       
                    </tr>

                    <tr>
                        <td bgcolor="#222538">
                            <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                <tr>
                                    <td  style="text-align: center; font-size: 28px; font-family:Arial; font-weight: 600; color: #2961FD;">Não sabe o que é a Menttoo? </td>
                                </tr>

                                <tr>
                                    <td style="text-align: center; font-size: 22px; font-family:Arial; font-weight: 100; color: #2961FD;">Acesse o site e nossas redes e saiba mais:</td>
                                </tr>

                                <tr>
                                    <td style="text-align: center; font-size: 18px; font-family:Arial; font-weight: 100; color: #2961FD; padding: 50px 0 0 0;"><a href="http://www.menttoo.com">http://www.menttoo.com</a></td>
                                </tr>

                                <tr>
                                    <td align="center" style="text-align: center;">
                                        <table border="0" cellspacing="" cellspacing="" style="margin-top: 10px; margin-bottom: 7px;" width="" align="center">
                                            <tr>
                                                <td align="center">
                                                    <a href="https://www.linkedin.com/company-beta/3589739/" style="outline:none; margin: 0 10px; display:inline-block;">
                                                        <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_linkedin_az.png" style="">
                                                    </a>
                                                </td>

                                                <td align="center">
                                                    <a href="https://www.facebook.com/menttoo/?fref=ts" style="outline:none; margin: 0 5px; display:inline-block; border-left: 1px solid #275BE5; border-right: 1px solid #275BE5; padding:0 14px;">
                                                        <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_facebook_az.png" style="">
                                                    </a>
                                                </td>
                                                <td align="center">
                                                    <a href="https://www.youtube.com/channel/UCY6ynwaxdfSC7e8SCTP4UTQ" style="outline:none; margin: 0 5px; display:inline-block;">
                                                        <img src="http://'.$_SERVER['HTTP_HOST'].'/portal/assets_site/images/img_youtube_az.png" style="">
                                                    </a>
                                                </td>
                                            </td>
                                        </table>
                                    </td>
                                </tr>

                            </table>

                        </td>
                    </tr>
                </table>';


                Base_Mail::mail(
                    $rLogin->lgn_email,
                    'menttoo::Validar cadastro',
                    $html,
                    'menttoo', 
                    'contato@inmais.com.br'
                );   

            // echo "<pre>";
            // print_r( $rLogin );
            // exit();
        }        

        $this->redirect('usuario', 'cadastro-coachee-validar', 'site', array('id' => $params['id']));          
    }

    public function cadastroCoacheeValidarSalvarAction(){
        
        $params = $this->_request->getParams();

        $mLogin        = new Application_Model_DbTable_Base_Login();
        $rsLogin       = $mLogin->find( $params['id'] )->current();

        if ( $rsLogin ) {
            $rsLogin->lgn_status = 'A';
            $rsLogin->save();
            $idLogin = $rsLogin->lgn_id;
            
            $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Cadastro validado, pode realizar o login.'));
            $this->redirect('login', 'index', 'site', array('sou' => "coachee") );    
        }        
    }



    public function cadastroCoacheeCompletarAction(){

        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $idLogin = $params["id"];
        }else if( Zend_Auth::getInstance()->hasIdentity() ) {  
            $dados = Zend_Auth::getInstance()->hasIdentity();
            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin     = $identity->lgn_id;

        }


        if( isset($idLogin) ){
            $mLogin = new Application_Model_DbTable_Base_Login();
            $rLogin = $mLogin->getUsuario(array("id"=>$idLogin));
            $this->view->usuario = $rLogin;            
        }            



        $mEstado = new Application_Model_DbTable_Base_Estado();
        $this->view->estados = $mEstado->combo();


        // echo "<pre>";
        // print_r( $rLogin);    
        $mSegmentoTipoCoach = new Application_Model_DbTable_Base_SegmentoTipoCoach();
        $rSegmentoLifeCoach = $mSegmentoTipoCoach->pesquisar(array("tipo_coach"=>1));
        $rSegmentoExecutive = $mSegmentoTipoCoach->pesquisar(array("tipo_coach"=>2));            

        $this->view->seg_life = $rSegmentoLifeCoach;
        $this->view->seg_executive = $rSegmentoExecutive;   
   
    }


    public function isUniqueEmailAction(){
        $params = $this->_request->getParams();

        $mLogin = new Application_Model_DbTable_Base_Login();
        $rLogin = $mLogin->getUsuario($params);
        if ( count($rLogin) ) {
             echo "1";
         }else{
            echo "0";
         } 

        // print_r( $rLogin );
        // exit();

        exit();
    }

    public function excluirContaAction(){
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();        

        if( Zend_Auth::getInstance()->hasIdentity() ) {  
            $dados = Zend_Auth::getInstance()->hasIdentity();
            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin     = $identity->lgn_id;
        }


        if (isset($idLogin)) {
            $mLogin = new Application_Model_DbTable_Base_Login();
            $mLogin->delete( "lgn_id=" . $idLogin );

            $mLogin->sair();

            $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Conta excluida com sucesso.'));
            $this->redirect('index', 'index', 'site' );

        }else{
            $this->setErrorMessage(Base_Message::ERROR_FORM, array('Erro ao submeter o formulário.'));
            $this->redirect('usuario', 'perfil-editar', 'site' );            
        }         
    }



    public function cancelarSolicitacaoAction(){

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

        $params = $this->_request->getParams();
        if (isset($params['id']) ) {
            $mCoaching  = new Application_Model_DbTable_Base_Coaching();
            $rSolicitacao = $mCoaching->find( $params["id"] )->current();
            $rSolicitacao->delete();

            $coaching_id = $params["id"];

            $mNotificacoes  = new Application_Model_DbTable_Base_Notificacoes();
            $rNotificacoes = $mNotificacoes->delete("coaching_id='$coaching_id'");

            $this->redirect('usuario', 'meus-coachees', 'site' );   
        }

    } 


}


