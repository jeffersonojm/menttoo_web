<?php
class Site_LoginController extends Base_Controller_Site
{
    public function indexAction(){
    	$params = $this->_request->getParams();
    	$_SESSION["SOU"] = $params["sou"];
    }


    public function loginAction(){
    }


	public function autenticarAction(){
        try {
            if ($this->_request->isPost()) {
                $post = $this->getRequest()->getPost();

                $mLogin = new Application_Model_DbTable_Base_Login();
                $user   = $mLogin->autenticar($post);
                // $this->redirect('login', 'home', 'site');
                if ( !$user) {

                    $mLogin = new Application_Model_DbTable_Base_Login();
                    $rLogin = $mLogin->getUsuario(array("email"=>$post["login"]));
                    
                    if ( count( $rLogin ) ) {
                        if ( $rLogin["lgn_status"] == "S" ) {
                            $this->setErrorMessage(Base_Message::ERROR_FORM, array( 'Seu login ainda não foi validado, favor verificar seu e-mail.' ));
                            $this->redirect('login', 'index', 'site', array("sou"=>$_SESSION["SOU"] ));
                        }else if( $rLogin["lgn_status"] == "A" ){
                            $this->setErrorMessage(Base_Message::ERROR_FORM, array( 'Algum erro com seu usuario de acesso, favor contactar o Administrador.' ));
                            $this->redirect('login', 'index', 'site', array("sou"=>$_SESSION["SOU"] ));
                        }else{
                            $this->setErrorMessage(Base_Message::ERROR_FORM, array( 'Erro ao logar, favor contactar o Administrador.' ));
                            $this->redirect('login', 'index', 'site', array("sou"=>$_SESSION["SOU"] ));                            
                        }
                    }else{
                        $this->setErrorMessage(Base_Message::ERROR_FORM, array( 'Login inválido.' ));
                        $this->redirect('login', 'index', 'site', array("sou"=>$_SESSION["SOU"] ));                         
                    }
                    

                }else{
                	// if ( $user->perfil = 'coach' ) {
                	// 	$this->redirect('usuario', 'meus-coachees', 'site'));
                	// }
                	if ( $user->perfil == 'coachee' ) {
                        if( $user->lgn_cadastro_completo){
                            $this->redirect('busca', 'index', 'site');
                        }else{
                            $this->redirect('usuario', 'cadastro-coachee-completar', 'site', array("id"=>$user->lgn_id ));
                        }
                		
                	}else{
                		$this->redirect('usuario', 'meus-coachees', 'site');
                	}
                }


                // echo "<pre>";
                // print_r( $user );
                exit();

            } else {
                $this->redirect('login', 'index', 'site', array("sou"=>$_SESSION["SOU"] ));
            }
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('form-login', $this->getRequest()->getPost(), array('senha', 'captcha', 'cid'));
            $this->redirect('index', 'index', 'admin');
        }
    }

    public function linkedinAction(){

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

        $config['base_url']             =   "http://".$_SERVER['HTTP_HOST']."/gogoals/login/linkedin";
        $config['callback_url']         =   "http://".$_SERVER['HTTP_HOST']."/gogoals/login/linkedin-callBack";
        $config['linkedin_access']      =   '78hqpg4cnscb88';
        $config['linkedin_secret']      =   'ul2ugUhZs4MAo2Sm';

        include_once "LinkedinLogin/linkedin.php";

        # First step is to initialize with your consumer key and secret. We'll use an out-of-band oauth_callback
        $linkedin = new LinkedIn($config['linkedin_access'], $config['linkedin_secret'], $config['callback_url'] );
        //$linkedin->debug = true;

        # Now we retrieve a request token. It will be set as $linkedin->request_token
        $linkedin->getRequestToken();
        $_SESSION['requestToken'] = serialize($linkedin->request_token);
      
        # With a request token in hand, we can generate an authorization URL, which we'll direct the user to
        // echo "Authorization URL: " . $linkedin->generateAuthorizeUrl() . "\n\n";
        header("Location: " . $linkedin->generateAuthorizeUrl());
    }    


    public function linkedinCallbackAction(){

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

        $config['base_url']             =   "http://".$_SERVER['HTTP_HOST']."/gogoals/login/linkedin";
        $config['callback_url']         =   "http://".$_SERVER['HTTP_HOST']."/gogoals/login/linkedin-callBack";
        $config['linkedin_access']      =   '78hqpg4cnscb88';
        $config['linkedin_secret']      =   'ul2ugUhZs4MAo2Sm';

        include_once "LinkedinLogin/linkedin.php";
       
        
        # First step is to initialize with your consumer key and secret. We'll use an out-of-band oauth_callback
        $linkedin = new LinkedIn($config['linkedin_access'], $config['linkedin_secret'], $config['callback_url'] );
        //$linkedin->debug = true;

       if (isset($_REQUEST['oauth_verifier'])){
            $_SESSION['oauth_verifier']     = $_REQUEST['oauth_verifier'];

            $linkedin->request_token    =   unserialize($_SESSION['requestToken']);
            $linkedin->oauth_verifier   =   $_SESSION['oauth_verifier'];
            $linkedin->getAccessToken($_REQUEST['oauth_verifier']);

            $_SESSION['oauth_access_token'] = serialize($linkedin->access_token);
            header("Location: " . $config['callback_url']);
            exit;
       }else{
            $linkedin->request_token    =   unserialize($_SESSION['requestToken']);
            $linkedin->oauth_verifier   =   $_SESSION['oauth_verifier'];
            $linkedin->access_token     =   unserialize($_SESSION['oauth_access_token']);
       }


        # You now have a $linkedin->access_token and can make calls on behalf of the current member
        $xml_response = $linkedin->getProfile("~:(id,email-address,first-name,last-name,location,picture-url,public-profile-url,formatted-name,specialties)");
        $xml2 = simplexml_load_string($xml_response);
        
        // echo '<pre>';
        $arrDadosPessoais = array();
        foreach ($xml2 as $key => $value) {
            if ( $key == "status" and $value==404) {
                $this->setErrorMessage(Base_Message::ERROR_FORM, array( 'Login inválido.' ));
                $this->redirect('login', 'index', 'site');
                break;
            }else{
                $value = (string) $value;
                // echo "item: " . $key ." : ". $value . "<br />";    
                if ( $key == "formatted-name" ) { $arrDadosPessoais['nome'] = $value; }
                if ( $key == "email-address" ) { $arrDadosPessoais['email'] = $value; }

                if ( $key == "picture-url" ) { 
                    $uploadPathDiploma = PUBLIC_PATH . '/portal/uploads/usuario/avatar/';
                    // Your file
                    $file = $value;
                    // Open the file to get existing content
                    $data = file_get_contents($file);
                    // New file
                    // $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                    $nomeArquivo = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.jpg';
                    $filePath    = $uploadPathDiploma . $nomeArquivo;

                    $new = $filePath;
                    // Write the contents back to a new file
                    file_put_contents($new, $data);


                    $arrDadosPessoais['avatar'] = $nomeArquivo;
                }
            }
            
        }

        if ( count( $arrDadosPessoais ) ) {

            if (isset($arrDadosPessoais['email'])) {
                

                $mLogin        = new Application_Model_DbTable_Base_Login();

                $rLogin = $mLogin->pesquisar(array("email"=>$arrDadosPessoais['email']));


                if( (int)$rLogin->count() ){
                    // echo "o efetua o login";
                    $user   = $mLogin->autenticar_redes(array(
                                                            "login"=>$arrDadosPessoais['email'],
                                                            "senha"=>"ttoocript_redes_134251"
                                                            )
                                                        );
                }else{
                    // echo "efetua o cadastro";
                    $arrDadosPessoais['origem_cadastro'] = 1;
                    $arrDadosPessoais['status'] = "A";
                    $arrDadosPessoais['senha_redes'] = "ttoocript_redes_134251";
                    $idLogin       = $mLogin->salvar($arrDadosPessoais);    

                    $user   = $mLogin->autenticar_redes(array(
                                                            "login"=>$arrDadosPessoais['email'],
                                                            "senha"=>$arrDadosPessoais['senha_redes']
                                                            )
                                                        );                    
                }

                // echo "<pre>";
                // print_r($arrDadosPessoais);
                // print_r($user);
                // exit();

                $this->redirect('busca', 'index', 'site');
                
            }else{
                $this->setErrorMessage(Base_Message::ERROR_FORM, array( 'Erro ao recuperar o e-mail.' ));
                $this->redirect('login', 'index', 'site', array("sou"=>$_SESSION["SOU"] ));                    
            }
        }else{
            $this->setErrorMessage(Base_Message::ERROR_FORM, array( 'Erro ao recuperar os dados.' ));
            $this->redirect('login', 'index', 'site', array("sou"=>$_SESSION["SOU"] ));                                     
        }

        exit();        

    }


    public function facebookCallbackAction(){
        

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

        $params = $this->_request->getParams();

        if (isset($params['email']) and $params['email'] ) {

            $mLogin        = new Application_Model_DbTable_Base_Login();

            $rLogin = $mLogin->pesquisar(array("email"=>$params['email']));


            if( (int)$rLogin->count() ){
                // echo "o efetua o login";
                $user   = $mLogin->autenticar_redes(array(
                                                        "login"=>$params['email'],
                                                        "senha"=>"ttoocript_redes_134251"
                                                        )
                                                    );
            }else{
                // echo "efetua o cadastro";
                $params['origem_cadastro'] = 2;
                $params['status'] = "A";
                $params['senha_redes'] = "ttoocript_redes_134251";

                // if(  $params['avatar'] ){

                //     $uploadPathDiploma = PUBLIC_PATH . '/portal/uploads/usuario/avatar/';
                //     // Your file
                //     $file = $params['avatar'];
                //     // Open the file to get existing content
                //     $data = file_get_contents($file);
                //     // New file
                //     // $extensaoArquivo      = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                //     $nomeArquivo = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.jpg';
                //     $filePath    = $uploadPathDiploma . $nomeArquivo;

                //     $new = $filePath;
                //     // Write the contents back to a new file
                //     file_put_contents($new, $data);

                //     $params['avatar'] = $nomeArquivo;
                
                // }

                $idLogin       = $mLogin->salvar($params);    

                $user   = $mLogin->autenticar_redes(array(
                                                        "login"=>$params['email'],
                                                        "senha"=>$params['senha_redes']
                                                        )
                                                    );                    
            }

            // echo "<pre>";
            // print_r($arrDadosPessoais);
            // print_r($user);
            // exit();

            // $this->redirect('busca', 'index', 'site');
            echo "1"; 
            exit();
        }else{
            $this->setErrorMessage(Base_Message::ERROR_FORM, array( 'Erro ao recuperar o e-mail.' ));
            echo "0"; 
            exit();
        }
        echo "0"; 
        exit();
        
    }


    public function sairAction(){
        $mLogin                = new Application_Model_DbTable_Base_Login();
        $mLogin->sair();
        // $this->setSuccessMessage(Base_Message::SUCCESS_LOGOUT, array(Base_Message::SUCCESS_USUARIO_SAIU));
        $this->redirect('login', 'login', 'site');
    }    





}



                
