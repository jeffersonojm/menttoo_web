<?php
class Site_IndexController extends Base_Controller_Site
{
    public function indexAction(){
        $this->_helper->layout()->disableLayout();
    }

    public function index2Action(){
        $this->_helper->layout()->disableLayout();
    }

    public function sessaoExpiradaAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $perfil = "coach"; 
        // echo "string";
        // exit();
        $identity   = Zend_Auth::getInstance()->getIdentity();
        $perfil = $identity->perfil; 
		Zend_Auth::getInstance()->clearIdentity();
        
        $this->setSuccessMessage(Base_Message::SUCCESS_LOGOUT, array('Seu usuário foi desconectado devido ao tempo de inatividade.'));
        $this->redirect('login', 'index', 'site', array("sou"=>$perfil));
    }

    public function semAcessoAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        
        
        $this->setSuccessMessage(Base_Message::SUCCESS_LOGOUT, array('Area restrita.'));
        $this->redirect('index', 'index', 'site');
    }

}



