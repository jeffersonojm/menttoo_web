<?php
class Site_ConfiguracoesController extends Base_Controller_Site
{

    
    public function indexAction()
    {


        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $idLogin = $params["id"];
        }else if( Zend_Auth::getInstance()->hasIdentity() ) {  
            $dados = Zend_Auth::getInstance()->hasIdentity();
            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin     = $identity->lgn_id;
        }


        $mLogin  = new Application_Model_DbTable_Base_Login();
        $rUsuario = $mLogin->find( $idLogin )->current();
        $this->view->usuario = $rUsuario;
        
    }

    public function alterarSenhaAction()
    {

        $params                  = $this->_request->getParams();
        if( isset($params["id"]) and $params["id"] ){
            $idLogin = $params["id"];
        }else if( Zend_Auth::getInstance()->hasIdentity() ) {  
            $dados = Zend_Auth::getInstance()->hasIdentity();
            $identity   = Zend_Auth::getInstance()->getIdentity();
            $idLogin     = $identity->lgn_id;
        }

        $mLogin  = new Application_Model_DbTable_Base_Login();
        $rUsuario = $mLogin->find( $idLogin )->current();
        $this->view->usuario = $rUsuario;
        
    }

    public function alterarSenhaSalvarAction()
    {

        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();


        try {

            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();


                if( isset($post["id"]) and $post["id"] ){
                    $idLogin = $post["id"];
                }else if( Zend_Auth::getInstance()->hasIdentity() ) {  
                    $dados = Zend_Auth::getInstance()->hasIdentity();
                    $identity   = Zend_Auth::getInstance()->getIdentity();
                    $idLogin     = $identity->lgn_id;
                }
                
                $mLogin  = new Application_Model_DbTable_Base_Login();
                $rUsuario = $mLogin->find( $idLogin )->current();
                $dados = $this->view->usuario = $rUsuario;


                if( (int)$dados->lgn_origem_cadastro ){
                    $senha_atual_bd = $dados->lgn_senha_redes;
                    $senha_form = md5("ttoocript_redes_134251");
                }else{
                    $senha_atual_bd = $dados->lgn_senha;
                    $senha_form = md5($post["senha_atual"]);
                }


                if( $senha_atual_bd != $senha_form ){

                    $this->setErrorMessage(Base_Message::ERROR_FORM, array('Senha atual inválida.'));
                    $this->redirect('configuracoes', 'alterar-senha', 'site', array( "id"=>$post["id"] ));

                }else if( $post["senha"] != $post["confirm_senha"] ){

                    $this->setErrorMessage(Base_Message::ERROR_FORM, array('Confirmação de senha não confere.'));
                    $this->redirect('configuracoes', 'alterar-senha', 'site', array( "id"=>$post["id"] ));

                }else{

                    $post['lgn_data_senha'] = date("Y-m-d H:i:s");

                    $mLogin->salvar($post);

                    $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Cadastro realizado com sucesso.'));
                    $this->redirect('configuracoes', 'alterar-senha', 'site', array( "id"=>$post["id"] ));

                }
                

            } else {
                
                $this->setErrorMessage(Base_Message::ERROR_FORM, array('Ocirreu um erro'));
                $this->redirect('configuracoes', 'alterar-senha', 'site', array( "id"=>$post["id"] ));

            }

        } catch (Base_Exception $e) {
            
            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            $this->redirect('configuracoes', 'alterar-senha', 'site', array( "id"=>$post["id"] ));

        }
        
    }

    public function contasVinculadasAction()
    {
        
    }

    public function notificacoesEmailAction()
    {
        
        $params = $this->_request->getParams();
        $mLogin  = new Application_Model_DbTable_Base_Login();
        $rUsuario = $mLogin->find( $params["id"] )->current();
        $this->view->usuario = $rUsuario;

        $lgn_id = $this->view->usuario->lgn_id;


        $mConfiguracoes  = new Application_Model_DbTable_Base_Configuracoes();
        $rConfiguracoes = $mConfiguracoes->readOne($lgn_id);
        $this->view->configuracoes = $rConfiguracoes;

    }

    public function notificacoesEmailSalvarAction()
    {

        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();



        try {

            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();
                
             
                if( $post['nova_mensagem'] == 'true' ){             $post['nova_mensagem'] = 1; }else{          $post['nova_mensagem'] = 0; }
                if( $post['novo_mentor_plataforma'] == 'true' ){    $post['novo_mentor_plataforma'] = 1; }else{ $post['novo_mentor_plataforma'] = 0; }
                if( $post['atualizacao_menttoo'] == 'true' ){       $post['atualizacao_menttoo'] = 1; }else{    $post['atualizacao_menttoo'] = 0; }
                if( $post['encerramento_mentoria'] == 'true' ){     $post['encerramento_mentoria'] = 1; }else{  $post['encerramento_mentoria'] = 0; }


                $identity       = Zend_Auth::getInstance()->getIdentity();
                $idLogin        = $identity->lgn_id;
                $post['lgn_id'] = $idLogin;

                $post['data_alteracao'] = date("Y-m-d H:i:s");

                $mLogin  = new Application_Model_DbTable_Base_Configuracoes();
                $mLogin->delete( "lgn_id='$idLogin'" );
                $mLogin->salvar($post);

                echo '1';

                //$this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Alterado com sucesso.'));
                //$this->redirect('configuracoes', 'notificacoes-email', 'site', array( "id"=>$post["lgn_id"] ));


            } else {

                echo '0';
                
                //$this->setErrorMessage(Base_Message::ERROR_FORM, array('Ocirreu um erro'));
                //$this->redirect('configuracoes', 'notificacoes-email', 'site', array( "id"=>$post["lgn_id"] ));

            }

        } catch (Base_Exception $e) {
            
            echo '0';

            //$this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            //$this->redirect('configuracoes', 'notificacoes-email', 'site', array( "id"=>$post["lgn_id"] ));

        }
        
    }

}



