<?php
class Site_ContatoController extends Base_Controller_Site
{
    public function indexAction(){
	        if( isset($params["id"]) and $params["id"] ){
	            $idLogin = $params["id"];
	        }else if( Zend_Auth::getInstance()->hasIdentity() ) {  
	            $dados = Zend_Auth::getInstance()->hasIdentity();
	            $identity   = Zend_Auth::getInstance()->getIdentity();
	            $idLogin    = $identity->lgn_id;
	        }

	        $mLogin = new Application_Model_DbTable_Base_Login();
	        $rLogin = $mLogin->find( $idLogin )->current();

	        $this->view->usuario = $rLogin;
    }   

    public function enviarAction(){

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

		if ($this->_request->isPost()) {

			$post = $this->_request->getPost();

			// echo "<pre>";
			// print_r($post);
			// exit();

	        if( isset($params["id"]) and $params["id"] ){
	            $idLogin = $params["id"];
	        }else if( Zend_Auth::getInstance()->hasIdentity() ) {  
	            $dados = Zend_Auth::getInstance()->hasIdentity();
	            $identity   = Zend_Auth::getInstance()->getIdentity();
	            $idLogin    = $identity->lgn_id;
	        }

	        $mLogin = new Application_Model_DbTable_Base_Login();
	        $rLogin = $mLogin->find( $idLogin )->current();

	        $mensagem = "<p>Nome:" . $post['nome'] . "</p>";
	        $mensagem .= "<p>E-mail:" . $post['email'] . "</p>";
	        $mensagem .= "<p>Mensagem:" . $post['mensagem'] . "</p>";

	        $mensagem .= "<p>Link perfil: <a href='http://".$_SERVER['HTTP_HOST']."/usuario/perfil/id/". $rLogin->lgn_id . "'>clique aqui</a></p>";


	        Base_Mail::mail(
	            'contato@menttoo.com',
	            'menttoo::FeedBack',
	            $mensagem,
	            'menttoo', 
	            'contato@inmais.com.br'
	        );   

	    }

        $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('Mensagem enviada com sucesso!'));
        $this->redirect('contato', 'index', 'site');  


    }   

}



