<?php
class Site_PerguntasController extends Base_Controller_Site
{
    public function indexAction(){
    }

}



