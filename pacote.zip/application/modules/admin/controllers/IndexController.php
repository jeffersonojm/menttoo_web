<?php

class Admin_IndexController extends Base_Controller_Admin
{
    public function indexAction()
    {
        $this->_helper->layout()->disableLayout();
        if (Zend_Auth::getInstance()->getIdentity() != null) {
            $this->redirect('index', 'home', 'admin');
        }
    }


    public function homeAction()
    {
        // $mMarcado  = new Application_Model_DbTable_Base_Marcado();   
        // $total_registros = $mMarcado->getTotalRegistros()->current();        
        // $this->view->total_registros = $total_registros->quantidade;

        // $total_registros_validados = $mMarcado->getTotalRegistrosValidados()->current();        
        // $this->view->total_registros_validados = $total_registros_validados->quantidade;
    }

    public function acessoAction()
    {
    }

    public function sessaoExpiradaAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $this->setSuccessMessage(Base_Message::SUCCESS_LOGOUT, array('Seu usuário foi desconectado devido ao tempo de inatividade.'));
        $this->redirect('index', 'index', 'admin');
    }

    public function loginAction()
    {
        try {
            if ($this->_request->isPost()) {
                $post = $this->getRequest()->getPost();
                if (APPLICATION_ENV != 'development') {
                    $capId      = trim($post['cid']);
                    $capSession = new Zend_Session_Namespace('Zend_Form_Captcha_' . $capId);
                    if ($post['captcha'] == $capSession->word) {
                        $mLogin = new Application_Model_DbTable_Base_Login();
                        $user   = $mLogin->autenticar($post, 'admin');
                        // $this->setInfoMessage(
                        //     'Sistema de demandas.',
                        //     array('Login efetuado com sucesso.')
                        // );
                        $this->redirect('index', 'home', 'admin');
                    } else {
                        Base_Exception::throwError('A "Frase de segurança" está incorreta.');
                    }
                } else {
                    $mLogin = new Application_Model_DbTable_Base_Login();
                    $user   = $mLogin->autenticar($post);
                    // $this->setInfoMessage(
                    //         'Sistema de demandas.',
                    //         array('Login efetuado com sucesso.')
                    // );
                    $this->redirect('index', 'home', 'admin');
                }
            } else {
                $this->redirect('index', 'index', 'admin');
            }
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('form-login', $this->getRequest()->getPost(), array('senha', 'captcha', 'cid'));
            $this->redirect('index', 'index', 'admin');
        }
    }

}
