<?php

class Admin_LoginController extends Base_Controller_Admin
{
    public function indexAction()
    {
        $mLogin               = new Application_Model_DbTable_Base_Login();
        $params               = $this->_request->getParams();
        $rsLogin              = $mLogin->pesquisar($params);
        $page                 = $this->_getParam('pagina', 1);
        $paginator            = Zend_Paginator::factory($rsLogin);
        $paginator->setItemCountPerPage(30);
        $paginator->setCurrentPageNumber($page);
        $paginator->setPageRange(5);
        $this->view->usuarios = $paginator;
        $this->view->pesquisa = $params;
    }


    public function cadastroAction()
    {
        $mLoginPerfil            = new Application_Model_DbTable_Base_LoginPerfil();
        $this->view->comboPerfil = $mLoginPerfil->comboSelect('lgp_nome');


        //empreendimentos
        // $mEmpreendimentos            = new Application_Model_DbTable_Base_Empreendimentos();
        // $this->view->comboEmpreendimentos = $mEmpreendimentos->lista();


        // $this->view->comboSexo = $this->comboSexo();
        // $this->view->comboEstadoCivil = $this->comboEstadoCivil();
        // $mEstados                 = new Application_Model_DbTable_Base_Estados();
        // $this->view->comboEstados = $mEstados->comboSelect('est_nome','Selecione');  
        // $mAssociado                 = new Application_Model_DbTable_Base_Associado();
        // $this->view->comboAssociado = $mAssociado->comboSelectAtivo('ass_sigla',array(),'ass_status');
        $params                  = $this->_request->getParams();
        if (isset($params['id'])) {
            $mLogin              = new Application_Model_DbTable_Base_Login();
            $params              = $mLogin->filtrar($params);
            $this->view->usuario = $mLogin->find($params['id'])->current();

            // Verifica se o item não foi removido
            if($this->view->usuario->lgn_status == 'R'){
                $this->setErrorMessage(Base_Message::ERROR_FORM, array('Usuário removido.'));
                $this->redirect('login', 'index', 'admin');
                // echo "entrou";
                exit();
            }
        }
    }

    public function salvarAction()
    {
        try {
            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();


                if (isset($post['id']) && $post['id']) {
                    $idLogin = $post['id'];
                }
                $mLogin  = new Application_Model_DbTable_Base_Login();
                $idLogin = $mLogin->salvar($post);

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('O usuário foi atualizado.'));
                $this->redirect('login', 'cadastro', 'admin', array('id' => $idLogin));
            } else {
                $this->redirect('login', 'index', 'admin');
            }
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('form-login', $this->getRequest()->getPost());
            if (isset($idLogin) && $idLogin) {
                $this->redirect('login', 'cadastro', 'admin', array('id' => $idLogin));
            } else {
                $this->redirect('login', 'cadastro', 'admin');
            }
        }
    }

    public function excluirAction()
    {
        try {
            $params = $this->_request->getParams();
            if (isset($params['id'])) {
                $mLogin = new Application_Model_DbTable_Base_Login();
                $mLogin->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('O usuário foi excluído.'));
            }
            $this->redirect('login', 'index', 'admin');
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('login', 'index', 'admin');
        }
    }

    public function sairAction(){
        $mLogin                = new Application_Model_DbTable_Base_Login();
        $mLogin->sair();
        $this->setSuccessMessage(Base_Message::SUCCESS_LOGOUT, array(Base_Message::SUCCESS_USUARIO_SAIU));
        $this->redirect('index', 'index', 'admin');
    }
}
