<?php

class Admin_SolicitacaoController extends Base_Controller_Admin
{

    public function indexAction()
    {
        $mSolicitacao         = new Application_Model_DbTable_Base_Solicitacao();
        $params               = $this->_request->getParams();
        $rsSolicitacao        = $mSolicitacao->getSelect($params);
        $page                 = $this->_getParam('pagina', 1);
        $paginator            = Zend_Paginator::factory($rsSolicitacao);
        $paginator->setItemCountPerPage(10);
        $paginator->setCurrentPageNumber($page);
        $paginator->setPageRange(5);
        $this->view->solicitacao = $paginator;
        $this->view->pesquisa = $params;     
    }    

    public function termoAceiteAction(){

    }


    public function cadastroAction()
    {

        $params                  = $this->_request->getParams();

        if ( (isset($params['termo']) && $params['termo'] == "sim") or isset($params['id']) ) {

            $identity = Zend_Auth::getInstance()->getIdentity();
            // echo "<pre>";
            // print_r($identity);
         //    exit();
            // if (isset($identity)) {
            //     $this->view->idUsuario   = $identity->lgn_id;
            //     $this->view->nomeUsuario   = $identity->lgn_nome;
            //     $this->view->perfilUsuario = $identity->lgn_lgp_id;
            //  lgn_telefone
            //  lgn_celular
            //  lgn_telefone
            //  lgn_celular    
            // }


            $this->view->idUsuario = $identity->lgn_id;
            $this->view->nomeUsuario = $identity->lgn_nome;
            $this->view->telefoneUsuario = $identity->lgn_telefone;
            $this->view->celularUsuario = $identity->lgn_celular;

            if (isset($identity)) {
                $mEmpreendimentos = new Application_Model_DbTable_Base_Empreendimentos();
                $this->view->comboEmpreendimentos = $mEmpreendimentos->lista_user();            
            }


            
            if (isset($params['id'])) {
                $mSolicitacao              = new Application_Model_DbTable_Base_Solicitacao();
                $this->view->solicitacao = $mSolicitacao->find($params['id'])->current();

                $mLogin             = new Application_Model_DbTable_Base_Login();
                $this->view->user   = $mLogin->find( $this->view->solicitacao->id_user )->current();

                $mUnidades = new Application_Model_DbTable_Base_Unidades();
                $this->view->comboUnidades = $mUnidades->lista( $this->view->solicitacao->id_empreendimento );            

                $mArquivos = new Application_Model_DbTable_Base_Arquivos();
                $this->view->arquivos = $mArquivos->lista( $this->view->solicitacao->id );


                $this->view->idUsuario = $this->view->user->lgn_id;
                $this->view->nomeUsuario = $this->view->user->lgn_nome;
                $this->view->telefoneUsuario = $this->view->user->lgn_telefone;
                $this->view->celularUsuario = $this->view->user->lgn_celular;

                // echo "<pre>";
                // print_r($this->view->comboUnidades);
                // exit();

            }



        }else{
            $this->setErrorMessage(Base_Message::ERROR_FORM, array('Realize o aceite do termo de aceitação abaixo para realizar o cadastro.'));
            $this->redirect('solicitacao', 'termo-aceite', 'admin', array('id' => $idSolicitacao));
        }






    }    

    public function visualizarAction()
    {

        $params                  = $this->_request->getParams();
        if (isset($params['demanda'])) {
            $mSolicitacao              = new Application_Model_DbTable_Base_Solicitacao();
            $this->view->solicitacao = $mSolicitacao->find($params['demanda'])->current();

            $mLogin             = new Application_Model_DbTable_Base_Login();
            $this->view->user   = $mLogin->find( $this->view->solicitacao->id_user )->current();

            $mEmpreendimentos   = new Application_Model_DbTable_Base_Empreendimentos();
            $this->view->empreendimento   = $mEmpreendimentos->find( $this->view->solicitacao->id_empreendimento )->current();


            $mUnidades = new Application_Model_DbTable_Base_Unidades();
            $this->view->unidade   = $mUnidades->find( $this->view->solicitacao->id_unidade )->current();          


            $mArquivos = new Application_Model_DbTable_Base_Arquivos();
            $this->view->arquivos = $mArquivos->lista( $this->view->solicitacao->id );


            // consultar soliciatação no mobuss

            $url = 'https://dev2.mobuss.com.br/ccweb/rest/v1/assistencia/solicitacao/consultar';
            $json = '{"idMobuss": "'.$this->view->solicitacao->id_mobuss.'"}';

            $opts = array(
                'http' => array(
                    'method' => 'POST',
                    // Conteúdo em JSON
                    'header' => "Content-type: application/json\r\n" .
                        // Formato UTF-8
                        "charset: utf-8\r\n" .
                        // Identificador da empresa
                        "companyID: ACTKUAS0TVUN\r\n" .
                        // Token de autenticação do usuário
                        "token: 2076437e-8127-4eb9-8d0e-6e96204bcbf6\r\n",
                    'content' => $json
                )
            );

            $context = stream_context_create($opts);
            $fp = fopen($url, 'r', false, $context);
            $result = json_decode(stream_get_contents($fp) );

            $this->view->motivo = "";
            $status = "";

            if( isset($result->solicitacaoAtendimento->situacao) ){
                $status = $result->solicitacaoAtendimento->situacao;
                if( isset($result->solicitacaoAtendimento->diagnostico) ){
                    $this->view->motivo = $result->solicitacaoAtendimento->diagnostico;
                }
            }else if( isset($result->preSolicitacaoAtendimento->situacao) ){
                $status = $result->preSolicitacaoAtendimento->situacao;
            }
            
            if ($status=='Pendente' or $status=='Integrada'  or $status=='Aberta' ) {
                $this->view->status = 'Aberta';
            }

            if ($status=='Andamento' ) {
                $this->view->status = 'Andamento';
            }

            if ($status=='Resolvida' ) {
                $this->view->status = 'Resolvida';
            }


            if ($status=='Descartada' or $status=='Encerrada' ) {
                $this->view->status = 'Encerrada';
            }
             


            // echo "<pre>";
            // print_r( $this->view->solicitacao );
            // exit();

        }

    }   

    public function salvarAction()
    {

        try {
            
            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();

                $post["protocolo"] = substr(str_shuffle(str_repeat('0123456789',8)),0,8);;
                $mSolicitacao = new Application_Model_DbTable_Base_Solicitacao();
                $idSolicitacao = $mSolicitacao->salvar($post);
                
                $rSolicitacao = $mSolicitacao->find($idSolicitacao)->current();
                
                $select = $mSolicitacao->getSelect(array("id"=>$idSolicitacao));
                $rsSolicitacao = $mSolicitacao->fetchAll($select)->current();


                // inicio - arquivo
                $files      = new Zend_File_Transfer_Adapter_Http();
                $filesInfo  = $files->getFileInfo();                

                $uploadPath = PUBLIC_PATH . '/portal/uploads/solicitacao/';
                if (!file_exists($uploadPath)) {
                    if (!mkdir($uploadPath, 0777, true)) {
                        Base_Exception::throwError('Ocorreu um erro ao realizar o upload do arquivo.');
                    }
                    chmod($uploadPath, 0777);
                }

                foreach ($filesInfo as $fieldname => $fileinfo) {

                    if ( substr($fieldname,0,6) == 'imagem' && $fileinfo['name'] != '') {

                        $extensaoArquivo       = pathinfo($fileinfo['name'], PATHINFO_EXTENSION);
                        $nomeArquivo           = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  ) . '.' . $extensaoArquivo;
                        $filePath              = $uploadPath . $nomeArquivo;
                        $files->addFilter('Rename', array('target' => $filePath, 'overwrite' => true));
                        $files->receive($fileinfo['name']);
                        chmod($filePath, 0777);

                        $arrArquivos = array(
                                        "arquivo"=>$nomeArquivo,
                                        "id_conteudo"=>$idSolicitacao
                                );

                        $mArquivos = new Application_Model_DbTable_Base_Arquivos();
                        $idArquivos = $mArquivos->salvar( $arrArquivos );

                    }
                }
                // fim - arquivo

                // inicio - salvar no mobbus
                $descricao = strip_tags($post["demanda"]);
                $nome_empreendimento = $rsSolicitacao->nome_empreendimento;
                $nome_unidade = $rsSolicitacao->nome_unidade;
                $nome_cliente = $rsSolicitacao->nome_cliente;
                $data_abertura = date(DATE_ATOM, mktime(0, 0, 0, 7, 1, 2000));
                $telefone = $rsSolicitacao->telefone;
                $email = $rsSolicitacao->email;
                $protocolo = $rsSolicitacao->protocolo;

                // echo $descricao;
                $json = '{"descricao":"'.$descricao.'","nomeObra":"'.$nome_empreendimento.'","nomeLocal":"'.$nome_unidade.'","nomeCliente":"'.$nome_cliente.'","dataAbertura":"'.$data_abertura.'","nomeCanalAtendimento":"Portal Web","nomeTipoAtendimento":"Assistência Técnica","nomeSetor":"SAC","telefoneContato":"'.$telefone.'","emailContato":"'.$email.'","numeroSolicitacaoAtendimento":"'.$protocolo.'"}';

                // echo "<pre>";
                // print_r($json);
                // echo "======================";
                // print_r($rSolicitacao);
                // exit();

                $url = 'https://dev2.mobuss.com.br/ccweb/rest/v1/assistencia/solicitacao/criar';

                $opts = array(
                        'http' => array(
                                'method' => 'POST',
                                'header' => "Content-type: application/json\r\n" . 
                                            "charset: utf-8\r\n" . 
                                            "companyID: ACTKUAS0TVUN\r\n" .
                                            "token: 2076437e-8127-4eb9-8d0e-6e96204bcbf6\r\n",
                                'content' => $json
                            )
                    );

                $context = stream_context_create( $opts );
                $fp = fopen($url, 'r', false, $context);
                $result = json_decode(stream_get_contents($fp) );
                // print_r( $result );


                $rSolicitacao->id_mobuss = $result->preSolicitacaoAtendimento->idMobuss;
                $rSolicitacao->save();

                // fim - salvar no mobbus
                // exit();

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('O registro foi atualizado.'));
                $this->redirect('solicitacao', 'cadastro', 'admin', array('id' => $idSolicitacao));
            } else {
                $this->redirect('solicitacao', 'index', 'admin');
            }

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('form-Empreendimentos', $this->getRequest()->getPost());
            if (isset($idSolicitacao) && $idSolicitacao) {
                $this->redirect('solicitacao', 'cadastro', 'admin', array('id' => $idSolicitacao));
            } else {
                $this->redirect('solicitacao', 'cadastro', 'admin');
            }
        }

    }   



    public function excluirAction()
    {
        try {
            $params = $this->_request->getParams();
            if (isset($params['id'])) {
                $mSolicitacao = new Application_Model_DbTable_Base_Solicitacao();
                $mSolicitacao->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('O item foi excluído.'));
            }
            $this->redirect('solicitacao', 'index', 'admin');
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('solicitacao', 'index', 'admin');
        }
    }


    public function excluirArquivoAction()
    {
        try {
            $params = $this->_request->getParams();
            if (isset($params['arquivo'])) {
                $mArquivos = new Application_Model_DbTable_Base_Arquivos();
                $mArquivos->exclusao_fisica($params['arquivo']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('O item foi excluído.'));
            }
            $this->redirect('solicitacao', 'cadastro', 'admin', array('id' => $params['id'] ));
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('solicitacao', 'cadastro', 'admin', array('id' => $params['id'] ));
        }
    }
}