<?php

class Admin_UnidadeController extends Base_Controller_Admin
{

    public function indexAction()
    {
        $mUnidades               = new Application_Model_DbTable_Base_Unidades();
        $params               = $this->_request->getParams();
        $rsUnidades              = $mUnidades->pesquisar($params);
        $page                 = $this->_getParam('pagina', 1);
        $paginator            = Zend_Paginator::factory($rsUnidades);
        $paginator->setItemCountPerPage(10);
        $paginator->setCurrentPageNumber($page);
        $paginator->setPageRange(5);
        $this->view->unidades = $paginator;
        $this->view->pesquisa = $params;
    }    

    public function cadastroAction()
    {
        $params                  = $this->_request->getParams();
        if (isset($params['id'])) {
            $mUnidades              = new Application_Model_DbTable_Base_Unidades();
            $this->view->unidade = $mUnidades->find($params['id'])->current();
        }

        $mEmpreendimentos = new Application_Model_DbTable_Base_Empreendimentos();
        $this->view->empreendimento = $mEmpreendimentos->lista();

    } 


    public function salvarAction()
    {

        try {
            
            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();

                $mUnidades  = new Application_Model_DbTable_Base_Unidades();
                $idUnidades = $mUnidades->salvar($post);

                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('O registro foi atualizado.'));
                $this->redirect('unidade', 'cadastro', 'admin', array('id' => $idUnidades));
            } else {
                $this->redirect('unidade', 'index', 'admin');
            }

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('form-unidades', $this->getRequest()->getPost());
            if (isset($idUnidades) && $idUnidades) {
                $this->redirect('unidade', 'cadastro', 'admin', array('id' => $idUnidades));
            } else {
                $this->redirect('unidade', 'cadastro', 'admin');
            }
        }

    } 



    public function listaUnidadesAction()
    {

        $params = $this->_request->getParams();


        $mUnidades            = new Application_Model_DbTable_Base_Unidades();

        if( isset($params['id']) and !empty($params['id']) ){
            $id_empreendimento = $params['id'];
            $this->view->unidades = $mUnidades->lista($id_empreendimento);
        }else{
            $id_empreendimento = '';
            $this->view->unidades = $mUnidades->lista($id_empreendimento);
        }
        
        if( isset($params['id_user']) and !empty($params['id_user']) ){
            $id_user = $params['id_user'];
            $this->view->unidades = $mUnidades->lista_user($id_empreendimento,$id_user);
        }else{
            $id_user = '';
        }

        // echo "<pre>";
        // print_r( $this->view->unidades );
        // exit();
        
        

        $this->_helper->layout->disableLayout();
        
    }  


    public function excluirAction()
    {


        try {
            $params = $this->_request->getParams();
            if (isset($params['id'])) {
                $mUnidades = new Application_Model_DbTable_Base_Unidades();
                $mUnidades->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('O registro foi excluído.'));
            }
            $this->redirect('unidade', 'index', 'admin');
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('unidade', 'index', 'admin');
        }

    }   

}