<?php

class Admin_CidadeController extends Base_Controller_Admin
{

    public function listaAction()
    {

        $params = $this->_request->getParams();

        if (isset($params['id'])) {
            
            $mLoginPerfil       = new Application_Model_DbTable_Base_Cidade();
            $params             = $mLoginPerfil->filtrar($params);
            $this->view->cidades = $mLoginPerfil->find($params['id'])->current();
        }

        if (isset($params['cid_id'])) {            
            $this->view->cid_id = $params['cid_id'];
        }
        
        $mEstado               = new Application_Model_DbTable_Base_Cidade();
        $params               = $this->_request->getParams();
        $rsLogin              = $mEstado->pesquisar($params);
        $this->view->cidades = $rsLogin;

        $this->_helper->layout->disableLayout();

    }

}
