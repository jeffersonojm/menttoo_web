<?php

class Admin_LoginPerfilController extends Base_Controller_Admin
{
    public function indexAction()
    {
        $mLoginPerfil         = new Application_Model_DbTable_Base_LoginPerfil();
        $params               = $this->_request->getParams();
        $rsLoginPerfil        = $mLoginPerfil->pesquisar($params);
        $page                 = $this->_getParam('pagina', 1);
        $paginator            = Zend_Paginator::factory($rsLoginPerfil);
        $paginator->setItemCountPerPage(10);
        $paginator->setCurrentPageNumber($page);
        $paginator->setPageRange(5);
        $this->view->perfis   = $paginator;
        $this->view->pesquisa = $params;
    }

    public function cadastroAction()
    {
        $params = $this->_request->getParams();
        if (isset($params['id'])) {
            $mLoginPerfil       = new Application_Model_DbTable_Base_LoginPerfil();
            $params             = $mLoginPerfil->filtrar($params);
            $this->view->perfil = $mLoginPerfil->find($params['id'])->current();
        }
    }

    public function salvarAction()
    {
        try {
            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();
                if (isset($post['id']) && $post['id']) {
                    $idLoginPerfil = $post['id'];
                }
                $mLoginPerfil  = new Application_Model_DbTable_Base_LoginPerfil();
                $idLoginPerfil = $mLoginPerfil->salvar($post);
                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('O perfil foi atualizado.'));
                $this->redirect('login-perfil', 'cadastro', 'admin', array('id' => $idLoginPerfil));
            } else {
                $this->redirect('login-perfil', 'index', 'admin');
            }
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('form-login-perfil', $this->getRequest()->getPost());
            if (isset($idLoginPerfil) && $idLoginPerfil) {
                $this->redirect('login-perfil', 'cadastro', 'admin', array('id' => $idLoginPerfil));
            } else {
                $this->redirect('login-perfil', 'cadastro', 'admin');
            }
        }
    }

    public function excluirAction()
    {
        try {
            $params = $this->_request->getParams();
            if (isset($params['id'])) {
                $mLoginPerfil = new Application_Model_DbTable_Base_LoginPerfil();
                $mLoginPerfil->excluir($params['id']);
                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('O perfil foi excluído.'));
            }
            $this->redirect('login-perfil', 'index', 'admin');
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('login-perfil', 'index', 'admin');
        }
    }
}
