<?php

class Admin_EmpreendimentoController extends Base_Controller_Admin
{

    public function indexAction()
    {

        $mEmpreendimentos               = new Application_Model_DbTable_Base_Empreendimentos();
        $params               = $this->_request->getParams();
        $rsEmpreendimentos              = $mEmpreendimentos->pesquisar($params);
        $page                 = $this->_getParam('pagina', 1);
        $paginator            = Zend_Paginator::factory($rsEmpreendimentos);
        $paginator->setItemCountPerPage(10);
        $paginator->setCurrentPageNumber($page);
        $paginator->setPageRange(5);
        $this->view->empreendimentos = $paginator;
        $this->view->pesquisa = $params;
        
    }    

    public function cadastroAction()
    {

        $params                  = $this->_request->getParams();
        if (isset($params['id'])) {
            $mEmpreendimentos              = new Application_Model_DbTable_Base_Empreendimentos();
            $this->view->empreendimento = $mEmpreendimentos->find($params['id'])->current();
        }




        $mEstado               = new Application_Model_DbTable_Base_Estado();
        $params               = $this->_request->getParams();
        $rsDados              = $mEstado->pesquisar($params);
        $this->view->estados = $rsDados;

    }    

    public function salvarAction()
    {

        try {
            
            if ($this->_request->isPost()) {
                $post = $this->_request->getPost();

                $mEmpreendimentos  = new Application_Model_DbTable_Base_Empreendimentos();
                $idEmpreendimentos = $mEmpreendimentos->salvar($post);


                $this->setSuccessMessage(Base_Message::SUCCESS_FORM_SUCESSO, array('O registro foi atualizado.'));
                $this->redirect('empreendimento', 'cadastro', 'admin', array('id' => $idEmpreendimentos));
            } else {
                $this->redirect('empreendimento', 'index', 'admin');
            }

        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_FORM, array($e->getErrorMessage()));
            Base_Form::populate('form-Empreendimentos', $this->getRequest()->getPost());
            if (isset($idEmpreendimentos) && $idEmpreendimentos) {
                $this->redirect('empreendimento', 'cadastro', 'admin', array('id' => $idEmpreendimentos));
            } else {
                $this->redirect('empreendimento', 'cadastro', 'admin');
            }
        }

    
    } 


    public function excluirAction()
    {


        try {
            $params = $this->_request->getParams();
            if (isset($params['id'])) {
                $mEmpreendimentos = new Application_Model_DbTable_Base_Empreendimentos();
                $mEmpreendimentos->exclusao_fisica($params['id']);
                $this->setSuccessMessage(Base_Message::PROCESS_SUCCESS, array('O registro foi excluído.'));
            }
            $this->redirect('empreendimento', 'index', 'admin');
        } catch (Base_Exception $e) {
            $this->setErrorMessage(Base_Message::ERROR_EXCLUSAO, array($e->getErrorMessage()));
            $this->redirect('empreendimento', 'index', 'admin');
        }

    } 
}