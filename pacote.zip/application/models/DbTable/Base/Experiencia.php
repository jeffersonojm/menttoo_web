<?php

class Application_Model_DbTable_Base_Experiencia extends Base_Db_Table
{
    protected $_name = 'experiencia';
    protected $_primary = 'id';

    
    public function pesquisar($lgn_id)
    {

        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'experiencia'))->where("lgn_id = '$lgn_id' ");

        $select->order('id ASC');
        return $this->fetchAll($select);
    }

}
