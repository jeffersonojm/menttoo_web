<?php

class Application_Model_DbTable_Base_Avaliacao extends Base_Db_Table
{
    protected $_name         = 'avaliacao';
    protected $_primary      = 'id';
    // protected $_referenceMap = array(array('refTableClass' => 'Application_Model_DbTable_Base_LoginPerfil',
    //                                        'refColumns'    => 'lgp_id',
    //                                        'columns'       => 'lgn_lgp_id'),
    //                                 array('refTableClass' => 'Application_Model_DbTable_Base_Cidades',
    //                                        'refColumns'    => 'cid_id',
    //                                        'columns'       => 'lgn_cid_id')
    //                                 );
    public function getSelectPesquisar($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('c' => 'avaliacao'),
                              array('c.*'));
        
        $select->where('c.status <> ?', 'R');                       
        
        if (isset($params['user_id'])) {
            $select->where('c.user_id = ?', $params['user_id']);
        }
        // $select->order('l.lgn_nome ASC');

        return $select;
    }
    /**
     * Recupera todos os dados baseado nos dados
     * informados na pesquisa
     * @param $params array
     * @return Zend_Db_Table_Rowset
     */
    public function pesquisar($params = array())
    {
        $select = $this->getSelectPesquisar($params);
        return $this->fetchAll($select);
    }

    public function combo($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              array(
                                    'l.lgn_id',
                                    'l.lgn_nome'
                                    ));
                       
        $select->where('l.lgn_status <> ?', 'R');                       
        $select->order('l.lgn_nome ASC');

        $dados = $this->fetchAll($select)->toArray();
        $arr_dados = array("0"=>"Selecione");
        foreach ($dados as $dado) {
            $arr_dados[$dado["lgn_id"]] = $dado["lgn_nome"];
        }

        // echo "<pre>";
        // print_r($arr_dados);
        // exit();

        return $arr_dados;
    }

    public function getAvaliacaoUser($params = array())
    {

        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('a' => 'avaliacao'),
                              array('SUM(a.avaliacao) as avaliacao', 'COUNT(a.id) as quantidade'));
        
        $select->where('a.status <> ?', 'R');                       
        
        if (isset($params['user_id_avaliado'])) {
            $select->where('a.user_id_avaliado = ?', $params['user_id_avaliado']);
        }
        // echo "<pre>";
        // print_r( $this->fetchAll($select) );
        // exit();
        return $this->fetchAll($select);
    }

    public function getAvaliacao($params = array())
    {

        // $identity   = Zend_Auth::getInstance()->getIdentity();
        // $idLogin    = $identity->lgn_id;
        // $perfil     = $identity->lgn_lgp_id;

        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('a' => 'avaliacao'),
                              array('a.*'))
                       ->joinLeft(array('l' => 'login'),'l.lgn_id = a.user_id_avaliando',array('l.lgn_nome as avaliador_nome', 'l.lgn_avatar as avaliador_avatar'))
                       ->joinLeft(array('l2' => 'login'),'l2.lgn_id = a.user_id_avaliado',array('l2.lgn_nome as avaliado_nome', 'l2.lgn_avatar as avaliado_avatar'))
                       ->joinLeft(array('c' => 'coaching'),'c.id = a.coaching_id',array('c.life_coaching', 'c.executive_coaching'));

        
        $select->where('a.status <> ?', 'R');                       
        
        if (isset($params['user_id_avaliado'])) {
            $select->where('a.user_id_avaliado = ?', $params['user_id_avaliado']);
        }
        
        
        if (isset($params['coaching_id'])) {
            $select->where('a.coaching_id = ?', $params['coaching_id']);
        }

        // if( !isset($params['coaching_id']) and isset($params['user_id_avaliado']) ){
        //   if( (int)$perfil == 3 ) {
        //       $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coach_id',array('l.*'));
        //   }
           
        //   if( (int)$perfil == 2 ) {
        //       $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coachee_id',array('l.*'));            
        //   }            
        // }




        if (isset($params['id'])) {
            $select->where('a.id = ?', $params['id']);
        }

        $select->limit(5);

        $select->order('a.data DESC');
        

        return $this->fetchAll($select);
    }

}
