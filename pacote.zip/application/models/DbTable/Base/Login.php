<?php

class Application_Model_DbTable_Base_Login extends Base_Db_Table
{
    protected $_name         = 'login';
    protected $_primary      = 'lgn_id';
    protected $_referenceMap = array(array('refTableClass' => 'Application_Model_DbTable_Base_LoginPerfil',
                                           'refColumns'    => 'lgp_id',
                                           'columns'       => 'lgn_lgp_id'),
                                    array('refTableClass' => 'Application_Model_DbTable_Base_Cidades',
                                           'refColumns'    => 'cid_id',
                                           'columns'       => 'lgn_cid_id')
                                    );

    /**
     * Autenticação de usuários
     * @access public
     * @param array $post
     * @return Zend_Auth
     * @throws Cfmv_Exception
     */
    public function autenticar(array $post, $modulo = 'site')
    {

        try {
            $this->filtrarAutenticacao($post);
            $this->validarAutenticacao($post);


            $authAdapter = new Zend_Auth_Adapter_DbTable($this->getAdapter(), 'login', 'lgn_email', 'lgn_senha', 'MD5(?)  AND `lgn_status`="A"');
            $authAdapter->setIdentity($post['login'])->setCredential($post['senha']);

            $zendAuth = Zend_Auth::getInstance();
            //$zendAuth->setStorage(new Zend_Auth_Storage_Session('Zend_Auth_' . ucfirst($modulo)));

            if ($zendAuth->authenticate($authAdapter)->isValid()) {
                $zendAuth->getStorage()->write(
                    $authAdapter->getResultRowObject(array('lgn_id', 'lgn_nome', 'lgn_sobrenome', 'lgn_email', 'lgn_usuario', 'lgn_telefone', 'lgn_celular', 'lgn_lgp_id', 'lgn_ass_id', 'lgn_avatar', 'lgn_cadastro_completo'))
                );
                $identity = Zend_Auth::getInstance()->getIdentity();
                if($identity){
                    if( isset($identity->lgn_lgp_id) ){
                        if($identity->lgn_lgp_id == 1){
                            $identity->perfil = 'master';
                        }else if($identity->lgn_lgp_id == 2){
                            $identity->perfil = 'coach';
                        }else if($identity->lgn_lgp_id == 3){
                            $identity->perfil = 'coachee';
                        }
                    }
                    $identity->origem_acesso = $modulo;
                }
                // echo "<pre>";
                // print_r( $identity );
                // exit();
                return $identity;
            } else {
                // grava o registro na tabela de acessos inválidos
                // $dadosAcessoInvalido              = array();
                // $dadosAcessoInvalido['ip']        = Base_Function::getIp();
                // $dadosAcessoInvalido['navegador'] = Base_Function::getBrowserInfo();
                // $dadosAcessoInvalido['script']    = Base_Function::getUri();
                // $dadosAcessoInvalido['idioma']    = Base_Function::getBrowserLanguage();
                // $mLoginAcessoInvalido             = new Application_Model_DbTable_Base_LoginAcessoInvalido();
                // $mLoginAcessoInvalido->salvar($dadosAcessoInvalido);
                // lança a exceção
                // $exception = new Base_Exception();
                // $exception->addErrorField('login');
                // $exception->addErrorField('senha');
                // $exception->setErrorMessage(Base_Message::ERROR_AUTENTICACAO);
                // throw $exception;
                
                // if( $modulo=='site' ){
                //     // Base_Controller_Action::setErrorMessage(Base_Message::ERROR_FORM, array('Login inválido.'));
                //     $this->redirect('index', 'index', 'site');
                // }else{
                //     // Base_Controller_Action::setErrorMessage(Base_Message::ERROR_FORM, array('Login inválido.'));
                //     $this->redirect('index', 'index', 'admin');
                // }
                return false;
                exit();
            }
        } catch (Zend_Db_Exception $e) {
            $eAnup = new Base_Exception();
            $eAnup->setErrorMessage($eAnup->getDbExceptionMessage($e));
            throw $eAnup;
        } catch (Base_Exception $e) {
            $e->setErrorMessage($e->getErrorMessage($e));
            throw $e;
        }
    }


    public function autenticar_redes(array $post, $modulo = 'site')
    {

        try {
            $this->filtrarAutenticacao($post);
            $this->validarAutenticacao($post);


            $authAdapter = new Zend_Auth_Adapter_DbTable($this->getAdapter(), 'login', 'lgn_email', 'lgn_senha_redes', 'MD5(?)  AND `lgn_status`="A"');
            $authAdapter->setIdentity($post['login'])->setCredential($post['senha']);

            $zendAuth = Zend_Auth::getInstance();
            //$zendAuth->setStorage(new Zend_Auth_Storage_Session('Zend_Auth_' . ucfirst($modulo)));

            if ($zendAuth->authenticate($authAdapter)->isValid()) {
                $zendAuth->getStorage()->write(
                    $authAdapter->getResultRowObject(array('lgn_id', 'lgn_nome', 'lgn_sobrenome', 'lgn_email', 'lgn_usuario', 'lgn_telefone', 'lgn_celular', 'lgn_lgp_id', 'lgn_ass_id', 'lgn_avatar', 'lgn_cadastro_completo'))
                );
                $identity = Zend_Auth::getInstance()->getIdentity();
                if($identity){
                    if( isset($identity->lgn_lgp_id) ){
                        if($identity->lgn_lgp_id == 1){
                            $identity->perfil = 'master';
                        }else if($identity->lgn_lgp_id == 2){
                            $identity->perfil = 'coach';
                        }else if($identity->lgn_lgp_id == 3){
                            $identity->perfil = 'coachee';
                        }
                    }
                    $identity->origem_acesso = $modulo;
                }
                // echo "<pre>";
                // print_r( $identity );
                // exit();
                return $identity;
            } else {
                // grava o registro na tabela de acessos inválidos
                // $dadosAcessoInvalido              = array();
                // $dadosAcessoInvalido['ip']        = Base_Function::getIp();
                // $dadosAcessoInvalido['navegador'] = Base_Function::getBrowserInfo();
                // $dadosAcessoInvalido['script']    = Base_Function::getUri();
                // $dadosAcessoInvalido['idioma']    = Base_Function::getBrowserLanguage();
                // $mLoginAcessoInvalido             = new Application_Model_DbTable_Base_LoginAcessoInvalido();
                // $mLoginAcessoInvalido->salvar($dadosAcessoInvalido);
                // lança a exceção
                // $exception = new Base_Exception();
                // $exception->addErrorField('login');
                // $exception->addErrorField('senha');
                // $exception->setErrorMessage(Base_Message::ERROR_AUTENTICACAO);
                // throw $exception;
                
                // if( $modulo=='site' ){
                //     // Base_Controller_Action::setErrorMessage(Base_Message::ERROR_FORM, array('Login inválido.'));
                //     $this->redirect('index', 'index', 'site');
                // }else{
                //     // Base_Controller_Action::setErrorMessage(Base_Message::ERROR_FORM, array('Login inválido.'));
                //     $this->redirect('index', 'index', 'admin');
                // }
                return false;
                exit();
            }
        } catch (Zend_Db_Exception $e) {
            $eAnup = new Base_Exception();
            $eAnup->setErrorMessage($eAnup->getDbExceptionMessage($e));
            throw $eAnup;
        } catch (Base_Exception $e) {
            $e->setErrorMessage($e->getErrorMessage($e));
            throw $e;
        }
    }


    /**
     * Filtra os dados da autenticação
     * @access public
     * @param array &$post
     * @return void
     */
    public function filtrarAutenticacao(array &$post)
    {
        $filterChain = new Zend_Filter();
        $filterChain->addFilter(new Zend_Filter_StringTrim())
                    ->addFilter(new Zend_Filter_StripTags());
        // login
        if (isset($post['login'])) {
            $post['login'] = $filterChain->filter($post['login']);
        }
        // senha
        if (isset($post['senha'])) {
            $post['senha'] = $filterChain->filter($post['senha']);
        }
    }

    /**
     * Valida os dados da autenticação
     * @access public
     * @param array &$post
     * @return void
     * @throws Cfmv_Exception
     */
    public function validarAutenticacao(array $post)
    {
        $exception = new Base_Exception();
        // login
        if (!Zend_Validate::is($post['login'], 'NotEmpty')) {
            $exception->addErrorField('login', Base_Message::ERROR_FIELD_CAMPO_OBRIGATORIO);
        }
        // senha
        if (!Zend_Validate::is($post['senha'], 'NotEmpty')) {
            $exception->addErrorField('senha', Base_Message::ERROR_FIELD_CAMPO_OBRIGATORIO);
        }
        if ($exception->hasErrors()) {
            $exception->setErrorMessage(Base_Message::ERROR_CAMPOS_FORM);
            throw $exception;
        }
    }




    /**
     * Realiza o logout do usuário
     * @return void
     */
    public function sair()
    {
        Zend_Auth::getInstance()->clearIdentity();
    }

    /**
     * Filtra os dados
     * @access public
     * @param array $dados
     * @return array
     */
    public function filtrar(array $dados)
    {
        $filtros = array('id'     => array('StringTrim',
                                           'StripTags',
                                           'Digits'),
                         'nome'   => array('StringTrim',
                                           'StripTags'),
                         'email'  => array('StringTrim',
                                           'StripTags'),
                         'perfil' => array('StringTrim',
                                           'StripTags',
                                           'Digits'));
        return parent::filtrar($dados, $filtros);
    }

    /**
     * Valida os dados do form
     * @access public
     * @param array $dados
     * @return void
     */
    public function validarCampos(array $dados)
    {

        $validadores = array();

        // $validadores = array('nome'     => array('NotEmpty'),
        //                      'email'    => array('NotEmpty',
        //                                        'EmailAddress'),
        //                      'login'    => array('NotEmpty'),
        //                      'perfil'   => array('NotEmpty',
        //                                        'Digits'),
        //                      'cpf'      => array('NotEmpty',
        //                                        'Digits'),
        //                      'telefone' => array('NotEmpty',
        //                                        'Digits'),
        //                      'celular' => array('NotEmpty',
        //                                        'Digits'));
        // senha
        if (!isset($dados['id']) || is_null($dados['id']) || trim($dados['id']) == '') {
            $validadores['senha'] = array('NotEmpty');
        }

        parent::validarCampos($dados, $validadores);
    }

    /**
     * Prepara a array de dados a serem persistidos
     * à partir dos dados do form
     * @access public
     * @param array $dados
     * @return array
    */
    public function prepararDados(array $dados)
    {
        $arrMapeamento = array('id'                 => 'lgn_id',
                               'perfil'             => 'lgn_lgp_id',            
                               'nome'               => 'lgn_nome',
                               'email'              => 'lgn_email',
                               'senha'              => 'lgn_senha',
                               'senha_redes'        => 'lgn_senha_redes',
                               'ddd'                => 'lgn_ddd',
                               'telefone'           => 'lgn_telefone',
                               'nascimento'         => 'lgn_data_nascimento',
                               'bio'                => 'lgn_bio',
                               'uf'                 => 'lgn_uf',
                               'cidade'             => 'lgn_cidade',
                               'avatar'             => 'lgn_avatar',
                               'processo_coaching'  => 'lgn_processo_coaching',
                               'duracao_media'      => 'lgn_duracao_media',
                               'codigo_convite'     => 'lgn_codigo_convite',
                               'preco_sessao'       => 'lgn_preco_sessao',
                               'cadastro_completo'  => 'lgn_cadastro_completo',
                               'origem_cadastro'    => 'lgn_origem_cadastro',
                               'status'             => 'lgn_status');
        
        // aplica a criptografia MD5 na senha
        if (isset($dados['senha']) && !is_null($dados['senha']) && trim($dados['senha']) != '') {
            $dados['senha'] = md5($dados['senha']);
        } else {
            unset($dados['senha']);
        }

        // aplica a criptografia MD5 na senha
        if (isset($dados['senha_redes']) && !is_null($dados['senha_redes']) && trim($dados['senha_redes']) != '') {
            $dados['senha_redes'] = md5($dados['senha_redes']);
        } else {
            unset($dados['senha_redes']);
        }


        // formata a data
        if (isset($dados['nascimento']) && $dados['nascimento']) {
            // $dados['nascimento'] = Base_Date::view2Db($dados['nascimento']);
            $data = explode("/", $dados['nascimento'] );
            $dados['nascimento'] = $data[2] . "-" . $data[1] . "-" . $data[0];
        }   

        // echo "<pre>";
        // print_r($dados['nascimento']);
        // exit();

        // chama o método do pai
        return parent::prepararDados($dados, $arrMapeamento);
    }
    /**
     *
     */
    public function getSelectPesquisar($params = array())
    {

        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              array('l.*'))
                       ->joinLeft(array('p' => 'login_perfil'),'l.lgn_lgp_id = p.lgp_id',array('p.lgp_nome as perfil'))
                       // ->joinLeft(array('dp' => 'diploma'),'l.lgn_id = dp.user_id',array('dp.arquivo as dp_arquivo','dp.data_encerramento as dp_data_encerramento','dp.nome_escola as dp_nome_escola'))
                       // ->joinLeft(array('sl' => 'segmento_login'),'l.lgn_id = sl.user_id',array('sl.tipo_id as tipo_coach_id','sl.segmento_id'))
                       ;
        
        
        if (isset($params['codigo'])) {
            $select->where('l.lgn_codigo_convite = ?', $params['codigo']);
        }

        if (isset($params['email_solicitacao'])) {
            $select->where('l.lgn_status = ?', 'S');
            $select->where('l.lgn_email = ?', $params['email_solicitacao']);
        }else{
            $select->where('l.lgn_status <> ?', 'R');
        }
        
        if (isset($params['id'])) {
            $select->where('l.lgn_id = ?', $params['id'] );

            $mSegmentoLogin = new Application_Model_DbTable_Base_SegmentoLogin();
            $rSegmentoLogin = $mSegmentoLogin->pesquisar( array('user_id'=> $params['id']) )->toArray();
        }

        if (isset($params['nome'])) {
            $select->where('LOWER(l.lgn_nome) like ?', '%' . strtolower($params['nome']) . '%');
        }
        if (isset($params['email'])) {
            $select->where('l.lgn_email = ?', strtolower($params['email']) );
        }
        if (isset($params['perfil'])) {
            $select->where('l.lgn_lgp_id = ?', $params['perfil']);
        }
        $select->order('l.lgn_nome ASC');


        // echo "<pre>";
        // print_r($params);
        // exit();


        return $select;
    }
    /**
     * Recupera todos os dados baseado nos dados
     * informados na pesquisa
     * @param $params array
     * @return Zend_Db_Table_Rowset
     */
    public function pesquisar($params = array())
    {
        $select = $this->getSelectPesquisar($params);
        return $this->fetchAll($select);
    }

    public function combo($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              array(
                                    'l.lgn_id',
                                    'l.lgn_nome'
                                    ));
                       
        $select->where('l.lgn_status <> ?', 'R');                       
        $select->order('l.lgn_nome ASC');

        $dados = $this->fetchAll($select)->toArray();
        $arr_dados = array("0"=>"Selecione");
        foreach ($dados as $dado) {
            $arr_dados[$dado["lgn_id"]] = $dado["lgn_nome"];
        }

        // echo "<pre>";
        // print_r($arr_dados);
        // exit();

        return $arr_dados;
    }


    public function getUsuario($params = array())
    {

        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              array('l.*'))
                       ->joinLeft(array('p' => 'login_perfil'),'l.lgn_lgp_id = p.lgp_id',array('p.lgp_nome as perfil'));
        
        $select->where('l.lgn_status <> ?', 'R');                       
        
        if (isset($params['id'])) {
            $select->where('l.lgn_id = ?', $params['id']);
        }
        
        if (isset($params['email'])) {
            $select->where('l.lgn_email = ?', $params['email']);
        }

        // if( !isset($params['email']) and !isset($params['id'])){
        //     $identity   = Zend_Auth::getInstance()->getIdentity();
        //     $select->where('l.lgn_id = ?', $identity->lgn_id);
        // }


        $select->order('l.lgn_nome ASC');

        $return = $this->fetchAll($select)->current();

        if( count($return) ){
            $return = $return->toArray();
        }
        

        if ( count( $return ) ) {

            if (!isset($params['id'])) {
                $params['id'] = $return["lgn_id"];
            }

            $mDiploma        = new Application_Model_DbTable_Base_Diploma();
            $rDiploma = $mDiploma->pesquisar( array('user_id'=> $params['id']) )->toArray();

            if ( count($rDiploma) ) {
                $return['diplomas'] = $rDiploma;  
            }


            $mSegmentoLogin = new Application_Model_DbTable_Base_SegmentoLogin();
            $rSegmentoLogin = $mSegmentoLogin->pesquisar( array('user_id'=> $params['id']) )->toArray();

            if ( count($rSegmentoLogin) ) {
                $return['segmentos'] = $rSegmentoLogin;  
                $key_life = array_search( 1 , array_column( $rSegmentoLogin, 'tipo_id'));
                $key_executive = array_search( 2 , array_column( $rSegmentoLogin, 'tipo_id'));

                if ( false !== $key_life ){ $return['life_coahing'] = 1; }
                if ( false !== $key_executive ){ $return['executive_coahing'] = 1; }
            }


            $mCredencial        = new Application_Model_DbTable_Base_Credencial();
            $rCredencial = $mCredencial->pesquisar( array('user_id'=> $params['id']) )->toArray();

            if ( count($rCredencial) ) {
                $return['credenciais'] = $rCredencial;  
            }



            $mComprovante        = new Application_Model_DbTable_Base_Comprovante();
            $rComprovante = $mComprovante->pesquisar( array('user_id'=> $params['id']) )->toArray();

            if ( count($rComprovante) ) {
                $return['comprovantes'] = $rComprovante;  
            }            


            $mClienteIndicado       = new Application_Model_DbTable_Base_ClienteIndicado();
            $rClienteIndicado = $mClienteIndicado->pesquisar( array('user_id'=> $params['id']) )->toArray();

            if ( count($rClienteIndicado) ) {
                $return['clientes_indicados'] = $rClienteIndicado;  
            }  


            $mCurriculo       = new Application_Model_DbTable_Base_Curriculo();
            $rCurriculo = $mCurriculo->pesquisar( array('user_id'=> $params['id']) )->toArray();

            if ( count($rCurriculo) ) {
                $return['curriculos'] = $rCurriculo;  
            }  


            $mCursos        = new Application_Model_DbTable_Base_Cursos();
            $rCursos = $mCursos->pesquisar( array('user_id'=> $params['id']) )->toArray();

            if ( count($rCursos) ) {
                $return['cursos'] = $rCursos;  
            }


            $mVideos       = new Application_Model_DbTable_Base_Videos();
            $rVideos = $mVideos->pesquisar( array('user_id'=> $params['id']) )->toArray();

            if ( count($rVideos) ) {
                $return['videos_apresentacao'] = $rVideos;  
            }  


            $mAvaliacaoUser       = new Application_Model_DbTable_Base_Avaliacao();
            $rAvaliacaoUser = $mAvaliacaoUser->getAvaliacaoUser( array('user_id_avaliado'=> $params['id']) )->toArray();

            if ( count($rAvaliacaoUser) ) {
                $return['avaliacao_qtd'] = $rAvaliacaoUser;  
            }              


            $mAvaliacao       = new Application_Model_DbTable_Base_Avaliacao();
            $rAvaliacao = $mAvaliacao->getAvaliacao( array('user_id_avaliado'=> $params['id']) )->toArray();

            if ( count($rAvaliacao) ) {
                $return['avaliacao'] = $rAvaliacao;  
            }   

            $mCoaching       = new Application_Model_DbTable_Base_Coaching();
            $rCoaching = $mCoaching->pesquisar( array('coach_id'=> $params['id'], "unique"=>"s" ) )->toArray();

            if ( count($rCoaching) ) {
                $return['coaching'] = $rCoaching;  
            }  


            $mExperiencia       = new Application_Model_DbTable_Base_Experiencia();
            $rExperiencia = $mExperiencia->pesquisar( $params['id'] )->toArray();

            if ( count($rExperiencia) ) {
                $return['experiencia'] = $rExperiencia;  
            }  


            $mPortfolio       = new Application_Model_DbTable_Base_Portfolio();
            $rPortfolio = $mPortfolio->pesquisar( $params['id'] )->toArray();

            if ( count($rPortfolio) ) {
                $return['portfolio'] = $rPortfolio;  
            }  


            $mPremios       = new Application_Model_DbTable_Base_Premios();
            $rPremios = $mPremios->pesquisar( $params['id'] )->toArray();

            if ( count($rPremios) ) {
                $return['premios'] = $rPremios;  
            }  

        }
        // echo "<pre>";
        // print_r($params);
        // exit();


        return $return;
    }



    /**
    * recupera senha
    */
    public function recuperar_senha($mail = ''){
        $select          = $this->select()
                                ->where('lgn_email = ?', $mail)
                                ->where('lgn_status = ?', 'A'); 

        $dados          = $this->fetchAll($select);


        if( $dados->count() ){
            $dados = $dados->current();
            $senha = strtoupper( substr( md5(uniqid(mt_rand(), true) ) , 0 , 10 )  );
            $dados->lgn_senha = md5($senha);
            $dados->save();
            return $senha;
        }else{
            return false;    
        }
       
    }  


    public function getBuscaCount($params = array())
    {

        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              // array('count(l.lgn_id) as quantidade'));
                        array('l.*'));
        
        
        $select->where('l.lgn_lgp_id = ?', 2);
        $select->where('l.lgn_codigo_convite  IS NOT NULL');
        

        if (isset($params['processo_coaching'])) {
            $tipo = $params['processo_coaching'];
            $select->where("(l.lgn_processo_coaching = '$tipo' or l.lgn_processo_coaching = 'ambos')");
        }

        if (isset($params['tipo_coach'])) {
            $select->join(array('sl' => 'segmento_login'),'l.lgn_id = sl.user_id',array('sl.id'));
            $select->where('sl.tipo_id = ?', $params['tipo_coach']);    

            if (isset($params['segmento'])) {
                $select->where('sl.segmento_id = ?', $params['segmento']);
            }            
        }

        if (isset($params['uf'])) {
            $select->where('UPPER(l.lgn_uf) = ?', strtoupper($params['uf']) );
        }

        if (isset($params['preco_sessao'])) {

            if ( strstr($params['preco_sessao'], "," ) ) {
                $preco = explode( ",", $params['preco_sessao'] );
                $preco = $preco[0];
            }else{
                $preco = $params['preco_sessao'];
            }

            $preco_min = $preco * 0.9;
            $preco_max = $preco * 1.1;
            // echo $preco;
            // echo "<br />";
            // echo $preco_min;
            // echo "<br />";
            // echo $preco_max;
            
            $select->where("( l.lgn_preco_sessao > '$preco_min' and l.lgn_preco_sessao < '$preco_max' )" );
        }


        if (isset($params['nome'])) {
            $select->where('LOWER(l.lgn_nome) like ?', '%' . strtolower($params['nome']) . '%');
        }

        $select->group( 'l.lgn_id' );

        // echo "<pre>";
        // print_r($select);
        // exit();

        return $this->fetchAll($select);
    }



    public function getBuscaResultados($params = array())
    {

        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              // array('count(l.lgn_id) as quantidade'));
                        array('l.*'));
        
        
        $select->where('l.lgn_lgp_id = ?', 2);
        $select->where('l.lgn_codigo_convite  IS NOT NULL');

        if (isset($params['processo_coaching'])) {
            $tipo = $params['processo_coaching'];
            if($tipo == "ambos"){
                // $select->where("(l.lgn_processo_coaching = 'ambos')");
            }else{
                $select->where("(l.lgn_processo_coaching = '$tipo' or l.lgn_processo_coaching = 'ambos')");    
            }
        }

        if (isset($params['tipo_coach'])) {
            
            $select->join(array('sl' => 'segmento_login'),'l.lgn_id = sl.user_id',array('sl.id'));
            $select->where('sl.tipo_id = ?', $params['tipo_coach']);    

            if (isset($params['segmento'])) {
                $select->where('sl.segmento_id = ?', $params['segmento']);
            }            
        }

        if (isset($params['uf'])) {
            $select->where('UPPER(l.lgn_uf) = ?', strtoupper($params['uf']) );
        }


        if (isset($params['nome'])) {
            $select->where('LOWER(l.lgn_nome) like ?', '%' . strtolower($params['nome']) . '%');
        }

        $select->group( 'l.lgn_id' );

        // echo "<pre>";
        // print_r($select);
        // exit();

        return $this->fetchAll($select);
    }


    public function getBuscaResultadosSimilar($params = array())
    {

        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              // array('count(l.lgn_id) as quantidade'));
                        array('l.*'));
        
        
        $select->where('l.lgn_lgp_id = ?', 2);
        $select->where('l.lgn_codigo_convite  IS NOT NULL');

        if (isset($params['processo_coaching'])) {
            $tipo = $params['processo_coaching'];
            if($tipo == "ambos"){
                // $select->where("(l.lgn_processo_coaching = 'ambos')");
            }else{
                $select->where("(l.lgn_processo_coaching = '$tipo' or l.lgn_processo_coaching = 'ambos')");    
            }
            
        }

        if (isset($params['tipo_coach'])) {
            $select->join(array('sl' => 'segmento_login'),'l.lgn_id = sl.user_id',array('sl.id'));
            $select->where('sl.tipo_id = ?', $params['tipo_coach']);    
        }


        $select->group( 'l.lgn_id' );

        // echo "<pre>";
        // print_r($select);
        // exit();

        return $this->fetchAll($select);
    }



    public function getBuscaCountSimilar($params = array())
    {

        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              // array('count(l.lgn_id) as quantidade'));
                        array('l.*'));
        
        
        $select->where('l.lgn_lgp_id = ?', 2);
        $select->where('l.lgn_codigo_convite  IS NOT NULL');

        if (isset($params['processo_coaching'])) {
            $tipo = $params['processo_coaching'];
            $select->where("l.lgn_processo_coaching = '$tipo'");
        }

        if (isset($params['tipo_coach'])) {
            $select->join(array('sl' => 'segmento_login'),'l.lgn_id = sl.user_id',array('sl.id'));


            $select->where('sl.tipo_id = ?', $params['tipo_coach']);    
            

            // if (isset($params['segmento'])) {
            //     $select->where('sl.segmento_id <> ?', $params['segmento']);
            // }            
        }

        $select->group( 'l.lgn_id' );

        // echo "<pre>";
        // print_r($select);
        // exit();

        return $this->fetchAll($select);
    }




    public function findByEmail($email)
    {

        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              array('l.*'))
                       ->joinLeft(array('p' => 'login_perfil'),'l.lgn_lgp_id = p.lgp_id',array('p.lgp_nome as perfil'));
        
        $select->where('l.lgn_status <> ?', 'R');                       
        
        if ( $email ) {
            $select->where('l.lgn_email = ?', $email );
        }

        return $this->fetchAll($select);
    }

}



