<?php

class Application_Model_DbTable_Base_LoginPerfil extends Base_Db_Table
{
    protected $_name    = 'login_perfil';
    protected $_primary = 'lgp_id';

    /**
     * Contantes para os ID's dos perfis do sistema
     */
    const MASTER                    = 1;
    const ADMINISTRADOR             = 2;
    const PARTICIPANTE              = 3;


    const USUARIO_COMUM             = 11;
    const USUARIO_AGENDA_COMUM      = 12;
    const USUARIO_AGENDA_PARTICULAR = 13;
    const USUARIO_AGENDA_AVANCADO   = 14;
    const EDITOR                    = 15;
    const USUARIO_AVANCADO          = 16;

    /**
     * Filtra os dados
     * @access public
     * @param array $dados
     * @return array
     */
    public function filtrar(array $dados)
    {
        $filtros = array('id'        => array('StringTrim',
                                              'StripTags',
                                              'Digits'),
                         'nome'      => array('StringTrim',
                                              'StripTags'),
                         'descricao' => array('StringTrim',
                                              'StripTags'));
        return parent::filtrar($dados, $filtros);
    }

    /**
     * Valida os dados do form
     * @access public
     * @param array $dados
     * @return void
     */
    public function validarCampos(array $dados)
    {
        $validadores = array('nome'      => array('NotEmpty'),
                             'descricao' => array('NotEmpty'));
        parent::validarCampos($dados, $validadores);
    }

    /**
     * Prepara a array de dados a serem persistidos
     * à partir dos dados do form
     * @access public
     * @param array $dados
     * @return array
     */
    public function prepararDados(array $dados)
    {
        $arrMapeamento = array('id'        => 'lgp_id',
                               'nome'      => 'lgp_nome',
                               'descricao' => 'lgp_descricao');
        // chama o método do pai
        return parent::prepararDados($dados, $arrMapeamento);
    }

    /**
     * Recupera todos os dados baseado nos dados
     * informados na pesquisa
     * @param $params array
     * @return Zend_Db_Table_Rowset
     */
    public function pesquisar($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->from(array('p' => 'login_perfil'),
                              array('p.lgp_id',
                                    'p.lgp_nome',
                                    'p.lgp_descricao'));
        if (isset($params['nome'])) {
            $select->where('LOWER(p.lgp_nome) like ?', '%' . strtolower($params['nome']) . '%');
        }
        $select->order('p.lgp_nome ASC');
        return $this->fetchAll($select);
    }
}
