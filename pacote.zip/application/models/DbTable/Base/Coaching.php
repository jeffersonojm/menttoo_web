<?php

class Application_Model_DbTable_Base_Coaching extends Base_Db_Table
{
    protected $_name         = 'coaching';
    protected $_primary      = 'id';
    // protected $_referenceMap = array(array('refTableClass' => 'Application_Model_DbTable_Base_LoginPerfil',
    //                                        'refColumns'    => 'lgp_id',
    //                                        'columns'       => 'lgn_lgp_id'),
    //                                 array('refTableClass' => 'Application_Model_DbTable_Base_Cidades',
    //                                        'refColumns'    => 'cid_id',
    //                                        'columns'       => 'lgn_cid_id')
    //                                 );
    public function getSelectPesquisar($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('c' => 'coaching'),
                              array('c.*'));
                       
        
        $select->where('c.status <> ?', 'R');                       
        
        if (isset($params['coach_id'])) {
            $select->where('c.coach_id = ?', $params['coach_id']);
            $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coachee_id',array('l.lgn_nome as coachee_nome', 'l.lgn_avatar as coachee_avatar'));
            $select->joinLeft(array('a' => 'avaliacao'),'a.user_id_avaliado = c.coachee_id',array('a.avaliacao'));

            if ( isset($params['unique']) ) {
                $select->group("coachee_id");
            }
        }

        if (isset($params['coachee_id'])) {
            $select->where('c.coachee_id = ?', $params['coachee_id']);
            $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coach_id',array('l.lgn_nome as coach_nome', 'l.lgn_avatar as coach_avatar'));
            $select->joinLeft(array('a' => 'avaliacao'),'a.user_id_avaliando = c.coach_id',array('a.avaliacao'));

            if ( isset($params['unique']) ) {
                $select->group("coach_id");
            }            
        }        
        // $select->order('l.lgn_nome ASC');

        return $select;
    }
    /**
     * Recupera todos os dados baseado nos dados
     * informados na pesquisa
     * @param $params array
     * @return Zend_Db_Table_Rowset
     */
    public function pesquisar($params = array())
    {
        $select = $this->getSelectPesquisar($params);
        return $this->fetchAll($select);
    }

    public function combo($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              array(
                                    'l.lgn_id',
                                    'l.lgn_nome'
                                    ));
                       
        $select->where('l.lgn_status <> ?', 'R');                       
        $select->order('l.lgn_nome ASC');

        $dados = $this->fetchAll($select)->toArray();
        $arr_dados = array("0"=>"Selecione");
        foreach ($dados as $dado) {
            $arr_dados[$dado["lgn_id"]] = $dado["lgn_nome"];
        }

        // echo "<pre>";
        // print_r($arr_dados);
        // exit();

        return $arr_dados;
    }

    public function getMySolicitacao($user_id)
    {
        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('c' => 'coaching'),
                              array('c.*'));
                       
        
        $select->where('c.status = ?', 'S');
        
        if ($user_id) {
            $select->where('c.coach_id = ?', $user_id );
            // $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coachee_id',array('l.lgn_nome as coachee_nome', 'l.lgn_avatar as coachee_avatar'));
            
        }

        if (isset($params['coachee_id'])) {
            // $select->where('c.coachee_id = ?', $params['coachee_id']);
            // $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coach_id',array('l.lgn_nome as coach_nome', 'l.lgn_avatar as coach_avatar'));
        }        
        // $select->order('l.lgn_nome ASC');

        // echo "<pre>";
        // print_r($select);
        // exit();

        return $this->fetchAll($select);
    }



    public function getMyCoachees($params = array() )
    {

        $identity   = Zend_Auth::getInstance()->getIdentity();
        $idLogin    = $identity->lgn_id;
        $perfil     = $identity->lgn_lgp_id;

        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('c' => 'coaching'),
                              array('c.*'));
                       // ->joinLeft(array('l' => 'login'),'l.lgn_id = c.coachee_id',array('l.lgn_nome as coachee_nome', 'l.lgn_avatar as coachee_avatar'));

        // echo $perfil;
        if( (int)$perfil == 3 ) {
            $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coach_id',array('l.lgn_nome as coachee_nome', 'l.lgn_avatar as coachee_avatar'));
            $select->where('c.coachee_id = ?', $idLogin );
        }
         
        if( (int)$perfil == 1 or (int)$perfil == 2 ) {
            $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coachee_id',array('l.lgn_nome as coachee_nome', 'l.lgn_avatar as coachee_avatar'));
            $select->where('c.coach_id = ?', $idLogin );
        }            

                       
        

        if( isset($params['id']) ){
            $select->where('c.id = ?', $params['id']);
        }   

        if( isset($params['solicitacao']) ){
            $select->where('c.status <> ?', 'E');
            $select->where('c.status <> ?', 'R');
        }   


        if( isset($params['encerrado']) ){
            $select->joinLeft(array('a' => 'avaliacao'),'a.coaching_id = c.id',array('a.id as avaliacao_id','a.avaliacao', 'a.depoimento', 'a.agradecimento'));
            $select->where('c.status = ?', 'E');
            $select->where('a.user_id_avaliando = ?', $idLogin );
        }
        
        

        // if (isset($params['coachee_id'])) {
            // $select->where('c.coachee_id = ?', $params['coachee_id']);
            // $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coach_id',array('l.lgn_nome as coach_nome', 'l.lgn_avatar as coach_avatar'));
        // }        
        $select->order('c.data DESC');

        // echo "<pre>";
        // print_r($select);
        // exit();

        return $this->fetchAll($select);
    }

    public function getCoaching($params = array() )
    {

        $identity   = Zend_Auth::getInstance()->getIdentity();
        $idLogin    = $identity->lgn_id;
        $perfil     = $identity->lgn_lgp_id;


        // $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('c' => 'coaching'),
                              array('c.*'));

                    
        // echo $perfil;
        if( (int)$perfil == 3 ) {
            $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coach_id',array('l.*'));
        }
         
        if( (int)$perfil == 1 or (int)$perfil == 2 ) {
            $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coachee_id',array('l.*'));            
        }            

        if ( isset($params['recusado']) and $params['recusado'] == 'S') {
            # code...
        }else{
            $select->where('c.status <> ?', 'R');    
        }

        if( isset($params['id']) ){
            $select->where('c.id = ?', $params['id']);
        }   


        // echo "<pre>";
        // print_r($select);
        // exit();       

        // if (isset($params['coachee_id'])) {
            // $select->where('c.coachee_id = ?', $params['coachee_id']);
            // $select->joinLeft(array('l' => 'login'),'l.lgn_id = c.coach_id',array('l.lgn_nome as coach_nome', 'l.lgn_avatar as coach_avatar'));
        // }        
        $select->order('c.data DESC');

        // echo "<pre>";
        // print_r($select);
        // exit();

        return $this->fetchAll($select);
    }


}
