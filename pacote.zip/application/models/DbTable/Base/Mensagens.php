<?php

class Application_Model_DbTable_Base_Mensagens extends Base_Db_Table
{
    
    protected $_name = 'mensagens';
    protected $_primary = 'id';


    public function getSelectPesquisar($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('m' => 'mensagens'),
                              array('m.*'));
                       
        
        $select->where('m.status <> ?', 'R');                       
        
        if (isset($params['coach_id'])) {
            $select->where('m.coach_id = ?', $params['coach_id']);
            // $select->joinLeft(array('l' => 'login'),'l.lgn_id = m.coachee_id',array('l.lgn_nome as coachee_nome', 'l.lgn_avatar as coachee_avatar'));
            
        }

        if (isset($params['coachee_id'])) {
            $select->where('m.coachee_id = ?', $params['coachee_id']);
            // $select->joinLeft(array('l' => 'login'),'l.lgn_id = m.coach_id',array('l.lgn_nome as coach_nome', 'l.lgn_avatar as coach_avatar'));
        }        
        // $select->order('l.lgn_nome ASC');

        return $select;
    }
    /**
     * Recupera todos os dados baseado nos dados
     * informados na pesquisa
     * @param $params array
     * @return Zend_Db_Table_Rowset
     */
    public function pesquisar($params = array())
    {
        $select = $this->getSelectPesquisar($params);
        return $this->fetchAll($select);
    }

    
    /*public function pesquisar()
    {

        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'mensagens'));//->where("id_especialidade = '$id_area' ")

        $select->order('id ASC');
        return $this->fetchAll($select);
    }*/


}
