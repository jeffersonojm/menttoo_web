<?php

class Application_Model_DbTable_Base_PerfisSalvo extends Base_Db_Table
{
    
    protected $_name = 'perfis_salvo';
    protected $_primary = 'id';

    
    public function list_all($lgn_id, $order = 'ASC', $nome)
    {

        $select = $this->select()
                                ->setIntegrityCheck(false)
                                ->from(array('PS' => 'perfis_salvo'), array('PS.*'))
                                ->joinLeft(array('L' => 'login'),'L.lgn_id = PS.perfil_id');

                                // if( !empty($nome) ){
                                //     $select->where("PS.id_coachee = '$lgn_id' AND L.lgn_nome LIKE '%$nome%' ");
                                // }else{
                                //     $select->where("PS.id_coachee = '$lgn_id' ");
                                // }





      // $select->order('L.lgn_nome '.$order);
      return $this->fetchAll($select);

    }



    public function getSelectPesquisar($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('ps' => 'perfis_salvo'),
                              array('ps.*'));
                       
        
        if (isset($params['user_id'])) {
            $select->where('ps.user_id = ?', $params['user_id']);
            $select->joinLeft(array('l' => 'login'),'l.lgn_id = ps.perfil_id',array('l.*'));
            
        }

        if (isset($params['perfil_id'])) {
            $select->where('ps.perfil_id = ?', $params['perfil_id']);
            $select->joinLeft(array('l' => 'login'),'l.lgn_id = ps.user_id',array('l.*'));
        }        
        // $select->order('l.lgn_nome ASC');

        return $select;
    }
    /**
     * Recupera todos os dados baseado nos dados
     * informados na pesquisa
     * @param $params array
     * @return Zend_Db_Table_Rowset
     */
    public function pesquisar($params = array())
    {
        $select = $this->getSelectPesquisar($params);
        return $this->fetchAll($select);
    }


// ====================


}
