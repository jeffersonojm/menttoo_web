<?php

class Application_Model_DbTable_Base_Notificacoes extends Base_Db_Table
{
    protected $_name = 'notificacoes';
    protected $_primary = 'id';

    
    public function pesquisar($lgn_id)
    {


        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'notificacoes'))->where("lgn_id = '$lgn_id' ");

        $select->order('data DESC');

        return $this->fetchAll($select);
    }



    
    public function getList($params)
    {


        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('n' => 'notificacoes'),
                              array('n.*'));

        if (isset($params['lgn_id'])) {
            $select->where('n.lgn_id = ?', $params['lgn_id']);
        }



        if (isset($params['status'])) {
            $select->where('n.status = ?', $params['status']);
        }

        $select->order('data DESC');

        return $this->fetchAll($select);
    }

    public function getCount($params)
    {


        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('n' => 'notificacoes'),
                              array('count(*) as quantidade'));

        if (isset($params['lgn_id'])) {
            $select->where('n.lgn_id = ?', $params['lgn_id']);
        }



        if (isset($params['status'])) {
            $select->where('n.status = ?', $params['status']);
        }

        $select->order('data DESC');

        return $this->fetchAll($select);
    }

}
