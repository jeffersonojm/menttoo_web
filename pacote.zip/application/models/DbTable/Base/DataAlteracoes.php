<?php

class Application_Model_DbTable_Base_DataAlteracoes extends Base_Db_Table
{
    protected $_name    = 'data_alteracoes';
    protected $_primary = 'id';




    public function pesquisar($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->from(array('da' => 'data_alteracoes'),
                              array('da.*'));
        if (isset($params['user_id'])) {
            $select->where('da.user_id = ?', $params['user_id'] );
        }
        
        if (isset($params['area_id'])) {
            $select->where('da.area_id = ?', $params['area_id'] );
        }

        // $select->order('p.lgp_nome ASC');
        return $this->fetchAll($select);
    }

}
