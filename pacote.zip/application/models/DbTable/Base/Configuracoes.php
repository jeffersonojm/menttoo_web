<?php

class Application_Model_DbTable_Base_Configuracoes extends Base_Db_Table
{
    protected $_name = 'configuracoes';
    protected $_primary = 'id';

    
    public function readOne($lgn_id)
    {

        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'configuracoes'))->where("lgn_id = '$lgn_id' ");

        $select->order('id ASC');
        return $this->fetchAll($select);
    }

}
