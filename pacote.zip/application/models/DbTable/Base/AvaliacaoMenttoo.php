<?php

class Application_Model_DbTable_Base_AvaliacaoMenttoo extends Base_Db_Table
{
    protected $_name         = 'avaliacao_menttoo';
    protected $_primary      = 'id';
    // protected $_referenceMap = array(array('refTableClass' => 'Application_Model_DbTable_Base_LoginPerfil',
    //                                        'refColumns'    => 'lgp_id',
    //                                        'columns'       => 'lgn_lgp_id'),
    //                                 array('refTableClass' => 'Application_Model_DbTable_Base_Cidades',
    //                                        'refColumns'    => 'cid_id',
    //                                        'columns'       => 'lgn_cid_id')
    //                                 );
    public function getSelectPesquisar($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('c' => 'avaliacao_menttoo'),
                              array('c.*'));
        
        $select->where('c.status <> ?', 'R');                       
        
        if (isset($params['user_id'])) {
            $select->where('c.user_id = ?', $params['user_id']);
        }
        // $select->order('l.lgn_nome ASC');

        return $select;
    }
    /**
     * Recupera todos os dados baseado nos dados
     * informados na pesquisa
     * @param $params array
     * @return Zend_Db_Table_Rowset
     */
    public function pesquisar($params = array())
    {
        $select = $this->getSelectPesquisar($params);
        return $this->fetchAll($select);
    }

    public function combo($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              array(
                                    'l.lgn_id',
                                    'l.lgn_nome'
                                    ));
                       
        $select->where('l.lgn_status <> ?', 'R');                       
        $select->order('l.lgn_nome ASC');

        $dados = $this->fetchAll($select)->toArray();
        $arr_dados = array("0"=>"Selecione");
        foreach ($dados as $dado) {
            $arr_dados[$dado["lgn_id"]] = $dado["lgn_nome"];
        }

        // echo "<pre>";
        // print_r($arr_dados);
        // exit();

        return $arr_dados;
    }

    public function getAvaliacaoUser($params = array())
    {

        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('a' => 'avaliacao_menttoo'),
                              array('SUM(a.avaliacao_menttoo) as avaliacao_menttoo', 'COUNT(a.id) as quantidade'));
        
        $select->where('a.status <> ?', 'R');                       
        
        if (isset($params['user_id_avaliado'])) {
            $select->where('a.user_id_avaliado = ?', $params['user_id_avaliado']);
        }
        // echo "<pre>";
        // print_r( $this->fetchAll($select) );
        // exit();
        return $this->fetchAll($select);
    }

    public function getAvaliacao($params = array())
    {

        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('a' => 'avaliacao_menttoo'),
                              array('a.*'))
                       ->joinLeft(array('l' => 'login'),'l.lgn_id = a.user_id',array('l.lgn_nome as user_nome', 'l.lgn_avatar as user_avatar'))
                       ->joinLeft(array('c' => 'coaching'),'c.id = a.coaching_id',array('c.life_coaching', 'c.executive_coaching'));

        
        $select->where('a.status <> ?', 'R');                       
        
        if (isset($params['user_id_avaliado'])) {
            $select->where('a.user_id_avaliado = ?', $params['user_id_avaliado']);
        }
        
        
        if (isset($params['coaching_id'])) {
            $select->where('a.coaching_id = ?', $params['coaching_id']);
        }


        if (isset($params['id'])) {
            $select->where('a.id = ?', $params['id']);
        }

        $select->limit(5);

        $select->order('a.data DESC');
        

        return $this->fetchAll($select);
    }

}
