<?php

class Application_Model_DbTable_Base_Segmento extends Base_Db_Table
{
    protected $_name         = 'segmento';
    protected $_primary      = 'id';
    // protected $_referenceMap = array(array('refTableClass' => 'Application_Model_DbTable_Base_LoginPerfil',
    //                                        'refColumns'    => 'lgp_id',
    //                                        'columns'       => 'lgn_lgp_id'),
    //                                 array('refTableClass' => 'Application_Model_DbTable_Base_Cidades',
    //                                        'refColumns'    => 'cid_id',
    //                                        'columns'       => 'lgn_cid_id')
    //                                 );
    public function getSelectPesquisar($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('sl' => 'segmento'),
                              array('sl.*'));
        $select->where('sl.status <> ?', 'R');        

        // if (isset($params['nome'])) {
        //     $select->where('LOWER(l.lgn_nome) like ?', '%' . strtolower($params['nome']) . '%');
        // }
        // if (isset($params['email'])) {
        //     $select->where('LOWER(l.lgn_email) like ?', '%' . strtolower($params['email']) . '%');
        // }
        if (isset($params['user_id'])) {
            $select->where('sl.user_id = ?', $params['user_id']);
        }
        // $select->order('sl.lgn_nome ASC');

        return $select;
    }
    /**
     * Recupera todos os dados baseado nos dados
     * informados na pesquisa
     * @param $params array
     * @return Zend_Db_Table_Rowset
     */
    public function pesquisar($params = array())
    {
        $select = $this->getSelectPesquisar($params);
        return $this->fetchAll($select);
    }

    public function combo($params = array())
    {
        $params = $this->filtrar($params);
        $select = $this->select()
                       ->setIntegrityCheck(false)
                       ->from(array('l' => 'login'),
                              array(
                                    'l.lgn_id',
                                    'l.lgn_nome'
                                    ));
                       
        $select->where('l.lgn_status <> ?', 'R');                       
        $select->order('l.lgn_nome ASC');

        $dados = $this->fetchAll($select)->toArray();
        $arr_dados = array("0"=>"Selecione");
        foreach ($dados as $dado) {
            $arr_dados[$dado["lgn_id"]] = $dado["lgn_nome"];
        }

        // echo "<pre>";
        // print_r($arr_dados);
        // exit();

        return $arr_dados;
    }

}
