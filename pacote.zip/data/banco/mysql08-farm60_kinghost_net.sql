-- phpMyAdmin SQL Dump
-- version 4.3.7
-- http://www.phpmyadmin.net
--
-- Host: mysql08-farm60.kinghost.net
-- Tempo de geração: 31/05/2017 às 19:17
-- Versão do servidor: 5.5.43-log
-- Versão do PHP: 5.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `menttoo05`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `avaliacao`
--

CREATE TABLE IF NOT EXISTS `avaliacao` (
  `id` int(11) NOT NULL,
  `user_id_avaliando` int(11) NOT NULL,
  `user_id_avaliado` int(11) NOT NULL,
  `coaching_id` int(11) DEFAULT NULL,
  `avaliacao` float NOT NULL,
  `depoimento` text,
  `agradecimento` text,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `avaliacao`
--

INSERT INTO `avaliacao` (`id`, `user_id_avaliando`, `user_id_avaliado`, `coaching_id`, `avaliacao`, `depoimento`, `agradecimento`, `data`, `status`) VALUES
(1, 1, 2, 1, 3, 'Cláudia fez a diferença na minha vida. Com certeza será alguém que vou indicar outras vezes.', 'd;kf d, f;ksdmf dsf', '2017-05-22 21:28:51', 'A'),
(2, 2, 1, 1, 5, 'Fabiano foi uma pessoa sensacional e com certeza sai desse processo mais preparado.', 'vfsvdsfvd sdff dsfds f dsf ', '2017-05-22 21:29:49', 'A'),
(3, 6, 4, 2, 4, NULL, NULL, '2017-05-28 21:01:20', 'A'),
(4, 6, 4, 3, 4, 'fgdgdf  fdgdf fgdfg', 'fgdfgdf', '2017-05-28 21:02:07', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `avaliacao_menttoo`
--

CREATE TABLE IF NOT EXISTS `avaliacao_menttoo` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `coaching_id` int(11) NOT NULL,
  `avaliacao` float NOT NULL,
  `mensagem` text,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `avaliacao_menttoo`
--

INSERT INTO `avaliacao_menttoo` (`id`, `user_id`, `coaching_id`, `avaliacao`, `mensagem`, `data`, `status`) VALUES
(1, 1, 1, 4, NULL, '2017-05-22 21:29:00', 'A'),
(2, 2, 1, 4, 'wfwefwefewf fewf wef', '2017-05-22 21:29:54', 'A'),
(3, 6, 2, 4, NULL, '2017-05-28 21:01:26', 'A'),
(4, 6, 3, 4, 'dfgdf gdfgdf', '2017-05-28 21:02:14', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cidade`
--

CREATE TABLE IF NOT EXISTS `cidade` (
  `cid_id` int(11) NOT NULL,
  `est_uf` varchar(4) NOT NULL DEFAULT '',
  `cid_nome` varchar(100) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `cliente_indicado`
--

CREATE TABLE IF NOT EXISTS `cliente_indicado` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nome` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `ddd` varchar(250) DEFAULT NULL,
  `telefone` varchar(250) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `coach_indicado`
--

CREATE TABLE IF NOT EXISTS `coach_indicado` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `coach_id` int(11) DEFAULT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `coaching`
--

CREATE TABLE IF NOT EXISTS `coaching` (
  `id` int(11) NOT NULL,
  `coach_id` int(11) NOT NULL,
  `coachee_id` int(11) NOT NULL,
  `objetivo` text,
  `life_coaching` int(11) NOT NULL DEFAULT '0',
  `executive_coaching` int(11) NOT NULL DEFAULT '0',
  `justificativa_recusa` text,
  `mensagem_boas_vindas` text,
  `mensagem_encerramento` text,
  `user_closed` int(11) NOT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_closed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data_termino` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'S' COMMENT 'S - Solicitado; A - Ativo; E - Encerrado; R - Recusado'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `coaching`
--

INSERT INTO `coaching` (`id`, `coach_id`, `coachee_id`, `objetivo`, `life_coaching`, `executive_coaching`, `justificativa_recusa`, `mensagem_boas_vindas`, `mensagem_encerramento`, `user_closed`, `data`, `data_closed`, `data_termino`, `status`) VALUES
(1, 2, 1, 'vslkmsdmdsnlf fkl dslkf lsdknflkds lmgf sdklmgsdg', 0, 2, NULL, 'Show, vamos nessa', 'fnv smlvn vknklv dgbnwek vfm', 1, '2017-05-22 21:25:16', '2017-05-22 18:27:38', '2017-11-22', 'E'),
(2, 6, 4, 'Quero ficar grande.\r\n', 1, 0, NULL, 'Ok Luciano, vamos trabalhar isso pra valer!!', 'Foi mto bacana mas deu!!', 4, '2017-05-28 20:44:38', '2017-05-28 17:59:31', '2017-08-28', 'E'),
(3, 6, 4, 'ndnzn', 1, 0, NULL, 'rferf', 'sfgsfgf', 6, '2017-05-28 21:01:08', '2017-05-28 18:01:58', '2017-08-28', 'E'),
(5, 3, 10, '32132132', 0, 2, NULL, NULL, NULL, 0, '2017-05-29 20:31:34', '0000-00-00 00:00:00', '2017-06-29', 'S');

-- --------------------------------------------------------

--
-- Estrutura para tabela `comprovante`
--

CREATE TABLE IF NOT EXISTS `comprovante` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `arquivo` varchar(250) DEFAULT NULL,
  `horas` varchar(250) DEFAULT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `comprovante`
--

INSERT INTO `comprovante` (`id`, `user_id`, `arquivo`, `horas`, `data`, `status`) VALUES
(1, 2, '10104C7F4F.xlsx', '123', '2017-05-22 20:32:33', 'A'),
(2, 6, '59833536C1.xlsx', '134', '2017-05-28 20:25:24', 'A'),
(3, 6, '9762881FE2.xlsx', '134', '2017-05-28 20:42:05', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `configuracoes`
--

CREATE TABLE IF NOT EXISTS `configuracoes` (
  `id` int(11) NOT NULL,
  `lgn_id` int(1) NOT NULL,
  `nova_mensagem` int(1) NOT NULL,
  `novo_mentor_plataforma` int(1) NOT NULL,
  `atualizacao_menttoo` int(1) NOT NULL,
  `encerramento_mentoria` int(1) NOT NULL,
  `outra` int(1) NOT NULL,
  `data_alteracao` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `credencial`
--

CREATE TABLE IF NOT EXISTS `credencial` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `arquivo` varchar(250) DEFAULT NULL,
  `data_validade` date DEFAULT NULL,
  `titulo` varchar(250) DEFAULT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `credencial`
--

INSERT INTO `credencial` (`id`, `user_id`, `arquivo`, `data_validade`, `titulo`, `data`, `status`) VALUES
(1, 2, 'DEE255B310.jpg', '2001-05-12', 'ICF', '2017-05-22 20:32:33', 'A'),
(2, 6, 'D73F371E63.jpg', '2013-01-01', 'ICF', '2017-05-28 20:25:24', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `curriculo`
--

CREATE TABLE IF NOT EXISTS `curriculo` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `url` varchar(250) DEFAULT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `curriculo`
--

INSERT INTO `curriculo` (`id`, `user_id`, `url`, `data`, `status`) VALUES
(3, 6, 'https://www.linkedin.com/in/fabianosanroma/', '2017-05-28 20:42:05', 'A'),
(4, 2, 'http://programaevoluirh.com.br/', '2017-05-29 21:46:38', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cursos`
--

CREATE TABLE IF NOT EXISTS `cursos` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `arquivo` varchar(250) DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_fim` date DEFAULT NULL,
  `nome_escola` varchar(250) DEFAULT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `data_alteracoes`
--

CREATE TABLE IF NOT EXISTS `data_alteracoes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `area_id` int(11) DEFAULT NULL COMMENT '1 = Perfil dados pessoais;  2 = Perfil Formação; 3 = Perfil Credencial; 4 = Perfil Processo de coaching; 5 = Perfil Limite de tempo para o processo de coaching; 6 = Perfil Preço por sessão; 7 = Perfil Video destaque; 8 = Perfil Experiencia; 9 = Perfil Cursos; 10 = Perfil Projetos; 11 = Perfil Reconhecimentos; 12 = Configuracoes Notificações e-mails;',
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `data_alteracoes`
--

INSERT INTO `data_alteracoes` (`id`, `user_id`, `area_id`, `data`, `status`) VALUES
(1, 3, 2, '2017-05-26 13:45:58', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `diploma`
--

CREATE TABLE IF NOT EXISTS `diploma` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `arquivo` varchar(250) DEFAULT NULL,
  `data_encerramento` date DEFAULT NULL,
  `nome_escola` varchar(250) DEFAULT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `diploma`
--

INSERT INTO `diploma` (`id`, `user_id`, `arquivo`, `data_encerramento`, `nome_escola`, `data`, `status`) VALUES
(1, 2, 'BE7D2388E7.jpg', '1999-03-12', 'IBC', '2017-05-22 20:32:33', 'A'),
(3, 3, 'E3C6CBCE03.pdf', '1983-10-10', 'nome da escola', '2017-05-26 13:56:55', 'A'),
(4, 6, '30C058FD05.jpg', '2012-01-01', 'SLAC', '2017-05-28 20:25:24', 'A'),
(5, 6, '5EEF95659E.jpg', '2012-01-01', 'SLAC', '2017-05-28 20:42:05', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `estado`
--

CREATE TABLE IF NOT EXISTS `estado` (
  `est_id` int(10) NOT NULL,
  `est_uf` varchar(255) NOT NULL,
  `est_nome` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `estado`
--

INSERT INTO `estado` (`est_id`, `est_uf`, `est_nome`) VALUES
(1, 'AC', 'Acre'),
(2, 'AL', 'Alagoas'),
(3, 'AM', 'Amazonas'),
(4, 'AP', 'Amapá'),
(5, 'BA', 'Bahia'),
(6, 'CE', 'Ceará'),
(7, 'DF', 'Distrito Federal'),
(8, 'ES', 'Espírito Santo'),
(9, 'GO', 'Goiás'),
(10, 'MA', 'Maranhão'),
(11, 'MG', 'Minas Gerais'),
(12, 'MS', 'Mato Grosso do Sul'),
(13, 'MT', 'Mato Grosso'),
(14, 'PA', 'Pará'),
(15, 'PB', 'Paraíba'),
(16, 'PE', 'Pernambuco'),
(17, 'PI', 'Piauí'),
(18, 'PR', 'Paraná'),
(19, 'RJ', 'Rio de Janeiro'),
(20, 'RN', 'Rio Grande do Norte'),
(21, 'RO', 'Rondônia'),
(22, 'RR', 'Roraima'),
(23, 'RS', 'Rio Grande do Sul'),
(24, 'SC', 'Santa Catarina'),
(25, 'SE', 'Sergipe'),
(26, 'SP', 'São Paulo'),
(27, 'TO', 'Tocantins');

-- --------------------------------------------------------

--
-- Estrutura para tabela `experiencia`
--

CREATE TABLE IF NOT EXISTS `experiencia` (
  `id` int(11) NOT NULL,
  `lgn_id` int(11) DEFAULT NULL,
  `onde_esta_trabalhando` varchar(255) DEFAULT NULL,
  `cargo` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `de` date DEFAULT NULL,
  `ate` date DEFAULT NULL,
  `atual` int(1) DEFAULT NULL,
  `biografia` text,
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `lgn_id` int(10) unsigned NOT NULL,
  `lgn_lgp_id` int(10) unsigned NOT NULL DEFAULT '3',
  `lgn_nome` text CHARACTER SET latin1,
  `lgn_email` varchar(200) CHARACTER SET latin1 NOT NULL,
  `lgn_senha` text CHARACTER SET latin1,
  `lgn_senha_redes` varchar(250) COLLATE latin1_general_cs DEFAULT NULL,
  `lgn_ddd` varchar(20) COLLATE latin1_general_cs DEFAULT NULL,
  `lgn_telefone` varchar(30) COLLATE latin1_general_cs DEFAULT NULL,
  `lgn_data_nascimento` date DEFAULT NULL,
  `lgn_bio` text COLLATE latin1_general_cs,
  `lgn_uf` varchar(20) COLLATE latin1_general_cs DEFAULT NULL,
  `lgn_cidade` varchar(250) COLLATE latin1_general_cs DEFAULT NULL,
  `lgn_avatar` varchar(250) COLLATE latin1_general_cs DEFAULT NULL,
  `lgn_codigo_convite` varchar(25) COLLATE latin1_general_cs DEFAULT NULL,
  `lgn_processo_coaching` varchar(20) COLLATE latin1_general_cs DEFAULT 'ambos',
  `lgn_duracao_media` varchar(20) COLLATE latin1_general_cs DEFAULT NULL,
  `lgn_preco_sessao` varchar(20) COLLATE latin1_general_cs DEFAULT NULL,
  `lgn_cadastro_completo` int(2) NOT NULL DEFAULT '0',
  `lgn_validado` int(11) NOT NULL DEFAULT '0',
  `lgn_origem_cadastro` int(2) NOT NULL DEFAULT '0' COMMENT '0 = menttoo; 1 = linkedin; 2 = facebook',
  `lgn_data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `lgn_data_senha` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lgn_status` varchar(20) COLLATE latin1_general_cs NOT NULL DEFAULT 'S' COMMENT 'S=Solicitacao de cadastro coach, A = Ativo, I = Inativo, R = Removido, C = complete o cadastro'
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs ROW_FORMAT=COMPACT;

--
-- Fazendo dump de dados para tabela `login`
--

INSERT INTO `login` (`lgn_id`, `lgn_lgp_id`, `lgn_nome`, `lgn_email`, `lgn_senha`, `lgn_senha_redes`, `lgn_ddd`, `lgn_telefone`, `lgn_data_nascimento`, `lgn_bio`, `lgn_uf`, `lgn_cidade`, `lgn_avatar`, `lgn_codigo_convite`, `lgn_processo_coaching`, `lgn_duracao_media`, `lgn_preco_sessao`, `lgn_cadastro_completo`, `lgn_validado`, `lgn_origem_cadastro`, `lgn_data`, `lgn_data_senha`, `lgn_status`) VALUES
(1, 3, 'Fabiano Sanromã', 'fabiano@sanromadesign.com', '81dc9bdb52d04dc20036dbd8313ed055', NULL, '61', '98636-3736', '1984-02-03', NULL, '0', NULL, 'A9B1DD77B9.jpg', NULL, NULL, NULL, NULL, 1, 0, 0, '2017-05-22 20:06:32', '0000-00-00 00:00:00', 'A'),
(2, 3, 'Cláudia Feijó', 'sanroma@agenciaflw.com.br', '81dc9bdb52d04dc20036dbd8313ed055', NULL, '61', '98636-3739', '1974-12-02', 'Minha atuação é exclusivamente como Coach de Carreira. Meu público principal são profissionais de Recursos Humanos que se encontram em uma fase intermediária da carreira, ou seja, já possuem bastante experiência na área e precisam decidir o próximo passo. Conheço muito bem esse público, pois trabalh', 'DF', 'Brasília', '5EB3FE4895.jpg', '5BC034', 'on', '6', '150,00', 1, 0, 0, '2017-05-22 20:26:17', '0000-00-00 00:00:00', 'A'),
(3, 2, 'Jefferson Monteiro', 'jeffersonojm@gmail.com', 'b5e9674f9acc8827038faa53503f710e', NULL, '61', '98593-9668', '1983-10-24', 'asdfasddf', 'DF', 'Brasilia', '99E042308A.jpg', '5BC035', 'ambos', '1', '300,00', 1, 0, 0, '2017-05-24 01:44:27', '0000-00-00 00:00:00', 'A'),
(4, 3, 'Luciano Costa', 'sanromdesign@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', NULL, '61', '98636-3736', NULL, 'É isso aí. Vamos melhorar!!', 'DF', 'Brasilia ', '4FBB4BAEC4.JPG', NULL, NULL, NULL, NULL, 1, 0, 0, '2017-05-28 19:56:58', '0000-00-00 00:00:00', 'A'),
(6, 2, 'André Luiz', 'fabiano@menttoo.com', '81dc9bdb52d04dc20036dbd8313ed055', NULL, '61', '98636-3736', '1984-02-03', 'Fabiano é carioca, tem 10 anos de profissão e cursou faculdade de design. No Rio de Janeiro fez importantes trabalhos para Petrobrás, Globo, Globosat e Grupo EBX. Foi vencedor de prêmios nacionais e internacionais, como Colunistas Rio e Brasil e AMPRO Globes Awards. Está em Brasília há 7 anos, onde ', 'RJ', 'Rio de janeiro', '04F3DDAE94.jpg', 'A4613D', 'ambos', '3', '150,00', 1, 0, 0, '2017-05-28 20:25:24', '0000-00-00 00:00:00', 'A'),
(7, 3, 'Aline Sanromã', 'alinesanroma@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', NULL, '61', '98636-3871', '0303-03-03', 'djlkvnlsd vldfvl eflv eflkjvnklepvijm', 'AL', 'Csdfc', NULL, NULL, NULL, NULL, NULL, 1, 0, 0, '2017-05-28 21:07:29', '0000-00-00 00:00:00', 'A'),
(10, 3, 'Jefferson Monteiro coachee', 'jefferson@menttoo.com', 'b5e9674f9acc8827038faa53503f710e', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ambos', NULL, NULL, 1, 0, 0, '2017-05-29 20:11:37', '0000-00-00 00:00:00', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `login_perfil`
--

CREATE TABLE IF NOT EXISTS `login_perfil` (
  `lgp_id` int(10) unsigned NOT NULL,
  `lgp_nome` text,
  `lgp_descricao` text
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Fazendo dump de dados para tabela `login_perfil`
--

INSERT INTO `login_perfil` (`lgp_id`, `lgp_nome`, `lgp_descricao`) VALUES
(1, 'Administrador Master', 'Acesso total ao sistema'),
(2, 'Coach', 'Coach'),
(3, 'Coachee', 'Coachee');

-- --------------------------------------------------------

--
-- Estrutura para tabela `mensagens`
--

CREATE TABLE IF NOT EXISTS `mensagens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `coach_id` int(11) NOT NULL,
  `mensagem` text NOT NULL,
  `resposta` text NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_resposta` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `mensagens`
--

INSERT INTO `mensagens` (`id`, `user_id`, `coach_id`, `mensagem`, `resposta`, `data`, `data_resposta`, `status`) VALUES
(1, 1, 2, 'testeando 123', 'fulano de tal é isso ai vamos nessa bagaça', '2017-05-22 20:38:06', '2017-05-22 17:39:38', 0),
(2, 1, 2, 'teste de novo', 'ok, combinado', '2017-05-22 20:40:32', '2017-05-22 17:41:13', 0),
(3, 2, 2, 'teste', 'teste', '2017-05-22 22:21:55', '2017-05-22 19:22:07', 0),
(4, 4, 2, 'seguinte. Mando essa msg apenas para tirar uma dúvida!!', 'Ok. Dúvida tirada', '2017-05-28 20:05:55', '2017-05-28 17:19:28', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `notificacoes`
--

CREATE TABLE IF NOT EXISTS `notificacoes` (
  `id` int(11) NOT NULL,
  `lgn_id` int(11) DEFAULT NULL,
  `coaching_id` int(11) DEFAULT NULL,
  `msg_id` int(11) DEFAULT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `texto` text,
  `status` int(1) NOT NULL DEFAULT '0',
  `tipo` int(1) DEFAULT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `notificacoes`
--

INSERT INTO `notificacoes` (`id`, `lgn_id`, `coaching_id`, `msg_id`, `titulo`, `texto`, `status`, `tipo`, `data`) VALUES
(1, 2, NULL, 1, 'Fabiano Sanromã', 'Você não respondeu uma mensagem de Fabiano Sanromã! Não deixe seus coachees na mão :)', 1, 6, '2017-05-22 20:39:14'),
(2, 1, NULL, 1, 'Cláudia Feijó', 'Respondeu sua mensagem', 1, 6, '2017-05-22 20:40:04'),
(3, 2, NULL, 2, 'Fabiano Sanromã', 'Você não respondeu uma mensagem de Fabiano Sanromã! Não deixe seus coachees na mão :)', 1, 6, '2017-05-22 20:40:41'),
(4, 1, NULL, 2, 'Cláudia Feijó', 'Respondeu sua mensagem', 1, 6, '2017-05-22 20:41:18'),
(5, 2, 1, NULL, 'Solicitação de coaching', 'Que tal começar agora?', 1, 4, '2017-05-22 21:26:06'),
(6, 1, 1, NULL, 'Parabéns! Processo de coaching iniciado', 'Agora você pode ter acesso aos contatos pessoais do coaching e falar diretamente com ele. CLIQUE AQUI E VEJA', 1, 2, '2017-05-22 21:27:22'),
(7, 2, 1, NULL, 'Coaching encerrado. Faça a sua avaliação', 'O ciclo de mentoria foi encerrado. Faça sua avaliação', 1, 3, '2017-05-22 21:29:15'),
(8, 2, NULL, 3, 'Cláudia Feijó', 'Você não respondeu uma mensagem de Cláudia Feijó! Não deixe seus coachees na mão :)', 1, 6, '2017-05-22 22:22:02'),
(9, 2, NULL, 3, 'Cláudia Feijó', 'Respondeu sua mensagem', 1, 6, '2017-05-22 22:22:11'),
(10, 2, NULL, 4, 'Luciano Costa', 'Você não respondeu uma mensagem de Luciano Costa! Não deixe seus coachees na mão :)', 1, 6, '2017-05-28 20:19:10'),
(11, 4, NULL, 4, 'Cláudia Feijó', 'Respondeu sua mensagem', 1, 6, '2017-05-28 20:43:20'),
(12, 6, 2, NULL, 'Solicitação de coaching', 'Que tal começar agora?', 1, 4, '2017-05-28 20:53:39'),
(13, 4, 2, NULL, 'Parabéns! Processo de coaching iniciado', 'Agora você pode ter acesso aos contatos pessoais do coaching e falar diretamente com ele. CLIQUE AQUI E VEJA', 1, 2, '2017-05-28 20:57:32'),
(14, 6, 2, NULL, 'Coaching encerrado. Faça a sua avaliação', 'O ciclo de mentoria foi encerrado. Faça sua avaliação', 1, 3, '2017-05-28 21:01:50'),
(15, 6, 2, NULL, 'Coaching encerrado. Faça a sua avaliação', 'O ciclo de mentoria foi encerrado. Faça sua avaliação', 1, 3, '2017-05-28 21:00:42'),
(16, 6, 3, NULL, 'Solicitação de coaching', 'Que tal começar agora?', 1, 4, '2017-05-28 21:01:36'),
(17, 4, 3, NULL, 'Parabéns! Processo de coaching iniciado', 'Agora você pode ter acesso aos contatos pessoais do coaching e falar diretamente com ele. CLIQUE AQUI E VEJA', 1, 2, '2017-05-28 21:02:26'),
(18, 4, 3, NULL, 'Coaching encerrado. Faça a sua avaliação', 'O ciclo de mentoria foi encerrado. Faça sua avaliação', 1, 3, '2017-05-28 21:02:30'),
(19, 3, 4, NULL, 'Solicitação de coaching', 'Que tal começar agora?', 1, 4, '2017-05-31 22:11:39'),
(20, 10, 4, NULL, 'Parabéns! Processo de coaching iniciado', 'Agora você pode ter acesso aos contatos pessoais do coaching e falar diretamente com ele. CLIQUE AQUI E VEJA', 0, 2, '2017-05-29 20:23:29'),
(21, 3, 5, NULL, 'Solicitação de coaching', 'Que tal começar agora?', 1, 4, '2017-05-31 22:11:14');

-- --------------------------------------------------------

--
-- Estrutura para tabela `perfis_salvo`
--

CREATE TABLE IF NOT EXISTS `perfis_salvo` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `perfis_salvo`
--

INSERT INTO `perfis_salvo` (`id`, `user_id`, `perfil_id`, `data`) VALUES
(1, 1, 2, '2017-05-22 20:42:34'),
(2, 4, 2, '2017-05-28 20:06:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `portfolio`
--

CREATE TABLE IF NOT EXISTS `portfolio` (
  `id` int(11) NOT NULL,
  `lgn_id` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `descricao` text,
  `imagem` varchar(255) DEFAULT NULL,
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `premios`
--

CREATE TABLE IF NOT EXISTS `premios` (
  `id` int(11) NOT NULL,
  `lgn_id` int(11) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `empresa_cargo` varchar(255) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `descricao` text,
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `segmento`
--

CREATE TABLE IF NOT EXISTS `segmento` (
  `id` int(11) NOT NULL,
  `nome` varchar(250) NOT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `segmento`
--

INSERT INTO `segmento` (`id`, `nome`, `data`, `status`) VALUES
(1, 'Coach de Relacionamento', '2017-04-08 18:28:56', 'A'),
(2, 'Coach de Produtividade', '2017-04-08 18:28:56', 'A'),
(3, 'Coach de Autoestima', '2017-04-08 18:28:56', 'A'),
(4, 'Coach de Orientação Profissional ', '2017-04-08 18:28:56', 'A'),
(5, 'Coach de Carreira', '2017-04-08 18:28:56', 'A'),
(6, 'Self Coach', '2017-04-08 18:28:56', 'A'),
(7, 'Coach Financeiro', '2017-04-08 18:28:56', 'A'),
(8, 'Coach de Família', '2017-04-08 18:28:56', 'A'),
(9, 'Coach para Homossexuais', '2017-04-08 18:28:56', 'A'),
(10, 'Coach Esportivo ', '2017-04-08 18:28:56', 'A'),
(11, 'Coach de Emagrecimento', '2017-04-08 18:28:56', 'A'),
(12, 'Coach Fitness', '2017-04-08 18:28:56', 'A'),
(13, 'Coach de Performance', '2017-04-08 18:28:56', 'A'),
(14, 'Coach de Concursos', '2017-04-08 18:28:56', 'A'),
(15, 'Coach de Negócios', '2017-04-08 18:28:56', 'A'),
(16, 'Coach de Empreendedorismo', '2017-04-08 18:28:56', 'A'),
(17, 'Coach de Liderança', '2017-04-25 02:25:08', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `segmento_login`
--

CREATE TABLE IF NOT EXISTS `segmento_login` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tipo_id` int(11) NOT NULL,
  `segmento_id` int(11) NOT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `segmento_login`
--

INSERT INTO `segmento_login` (`id`, `user_id`, `tipo_id`, `segmento_id`, `data`, `status`) VALUES
(26, 6, 1, 10, '2017-05-28 20:42:05', 'A'),
(27, 6, 1, 11, '2017-05-28 20:42:05', 'A'),
(28, 6, 1, 12, '2017-05-28 20:42:05', 'A'),
(29, 2, 1, 1, '2017-05-29 21:46:38', 'A'),
(30, 2, 1, 2, '2017-05-29 21:46:38', 'A'),
(31, 2, 1, 3, '2017-05-29 21:46:38', 'A'),
(32, 2, 1, 4, '2017-05-29 21:46:38', 'A'),
(33, 2, 1, 5, '2017-05-29 21:46:38', 'A'),
(34, 2, 1, 6, '2017-05-29 21:46:38', 'A'),
(35, 2, 1, 7, '2017-05-29 21:46:38', 'A'),
(36, 2, 1, 8, '2017-05-29 21:46:38', 'A'),
(37, 2, 1, 9, '2017-05-29 21:46:38', 'A'),
(38, 2, 1, 10, '2017-05-29 21:46:38', 'A'),
(39, 2, 1, 11, '2017-05-29 21:46:38', 'A'),
(40, 2, 1, 12, '2017-05-29 21:46:38', 'A'),
(41, 2, 2, 2, '2017-05-29 21:46:38', 'A'),
(42, 2, 2, 7, '2017-05-29 21:46:38', 'A'),
(43, 2, 2, 13, '2017-05-29 21:46:38', 'A'),
(44, 2, 2, 14, '2017-05-29 21:46:38', 'A'),
(45, 2, 2, 15, '2017-05-29 21:46:38', 'A'),
(46, 2, 2, 16, '2017-05-29 21:46:38', 'A'),
(47, 2, 2, 1, '2017-05-29 21:46:38', 'A'),
(48, 2, 2, 5, '2017-05-29 21:46:38', 'A'),
(49, 2, 2, 6, '2017-05-29 21:46:38', 'A'),
(50, 2, 2, 4, '2017-05-29 21:46:38', 'A'),
(51, 2, 2, 17, '2017-05-29 21:46:38', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `segmento_tipo_coach`
--

CREATE TABLE IF NOT EXISTS `segmento_tipo_coach` (
  `id` int(11) NOT NULL,
  `tipo_coach_id` int(11) NOT NULL,
  `segmento_id` int(11) NOT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `segmento_tipo_coach`
--

INSERT INTO `segmento_tipo_coach` (`id`, `tipo_coach_id`, `segmento_id`, `data`, `status`) VALUES
(1, 1, 1, '2017-03-29 19:59:57', 'A'),
(2, 1, 2, '2017-03-29 19:59:57', 'A'),
(3, 1, 3, '2017-03-29 19:59:57', 'A'),
(4, 1, 4, '2017-03-29 19:59:57', 'A'),
(5, 1, 5, '2017-03-29 19:59:57', 'A'),
(6, 1, 6, '2017-03-29 19:59:57', 'A'),
(7, 1, 7, '2017-03-29 19:59:57', 'A'),
(8, 1, 8, '2017-03-29 19:59:57', 'A'),
(9, 1, 9, '2017-03-29 19:59:57', 'A'),
(10, 1, 10, '2017-03-29 19:59:57', 'A'),
(11, 1, 11, '2017-03-29 19:59:57', 'A'),
(12, 1, 12, '2017-03-29 19:59:57', 'A'),
(13, 2, 2, '2017-03-29 20:01:16', 'A'),
(14, 2, 7, '2017-03-29 20:01:16', 'A'),
(15, 2, 13, '2017-03-29 20:01:16', 'A'),
(16, 2, 14, '2017-03-29 20:01:16', 'A'),
(17, 2, 15, '2017-03-29 20:01:16', 'A'),
(18, 2, 16, '2017-03-29 20:01:16', 'A'),
(19, 2, 1, '2017-03-29 20:01:16', 'A'),
(20, 2, 5, '2017-03-29 20:01:16', 'A'),
(21, 2, 6, '2017-03-29 20:01:16', 'A'),
(22, 2, 4, '2017-04-25 02:23:23', 'A'),
(23, 2, 17, '2017-04-25 02:25:24', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tipo_coach`
--

CREATE TABLE IF NOT EXISTS `tipo_coach` (
  `id` int(11) NOT NULL,
  `nome` varchar(250) NOT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `tipo_coach`
--

INSERT INTO `tipo_coach` (`id`, `nome`, `data`, `status`) VALUES
(1, 'Life Coaching, Personal Coaching (Pessoal)', '2017-03-29 19:30:48', 'A'),
(2, 'Executive e Business Coaching (Profissional)', '2017-03-29 19:30:48', 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `videos`
--

CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `url` varchar(250) DEFAULT NULL,
  `descricao` varchar(250) DEFAULT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'A'
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `videos`
--

INSERT INTO `videos` (`id`, `user_id`, `url`, `descricao`, `data`, `status`) VALUES
(1, 45, 'https://vimeo.com/178633488', 'Fulano de tal bla bla bla e é isso', '2017-04-24 23:25:55', 'A'),
(2, 45, 'https://www.youtube.com/watch?v=poFS5zbr3GQ', 'Somos uma startup que ajuda coaches a captarem clientes e coachees a encontrarem o coach ideal com facilidade, com segurança e sem blá, blá, blá. Saiba mais: http://www.menttoo.com/', '2017-04-24 23:31:35', 'A'),
(3, 54, 'https://www.youtube.com/watch?v=4XRmQF0Uudo', NULL, '2017-04-25 02:51:36', 'A'),
(6, 56, 'https://www.youtube.com/watch?v=2OqPWF2HEeY', 'm m,dszxcdsjcsd vksdv', '2017-04-26 04:12:43', 'A'),
(7, 56, 'https://vimeo.com/214352663', 'knckladsncsdc. sdcmds, c,mad c,', '2017-04-26 04:12:59', 'A'),
(8, 45, 'https://vimeo.com/178633488', 'Subindo o mesmo vídeo de novo', '2017-05-11 16:25:19', 'A'),
(9, 6, 'https://www.youtube.com/watch?v=EjFd4VrImLg', NULL, '2017-05-28 20:42:05', 'A');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `avaliacao`
--
ALTER TABLE `avaliacao`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `avaliacao_menttoo`
--
ALTER TABLE `avaliacao_menttoo`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cidade`
--
ALTER TABLE `cidade`
  ADD UNIQUE KEY `cid_id` (`cid_id`);

--
-- Índices de tabela `cliente_indicado`
--
ALTER TABLE `cliente_indicado`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `coach_indicado`
--
ALTER TABLE `coach_indicado`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `coaching`
--
ALTER TABLE `coaching`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `comprovante`
--
ALTER TABLE `comprovante`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `credencial`
--
ALTER TABLE `credencial`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `curriculo`
--
ALTER TABLE `curriculo`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `data_alteracoes`
--
ALTER TABLE `data_alteracoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `diploma`
--
ALTER TABLE `diploma`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`est_id`);

--
-- Índices de tabela `experiencia`
--
ALTER TABLE `experiencia`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`lgn_id`), ADD UNIQUE KEY `lgn_email` (`lgn_email`), ADD KEY `login_FKIndex1` (`lgn_lgp_id`) COMMENT '(null)';

--
-- Índices de tabela `login_perfil`
--
ALTER TABLE `login_perfil`
  ADD PRIMARY KEY (`lgp_id`);

--
-- Índices de tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `perfis_salvo`
--
ALTER TABLE `perfis_salvo`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `premios`
--
ALTER TABLE `premios`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `segmento`
--
ALTER TABLE `segmento`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `segmento_login`
--
ALTER TABLE `segmento_login`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `segmento_tipo_coach`
--
ALTER TABLE `segmento_tipo_coach`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `tipo_coach`
--
ALTER TABLE `tipo_coach`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `avaliacao`
--
ALTER TABLE `avaliacao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `avaliacao_menttoo`
--
ALTER TABLE `avaliacao_menttoo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `cidade`
--
ALTER TABLE `cidade`
  MODIFY `cid_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `cliente_indicado`
--
ALTER TABLE `cliente_indicado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `coach_indicado`
--
ALTER TABLE `coach_indicado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `coaching`
--
ALTER TABLE `coaching`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de tabela `comprovante`
--
ALTER TABLE `comprovante`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `credencial`
--
ALTER TABLE `credencial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `curriculo`
--
ALTER TABLE `curriculo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `data_alteracoes`
--
ALTER TABLE `data_alteracoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `diploma`
--
ALTER TABLE `diploma`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de tabela `estado`
--
ALTER TABLE `estado`
  MODIFY `est_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT de tabela `experiencia`
--
ALTER TABLE `experiencia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `login`
--
ALTER TABLE `login`
  MODIFY `lgn_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de tabela `login_perfil`
--
ALTER TABLE `login_perfil`
  MODIFY `lgp_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT de tabela `perfis_salvo`
--
ALTER TABLE `perfis_salvo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `premios`
--
ALTER TABLE `premios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `segmento`
--
ALTER TABLE `segmento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT de tabela `segmento_login`
--
ALTER TABLE `segmento_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT de tabela `segmento_tipo_coach`
--
ALTER TABLE `segmento_tipo_coach`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT de tabela `tipo_coach`
--
ALTER TABLE `tipo_coach`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
