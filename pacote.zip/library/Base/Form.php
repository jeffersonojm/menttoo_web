<?php

/**
 * Classe para tratamento de formulários
 */
class Base_Form
{
    /**
     * Prepara a sessão para popular o form a partir dos dados submetidos.
     * O método recebe o id do formulário a ser populado, o array com os dados
     * do post e um array com as variáveis a serem desconsideradas no populate,
     * como campos de senha, por exemplo, por questões de segurança.
     *
     * @static
     * @access public
     * @param string $formId
     * @param array $post
     * @param array $remove
     * @return void
     */
    static public function populate($formId, array $post, $remove=array())
    {

        if (!empty($post)) {

            $sForm     = new Zend_Session_Namespace('form-populate');
            $sForm->id = $formId;
            foreach ($post as $name => $value) {
                if (!in_array($name, $remove)) {
                    $sForm->campos[$name] = $value;
                }
            }

        }
    }
}
