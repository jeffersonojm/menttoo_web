<?php

class Base_Date
{
    const DATABASE_DATE     = 'yyyy-MM-dd';
    const DATABASE_TIME     = 'hh:mm:ss';
    const DATABASE_DATETIME = 'yyyy-MM-dd HH:mm:ss';
    const VIEW_DATE         = 'dd/MM/yyyy';
    const VIEW_TIME         = 'HH:mm:ss';
    const VIEW_DATETIME     = 'dd/MM/yyyy HH:mm:ss';
    const VIEW_DATE_MONTH   = 'dd/MM';
    const VIEW_DATE_WRITING = 'dd/MM/yyyy HH:mm';

    const VIEW_DATE_DAY = 'dd';
    const VIEW_DATE_MON = 'MM';
    const VIEW_DATE_YEA = 'yyyy';
    const VIEW_DATE_H = 'HH';
    const VIEW_DATE_M = 'mm';


    /**
     *
     */
    public static function getMonthWriting($month = '') {
        
        if( $month ){
            switch ( $month ) {
                case '01':
                    $month = 'janeiro';
                    break;
                case '02':
                    $month = 'fevereiro';
                    break;
                case '03':
                    $month = 'março';
                    break;
                case '04':
                    $month = 'abril';
                    break;
                case '05':
                    $month = 'maio';
                    break;
                case '06':
                    $month = 'junho';
                    break;
                case '07':
                    $month = 'julho';
                    break;
                case '08':
                    $month = 'agosto';
                    break;
                case '09':
                    $month = 'setembro';
                    break;
                case '10':
                    $month = 'outubro';
                    break;
                case '11':
                    $month = 'novembro';
                    break;
                case '12':
                    $month = 'dezembro';
                    break;                                        
            }
        }

        return $month;
    }

    /**
     *
     */
    public static function getDate() {
        $date = new Zend_Date();
        return $date->get(self::DATABASE_DATE);
    }

    /**
     *
     */
    public static function getTime() {
        $date = new Zend_Date();
        return $date->get(self::DATABASE_TIME);
    }

    /**
     *
     */
    public static function getDateTime() {
        $date = new Zend_Date();
        return $date->get(self::DATABASE_DATETIME);
    }

    /**
     *
     */
    public static function db2View($data, $format = null)
    {
        $date   = new Zend_Date($data);
        if ($format) {
            return $date->get($format);
        }
        return $date->get(self::VIEW_DATE);
    }

    /**
     *
     */
    public static function db2ViewMonth($data, $format = null)
    {
        $date   = new Zend_Date($data);
        if ($format) {
            return $date->get($format);
        }

        return $date->get(self::VIEW_DATE_MONTH);
    }
    /**
     *
     */
    public static function db2ViewWriting($data, $format = null)
    {
        $date   = new Zend_Date($data);

        $dia = $date->get(self::VIEW_DATE_DAY);
        $mes = $date->get(self::VIEW_DATE_MON);
        $ano = $date->get(self::VIEW_DATE_YEA);
        $h = $date->get(self::VIEW_DATE_H);
        $m = $date->get(self::VIEW_DATE_M);

        // return $dia . ' de ' . Base_Date::getMonthWriting($mes) . ' de ' . $ano . ' às ' . $h . 'h' . $m ;
        return $dia . '/' . $mes . '/' . $ano . ' às ' . $h . 'h' . $m ;
    }
    /**
     *
     */
    public static function db2ViewWritingNotYear($data, $format = null)
    {
        $date   = new Zend_Date($data);

        $dia = $date->get(self::VIEW_DATE_DAY);
        $mes = $date->get(self::VIEW_DATE_MON);
        $ano = $date->get(self::VIEW_DATE_YEA);
        $h = $date->get(self::VIEW_DATE_H);
        $m = $date->get(self::VIEW_DATE_M);

        // return $dia . ' de ' . Base_Date::getMonthWriting($mes) . ' de ' . $ano . ' às ' . $h . 'h' . $m ;
        return $dia . '/' . $mes . ' às ' . $h . 'h' . $m ;
    }
    /**
     *
     */
    public static function db2ViewWriting2($data, $format = null)
    {
        $date   = new Zend_Date($data);

        $dia = $date->get(self::VIEW_DATE_DAY);
        $mes = $date->get(self::VIEW_DATE_MON);
        $ano = $date->get(self::VIEW_DATE_YEA);

        // return $dia . ' de ' . Base_Date::getMonthWriting($mes) . ' de ' . $ano;
        return $dia . '/' . $mes . '/' . $ano;
    }    
    /**
     *
     */
    public static function db2Time($dateTime, $format = null)
    {
        $date = new Zend_Date($dateTime);
        if ($format) {
            return $date->get($format);
        }
        return $date->get(self::VIEW_TIME);
    }

    /**
     *
     */
    public static function view2Db($data)
    {
        $date = new Zend_Date($data);
        return $date->get(self::DATABASE_DATE);
    }

    /**
     *
     */
    public static function view2DbDateTime($data)
    {
        $date = new Zend_Date($data);
        return $date->get(self::VIEW_DATETIME);
    }
    /**
     *
     */
    public static function view3Db($data)
    {
        $date = new Zend_Date($data);
        return $date->get(self::DATABASE_DATETIME);
    }

    /**
     *
     */
    public static function dataMaior($data1, $data2)
    {
        $date1 = new Zend_Date($data1);
        $date2 = new Zend_Date($data2);
        if ($date1->isLater($date2)) {
            return true;
        }
        return false;
    }

    /**
     *
     */
    public static function dataMaiorOuIgual($data1, $data2)
    {
        $date1   = new Zend_Date($data1);
        $date2   = new Zend_Date($data2);
        if ($date1->isLater($date2) || $date1->equals($date2)) {
            return true;
        }
        return false;
    }
     /**
     * @fixme coloquei esse método pois o de cima tava dando pala. Por ex: 01/10/2012 ficando assim 2012-01-10
     */
    static public function _date2Db($date)
    {
        if($date){
            $date = implode("-",array_reverse(explode("/",$date)));
        }
        return $date ? $date : null;
    }



    /**
     * @fixme coloquei esse método pois o de cima tava dando pala
     */
    static public function _db2Date($date)
    {
        if($date){
            //$date = implode("/",array_reverse(explode("-",$date)));
            return date('d/m/Y', strtotime($date));
        }
        //return $date ? $date : null;
    }
}
