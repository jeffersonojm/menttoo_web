<?php

class Base_Db_Table extends Base_Db_Table_Abstract
{
    /**
     * @return void
     */
    protected function _setupDatabaseAdapter()
    {
        $this->_setAdapter(Zend_Registry::get('multidb')->getDb('base'));
    }
}
