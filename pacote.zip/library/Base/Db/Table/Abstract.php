<?php
/*
 * locness/anup
 *
 * @link https://svn.locness.com.br/svn/anup/trunk for the canonical source repository
 * @version 1.0.0
 */

/**
 * {@inheritdoc}
 */
class Base_Db_Table_Abstract extends Zend_Db_Table_Abstract
{

    const NAO = 0;
    const SIM = 1;

    static public function getSimNao()
    {
        return array(self::NAO => 'Não',
                     self::SIM => 'Sim');
    }

    /**
     * Recupera todos os registros
     * @return Zend_Db_Table_Rowset
     */
    public function recuperarTodos($order = null)
    {
        return $this->fetchAll(null, $order);
    }

    /**
     * Retorna um array para montagem de combos (<select>)
     * a partir da chave primária e de outro campo informado
     * por parâmetro.
     * @access public
     * @param string $option
     * @return array
     */
    public function comboSelect($option, array $defaultValue=array())
    {
        $primaryKey      = $this->getPrimaryKeyName();
        $select          = $this->select()
                                ->from($this, array('value'  => $primaryKey,
                                                    'option' => $option))
                                ->order($option);
        $rowset          = $this->fetchAll($select);
        $comboSelect     = array();
        if (is_array($defaultValue) && !empty($defaultValue)) {
            foreach ($defaultValue as $key=>$value) {
                $comboSelect[$key] = $value;
            }
        } else {
            $comboSelect[''] = 'Selecione';
        }
        foreach ($rowset as $row) {
            $comboSelect[$row->value] = $row->option;
        }
        return $comboSelect;
    }


    public function comboSelectAtivo($option, array $defaultValue=array(),$where = '')
    {
        $primaryKey      = $this->getPrimaryKeyName();
        $select          = $this->select()
                                ->from($this, array('value'  => $primaryKey,
                                                    'option' => $option));

                        if(!is_array($where) && $where){
                            $select->where($where . "<> ?","R");    
                        }else if( is_array($where) && !empty($where) ){
                            foreach ($where as $condicion=>$value) {
                                $select->where($condicion,$value);
                            }
                        } 
                        
                        $select->order($option);
        $rowset         = $this->fetchAll($select);
        $comboSelect    = array();
        if (is_array($defaultValue) && !empty($defaultValue)) {
            foreach ($defaultValue as $key=>$value) {
                $comboSelect[$key] = $value;
            }
        } else {
            $comboSelect[''] = 'Selecione';
        }
        foreach ($rowset as $row) {
            $comboSelect[$row->value] = $row->option;
        }
        return $comboSelect;
    }

    /**
     * Retorna o nome da chave primária da tabela
     * @access protected
     * @return string
     */
    protected function getPrimaryKeyName()
    {
        if (isset($this->_primary) && $this->_primary) {
            if (is_array($this->_primary)) {
                if (isset($this->_primary[0]) && !is_null($this->_primary[0])) {
                    return $this->_primary[0];
                } else {
                    return $this->_primary[1];
                }
            } else {
                return $this->_primary;
            }
        } else {
            $primary = $this->info('primary');
            return $primary[1];
        }
    }

    /**
     * Persiste os dados do form
     * @access public
     * @param array $post
     * @return integer
     * @throws Livraria_Exception
     */
    public function salvar(array $post)
    {
        try {
            $post = $this->filtrar($post);
            $this->validarCampos($post);
            $this->validarNegocio($post);
            $post = $this->prepararDados($post);

            if (isset($post[$this->getPrimaryKeyName()]) && $post[$this->getPrimaryKeyName()]) {
                $id = $post[$this->getPrimaryKeyName()];
            } elseif (isset($post['id']) && $post['id']) {
                $id = $post[$this->getPrimaryKeyName()] = $post['id'];
                unset($post['id']);
            } else {
                $id = null;
            }

            if ($id) {
                $row = $this->find($id)->current();
                $row->setFromArray($post);
                $id  = $row->save();
            } else {
                unset($post[$this->getPrimaryKeyName()]);
                $row = $this->createRow($post);
                $id  = $row->save();
            }

            $this->posSalvar($id, $post);
            return $id;

        } catch (Zend_Db_Exception $e) {
            $eAnup = new Base_Exception();
            $eAnup->setErrorMessage($eAnup->getDbExceptionMessage($e));
            throw $eAnup;
        }
    }

    /**
     * Método chamado depois de salvar
     * @param $id
     * @param $post
     */
    protected function posSalvar($id, $post)
    {
    }

    /**
     * Filtra os dados
     * @access protected
     * @param array $dados
     * @param array $filtros
     * @return array
     */
    protected function filtrar(array $dados, array $filtros = array())
    {
        $filter = new Zend_Filter_Input($filtros, array(), $dados);
        return $filter->getUnescaped();
    }

    /**
     * Valida os dados dos campos de formulário
     * @access protected
     * @param array $post
     * @param array $validadores
     * @return void
     * @throws Livraria_Exception
     */
    protected function validarCampos(array $post, array $validadores = array())
    {
        $validate  = new Zend_Filter_Input(array(), $validadores, $post);
        $eAnup = new Base_Exception();
        if (!$validate->isValid()) {
            foreach ($validate->getMessages() as $campo => $mensagens) {
                foreach($mensagens as $tipo => $mensagem) {
                    $eAnup->addErrorField($campo, addslashes($mensagem));
                }
            }
        }
        if ($eAnup->hasErrors()) {
            $eAnup->setErrorMessage(Base_Message::ERROR_CAMPOS_FORM);
            throw $eAnup;
        }
    }

    /**
     * Valida as regras de negócio
     * @access protected
     * @param array $dados
     * @return void
     */
    protected function validarNegocio(array $dados){}

    /**
     * Prepara o array de dados para ser persistido
     * @access protected
     * @param array $dados
     * @param array $mapeamento
     * @return array
     */
    protected function prepararDados(array $dados, array $mapeamento = array())
    {
        if (!empty($dados)) {
            $arrDados = array();
            foreach ($dados as $key => $value) {
                if (!empty($mapeamento)) {
                    if (isset($mapeamento[$key])) {
                        $key = $mapeamento[$key];
                    }
                }

                if ('' === trim($value)) {
                    $arrDados[$key] = null;
                } else {
                    $arrDados[$key] = $value;
                }
            }
            $dados = $arrDados;
        }
        return $dados;
    }

    /**
     * Realiza a exclusão de um registro
     * @access public
     * @param integer $id
     * @return void
     * @throws Livraria_Exception
     */
    public function excluir($id)
    {
        try {
            $filtros     = array('id'       => array('StringTrim',
                                               'StripTags',
                                               'Digits'),
                                 'status'   => array('StringTrim',
                                                    'StripTags'));
            $dados       = array();
            $dados['id'] = $id;
            $dados['status'] = 'R';
            // $dados       = $this->filtrar($dados, $filtros);

            // echo "<pre>";
            // print_r($dados);
            // exit();
            $this->salvar($dados);
            // $this->delete($this->getPrimaryKeyName() . ' = '. $id);
        } catch (Zend_Db_Exception $e) {
            $eAnup = new Base_Exception();
            $eAnup->setErrorMessage($eAnup->getDbExceptionMessage($e));
            throw $eAnup;
        }
    }


    /**
     * Realiza a exclusão de um registro fisico
     * @access public
     * @param integer $id
     * @return void
     * @throws Livraria_Exception
     */
    public function exclusao_fisica($id)
    {
        try {
            $filtros     = array('id'       => array('StringTrim',
                                               'StripTags',
                                               'Digits'),
                                 'status'   => array('StringTrim',
                                                    'StripTags'));
            
            $this->delete($this->getPrimaryKeyName() . ' = '. $id);
        } catch (Zend_Db_Exception $e) {
            $eAnup = new Base_Exception();
            $eAnup->setErrorMessage($eAnup->getDbExceptionMessage($e));
            throw $eAnup;
        }
    }


    public function moneyFormat($valor, $casasDecimais = 2)
    {
        if ($valor){
            $valor = str_replace(',', '.', $valor);
            return number_format($valor, $casasDecimais, ',', '.');
        }
        return null;
    }

    /**
     * Recupera todos os dados baseado nos dados informados na pesquisa.
     *
     * @param $params array
     * @return Zend_Db_Table_Rowset
     */
    public function pesquisar($params = array())
    {
        $select = $this->getSelectPesquisar($params);

        return $this->fetchAll($select);
    }

    /**
     *
     */
    public function getSelectPesquisar($params = array())
    {
        $params     = $this->filtrar($params);
        $columns    = $this->createRow(array())->toArray();
        $select     = $this->select()
            ->setIntegrityCheck(false)
            ->from(array('t' => $this->_name));

        foreach ($columns as $column => $null) {
            if (isset($params[$column]) && $params[$column]) {
                $select->where("LOWER({$column}) LIKE ?", strtolower("%{$params[$column]}%"));
            }
        }

        return $select;
    }
}
