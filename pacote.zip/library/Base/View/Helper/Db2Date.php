<?php

class Base_View_Helper_Db2Date extends Zend_View_Helper_Abstract
{
    public function db2Date($date, $format = 'dd/MM/yyyy')
    {
        return Base_Date::db2View($date, $format);
    }
}
