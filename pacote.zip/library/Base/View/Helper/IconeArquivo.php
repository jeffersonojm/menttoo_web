<?php

class Base_View_Helper_IconeArquivo extends Zend_View_Helper_Abstract
{
    public function iconeArquivo($extensaoArquivo)
    {
        $icone = '';
        switch (strtolower(trim($extensaoArquivo))) {
            case 'avi':
                $icone = 'icone_avi.png';
                break;
            case 'doc':
                $icone = 'icone_doc.png';
                break;
            case 'docx':
                $icone = 'icone_doc.png';
                break;
            case 'jpg':
                $icone = 'icone_jpg.png';
                break;
            case 'mp3':
                $icone = 'icone_mp3.png';
                break;
            case 'pdf':
                $icone = 'icone_pdf.png';
                break;
            case 'ppt':
                $icone = 'icone_ppt.png';
                break;
            case 'pptx':
                $icone = 'icone_ppt.png';
                break;
            case 'xls':
                $icone = 'icone_xls.png';
                break;
            case 'xlsx':
                $icone = 'icone_xls.png';
                break;
            case 'zip':
                $icone = 'icone_zip.png';
                break;
        }
        return $icone;
    }
}
