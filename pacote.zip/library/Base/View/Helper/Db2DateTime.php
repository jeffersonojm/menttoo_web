<?php

class Base_View_Helper_Db2DateTime extends Zend_View_Helper_Abstract
{
    public function db2DateTime($date)
    {
        return Base_Date::db2View($date, 'dd/MM/yyyy') . ' às ' .
               Base_Date::db2View($date, 'HH:mm');
    }
}
