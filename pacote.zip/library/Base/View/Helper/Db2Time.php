<?php

class Base_View_Helper_Db2Time extends Zend_View_Helper_Abstract
{
    public function db2Time($dateTime, $format = null)
    {
        return Base_Date::db2Time($dateTime, $format);
    }
  
}
