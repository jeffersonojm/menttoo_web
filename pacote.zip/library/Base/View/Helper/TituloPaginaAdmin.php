<?php

class Base_View_Helper_TituloPaginaAdmin extends Zend_View_Helper_Abstract
{
    public function tituloPaginaAdmin($titulo, $subtitulo=null)
    {
        if ($subtitulo) {
            $subtitulo = '<i class="icon-double-angle-right"></i>' . $subtitulo;
        } else {
            $subtitulo = '';
        }
        $str = '<script type="text/javascript">' .
               'tituloPaginaAdmin = "' . $titulo . '";' .
               'subtituloPaginaAdmin = \'' . $subtitulo . '\';' .
               '</script>';
        return $str;
    }
}
