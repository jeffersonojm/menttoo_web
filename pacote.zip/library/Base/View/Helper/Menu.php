<?php

class Base_View_Helper_Menu extends Zend_View_Helper_Abstract
{
	public function menu($secao){
		$mMenu = new Application_Model_DbTable_Base_Menu();

        $aMenu = $mMenu->listar(null, $secao)->toArray();

          for ($i=0;$i<count($aMenu);$i++) {
              $aMenu[$i]['filhos'] = $mMenu->listar($aMenu[$i]['id_menu'], $secao)->toArray();
              for($j=0;$j<count($aMenu[$i]['filhos']);$j++){
                  $aMenu[$i]['filhos'][$j]['filhos'] = array();
                  $menuPai = $aMenu[$i]['filhos'][$j]['id_menu'];
                   $aMenu[$i]['filhos'][$j]['filhos'] = $mMenu->listar($menuPai, $secao)->toArray();
               }
           }
           
          
          return $aMenu;
	}
	
	
}
