<?php

class Base_View_Helper_TelefoneFormat extends Zend_View_Helper_Abstract
{
    public function telefoneFormat($telefone)
    {
        $filter      = new Zend_Filter_Digits();
        $telefone    = $filter->filter($telefone);
        $str         = '';
        $tamTelefone = strlen($telefone);
        //
        if ($tamTelefone == 10) {
            $str .= '(' . substr($telefone, 0, 2) . ')' .
                    substr($telefone, 2, 4) .
                    '-' .
                    substr($telefone, 6);
        } elseif ($tamTelefone == 8) {
            $str .= substr($telefone, 0, 4) .
                   '-' .
                   substr($telefone, 4);
        }
        //
        if ($str != '') {
            return $str;
        }
        return $telefone;
    }
}
