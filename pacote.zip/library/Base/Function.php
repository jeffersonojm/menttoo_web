<?php

class Base_Function
{
    /**
     * Retorna o endereço IP do usuário
     * @author Felipe Carvalho (felipe.oliveirac@gmail.com)
     * @since 11/11/2013
     * @access public
     * @return string
     */
    public static function getIp()
    {
         $ipAddress = '';
         if ($_SERVER['HTTP_CLIENT_IP']) {
             $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
         } else if($_SERVER['HTTP_X_FORWARDED_FOR']) {
             $ipAddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
         } else if($_SERVER['HTTP_X_FORWARDED']) {
             $ipAddress = $_SERVER['HTTP_X_FORWARDED'];
         } else if($_SERVER['HTTP_FORWARDED_FOR']) {
             $ipAddress = $_SERVER['HTTP_FORWARDED_FOR'];
         } else if($_SERVER['HTTP_FORWARDED']) {
             $ipAddress = $_SERVER['HTTP_FORWARDED'];
         } else if($_SERVER['REMOTE_ADDR']) {
             $ipAddress = $_SERVER['REMOTE_ADDR'];
         } else {
             $ipAddress = 'UNKNOWN';
         }
         return $ipAddress;
    }

    /**
     * Retorna as informações referentes ao navegador do usuário
     * @author Felipe Carvalho (felipe.oliveirac@gmail.com)
     * @since 11/11/2013
     * @access public
     * @return string
     */
    public static function getBrowserInfo()
    {
        $userAgent = new Zend_Http_UserAgent();
        $device    = $userAgent->getDevice();
        return $device->getUserAgent();
    }

    /**
     * Retorna a URL que o usuário está acessando
     * @author Felipe Carvalho (felipe.oliveirac@gmail.com)
     * @since 11/11/2013
     * @access public
     * @return string
     */
    public static function getUri()
    {
        $userAgent = new Zend_Http_UserAgent();
        return $userAgent->getServerValue('request_uri');
    }

    /**
     * Retorna o idioma do Browser do usuário de acesso
     * @author Felipe Carvalho (felipe.oliveirac@gmail.com)
     * @since 11/11/2013
     * @access public
     * @return string
     */
    public static function getBrowserLanguage()
    {
        $locale = new Zend_Locale(Zend_Locale::BROWSER);
        return $locale->getLanguage() . '_' . $locale->getRegion();
    }

    /**
     *
     */
    public static function validaExtensaoArquivo($extensaoArquivo)
    {
        $arrExtensoesPermitidas = array('gif', 'png', 'jpg', 'jpeg', 'doc', 'docx',
                                        'xls', 'xslx', 'ppt', 'pptx', 'zip', 'mp3');
        $extensaoArquivo        = strtolower(trim($extensaoArquivo));
        return in_array($extensaoArquivo, $arrExtensoesPermitidas);
    }

    /**
     *
     */
    static public function slugify($str)
    {
        setlocale(LC_ALL, 'en_US.utf8');
        $str = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
        $str = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $str);
        $str = strtolower(trim($str, '-'));
        $str = preg_replace("/[\/_|+ -]+/", '-', $str);
        return $str;
    }

    static public function randomStr($len = 8)
    {
        return substr(
            str_shuffle(
                '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
            ),
            0,
            $len
        );
    }
}
