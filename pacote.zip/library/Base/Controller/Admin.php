<?php

abstract class Base_Controller_Admin extends Base_Controller_Action
{
    public function init()
    {
        parent::init();
        $this->_helper->layout->setLayout('admin');
        $identity = Zend_Auth::getInstance()->getIdentity();
        if (isset($identity)) {
            $this->view->idUsuario   = $identity->lgn_id;
            $this->view->nomeUsuario   = $identity->lgn_nome;
            $this->view->perfilUsuario = $identity->lgn_lgp_id;
        }
    }
}
