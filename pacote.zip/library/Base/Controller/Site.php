<?php

abstract class Base_Controller_Site extends Base_Controller_Action
{
    public function init()
    {
        parent::init();
        $this->_helper->layout->setLayout('site');
        // $identity = Zend_Auth::getInstance()->getIdentity();
        // echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
        // print_r($identity);
        // echo "<br> ====================================== <br>";
        if (isset($identity)) {
            $this->view->idUsuario   = $identity->lgn_id;
            $this->view->nomeUsuario   = $identity->lgn_nome;
            $this->view->perfilUsuario = $identity->lgn_lgp_id;
        }
    }
}
