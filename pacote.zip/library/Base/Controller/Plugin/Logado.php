<?php

class Base_Controller_Plugin_Logado extends Zend_Controller_Plugin_Abstract
{
    public function preDispatch(Zend_Controller_Request_Abstract $request)
    {

        $module     = $request->getParam('module');
        $controller = $request->getParam('controller');
        $action     = $request->getParam('action');

        // inicia a sessão
        // Zend_Session::start();
        // recupera as configurações da sessão no arquivo "session.ini"
        //$configIni = new Zend_Config_Ini(APPLICATION_PATH . '/configs/session.ini', APPLICATION_ENV);
        // se o usuário logado ficou inativo por mais tempo que determinado
        // pela diretiva "gc_maxlifetime", é deslogado e redirecionado para o login.


        // echo "logado a: " . $_SESSION['last_activity'];
        // echo "<br />";
        // echo "tempo atual: " . time();
        // echo "<br />";
        // echo time() - $_SESSION['last_activity'];
        // echo "<br />";
        // echo $configIni->gc_maxlifetime;
        // echo "<br />";
        // // exit();

        // if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $configIni->gc_maxlifetime) && Zend_Auth::getInstance()->getIdentity() != null) {

        //      $uploaddir = PUBLIC_PATH . '/data/session';
        //      $dir_contents = scandir($uploaddir);

        //      if(is_dir($uploaddir)) {
        //        foreach($dir_contents as $content) {
        //         if ( $content != "." and $content != ".." ) {
        //             unlink($uploaddir.'/'.$content);
        //             // echo $uploaddir.'/'.$content . "<br/>";
        //         }
        //        }
        //      }

        //     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
            
        //     if ( $module == 'site' ) {
        //         $redirector->gotoSimpleAndExit('sessao-expirada', 'index', 'site');
        //         exit();
        //     }else{
        //         $redirector->gotoSimpleAndExit('sessao-expirada', 'index', 'admin');
        //         exit();
        //     }
        // }
        // // seta a hora da última ação do usuário
        // $_SESSION['last_activity'] = time();
    }
}
