<?php
class Base_Controller_Plugin_Acl extends Zend_Controller_Plugin_Abstract
{
    public function preDispatch (Zend_Controller_Request_Abstract $request)
    {
        $front = Zend_Controller_Front::getInstance();
        $module     = $request->getParam('module');
        $controller = $request->getParam('controller');
        $action     = $request->getParam('action');

        if ($front->getDispatcher()->isDispatchable($request)) {
            $acl = Zend_Registry::get('acl');
            if (isset($acl)) {
                //echo " ACL ";
                
                $resource   = "{$module}-{$controller}";
                  if( Zend_Auth::getInstance()->hasIdentity() ) {  
                    $identity   = Zend_Auth::getInstance()->getIdentity();
                  }

                // $identity   = Zend_Auth::getInstance()->getIdentity();
                // echo "<pre>";
                // print_r($identity);


                $role       = 'usuario';
                if (isset($identity)) {
                    // echo " logado ";
                    // exit();
                    if (isset($identity->lgn_lgp_id)) {
                        switch ($identity->lgn_lgp_id) {
                            case Application_Model_DbTable_Base_LoginPerfil::MASTER:
                                $role = 'master';
                                break;
                            case Application_Model_DbTable_Base_LoginPerfil::ADMINISTRADOR:
                                $role = 'administrador';
                                break;
                            case Application_Model_DbTable_Base_LoginPerfil::PARTICIPANTE:
                                $role = 'participante';
                                break;                                                                
                            default:
                                $role = 'usuario';
                                // $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                                // $redirector->gotoSimpleAndExit('acesso', 'error', 'site');
                        }
                    } elseif (isset($identity->perfil)) {
                        switch ($identity->perfil) {
                            case Application_Model_DbTable_Base_UsuarioPerfil::PERFIL_USUARIO_COMUM:
                                $role = 'site-usuario-comum';
                                break;
                            case Application_Model_DbTable_Base_UsuarioPerfil::PERFIL_MANTENEDOR:
                                $role = 'site-mantenedor';
                                break;
                            default:
                                $role = 'usuario';
                                // $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                                // $redirector->gotoSimpleAndExit('acesso', 'error', 'site');
                        }
                    }
                }else{

                    // echo "Não logado";
                    // exit();

                    if ( $module == 'site' ) {

                        if( 
                            ( $controller != 'index' and $action != 'index' ) and
                            ( $controller != 'index' and $action != 'sem-acesso' ) and
                            ( $controller != 'index' and $action != 'index2' ) and
                            ( $controller != 'index' and $action != 'login' ) and
                            ( $controller != 'login' and $action != 'index' ) and
                            ( $controller != 'login' and $action != 'autenticar' ) and
                            ( $controller != 'usuario`' and $action != 'cadastro-coach' ) and
                            ( $controller != 'usuario`' and $action != 'cadastro-coach-salvar' ) and
                            ( $controller != 'usuario`' and $action != 'cadastro-coach-convite' ) and
                            ( $controller != 'usuario`' and $action != 'cadastro-coach-convite-salvar' ) and
                            ( $controller != 'usuario`' and $action != 'esqueci-senha' ) and
                            ( $controller != 'usuario`' and $action != 'esqueci-senha-enviar' ) and
                            ( $controller != 'usuario`' and $action != 'esqueci-senha-positivo' ) and
                            ( $controller != 'usuario`' and $action != 'esqueci-senha-negativo' ) and

                            ( $controller != 'usuario`' and $action != 'cadastro-coachee' ) and
                            ( $controller != 'usuario`' and $action != 'cadastro-coachee-salvar' ) and
                            ( $controller != 'usuario`' and $action != 'cadastro-coachee-validar' ) and
                            ( $controller != 'usuario`' and $action != 'cadastro-coachee-validar-enviar' ) and
                            ( $controller != 'usuario`' and $action != 'cadastro-coachee-validar-salvar' ) and

                            ( $controller != 'contato`' and $action != 'index' ) and
                            ( $controller != 'contato`' and $action != 'enviar' ) and

                            ( $controller != 'error`' and $action != 'error' ) and
                            ( $controller != 'error`' and $action != 'get-log' ) and
                            ( $controller != 'error`' and $action != 'acesso' ) and
                            ( $controller != 'error`' and $action != 'not-found' ) and
                            ( $controller != 'usuario`' and $action != 'cadastro-coach-salvar' ) and
                            ( $controller != 'usuario`' and $action != 'gerar-convite-coach' )                            
                        ){

                            $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                            $redirector->gotoSimpleAndExit('index', 'index', 'site');
                      
                        }
                        
                    }

                    if ( $module == 'admin' ) {
                        // echo "Sem permissão para o admin";
                        // exit();                        
                    }

                   
                }


                if ($acl->has($resource)) {

                    if (!$acl->isAllowed($role, $resource, $action)) {

                        switch ($module) {
                            case 'admin':
                                if (isset($identity)) {
                                    $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                                    $redirector->gotoSimpleAndExit('acesso', 'index', 'admin');
                                }else{ // Usuário não logado
                                    $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                                    $redirector->gotoSimpleAndExit('index', 'index', 'admin');                               
                                }
                                break;
                            case 'loja':
                                $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                                $redirector->gotoSimpleAndExit('acesso', 'error', 'loja');
                                break;
                            default:
                                echo " 03 ";
                                exit();

                                $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                                $redirector->gotoSimpleAndExit('index', 'index', 'site');
                        }
                    }
                }
            }
        } else {

            switch ($module) {
                case 'admin':
                    $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                    $redirector->gotoSimpleAndExit('acesso', 'index', 'admin');
                    break;
                case 'loja':
                    $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                    $redirector->gotoSimpleAndExit('acesso', 'error', 'loja');
                    break;
                default:
                    $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
                    $redirector->gotoSimpleAndExit('acesso', 'error', 'site');
            }
        }
    }
}





// class Base_Controller_Plugin_Acl extends Zend_Controller_Plugin_Abstract
// {
//     public function preDispatch (Zend_Controller_Request_Abstract $request)
//     {
//         $front = Zend_Controller_Front::getInstance();
//         $module     = $request->getParam('module');
//         $controller = $request->getParam('controller');
//         $action     = $request->getParam('action');

//         if ($front->getDispatcher()->isDispatchable($request)) {
//             $acl = Zend_Registry::get('acl');
//             if (isset($acl)) {
//                 $resource   = "{$module}-{$controller}";
//                 $identity   = Zend_Auth::getInstance()->getIdentity();
//                 $role       = 'usuario';
//                 if (isset($identity)) {

//                     if (isset($identity->lgn_lgp_id)) {
//                         switch ($identity->lgn_lgp_id) {
//                             case Application_Model_DbTable_Base_LoginPerfil::MASTER:
//                                 $role = 'master';
//                                 break;
//                             case Application_Model_DbTable_Base_LoginPerfil::ADMINISTRADOR:
//                                 $role = 'administrador';
//                                 break;
//                             case Application_Model_DbTable_Base_LoginPerfil::PARTICIPANTE:
//                                 $role = 'cliente';
//                                 break;                                                                
//                             default:
//                                 $role = 'usuario';
//                                 // $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                 // $redirector->gotoSimpleAndExit('acesso', 'error', 'site');
//                         }
//                     } elseif (isset($identity->perfil)) {
//                         switch ($identity->perfil) {
//                             case Application_Model_DbTable_Base_UsuarioPerfil::PERFIL_USUARIO_COMUM:
//                                 $role = 'site-usuario-comum';
//                                 break;
//                             case Application_Model_DbTable_Base_UsuarioPerfil::PERFIL_MANTENEDOR:
//                                 $role = 'site-mantenedor';
//                                 break;
//                             default:
//                                 $role = 'usuario';
//                                 // $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                 // $redirector->gotoSimpleAndExit('acesso', 'error', 'site');
//                         }
//                     }
//                 }else{


//                 if ($acl->has($resource)) {
//                     if (!$acl->isAllowed($role, $resource, $action)) {

//                         switch ($module) {
//                             case 'admin':
//                                 if (isset($identity)) {
//                                     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                     $redirector->gotoSimpleAndExit('acesso', 'index', 'admin');
//                                 }else{ // Usuário não logado
//                                     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                     $redirector->gotoSimpleAndExit('index', 'index', 'admin');                               
//                                 }
//                                 break;
//                             case 'loja':
//                                 $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                 $redirector->gotoSimpleAndExit('acesso', 'error', 'loja');
//                                 break;
//                             default:
//                                 $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                 $redirector->gotoSimpleAndExit('acesso', 'error', 'site');
//                         }
//                     }
//                 }

//                     // echo $module;
                    
//                     // if ( $module == 'site' ) {
//                     //     // if( 
//                     //     //     ( $controller != 'index' and $action != 'index' ) and
//                     //     //     ( $controller != 'index' and $action != 'login' ) and
//                     //     //     ( $controller != 'login' and $action != 'index' ) and
//                     //     //     ( $controller != 'login' and $action != 'autenticar' ) and
//                     //     //     ( $controller != 'usuario`' and $action != 'cadastro-coach' ) and
//                     //     //     ( $controller != 'usuario`' and $action != 'cadastro-coach-salvar' ) and
//                     //     //     ( $controller != 'usuario`' and $action != 'cadastro-coach-convite' ) and
//                     //     //     ( $controller != 'usuario`' and $action != 'cadastro-coach-convite-salvar' ) and
//                     //     //     ( $controller != 'usuario`' and $action != 'esqueci-senha' ) and
//                     //     //     ( $controller != 'usuario`' and $action != 'esqueci-senha-enviar' ) and
//                     //     //     ( $controller != 'usuario`' and $action != 'esqueci-senha-positivo' ) and
//                     //     //     ( $controller != 'usuario`' and $action != 'esqueci-senha-negativo' ) and

//                     //     //     ( $controller != 'usuario`' and $action != 'cadastro-coachee' ) and
//                     //     //     ( $controller != 'usuario`' and $action != 'cadastro-coach-salvar' )                            
//                     //     // ){
//                     //     //     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                     //     //     $redirector->gotoSimpleAndExit('index', 'index', 'site');
//                     //     // }
                        
//                     // }else if ( $module == 'admin' ) {
//                     //     if( 
//                     //         ( $controller != 'index' and $action != 'index' ) and
//                     //         ( $controller != 'index' and $action != 'login' )
//                     //     ){
//                     //         // $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                     //         // $redirector->gotoSimpleAndExit('index', 'index', 'admin');
//                     //     }

//                     // }else{
//                     //     // $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                     //     // $redirector->gotoSimpleAndExit('index', 'index', 'site');
//                     // }

//                     // exit();

                    
                    
//                     // if( $controller != "index"){
//                     //     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                     //     $redirector->gotoSimpleAndExit('index', 'index', 'admin');
//                     // }else if( $action!="index" and $action!="login"){
//                     //     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                     //     $redirector->gotoSimpleAndExit('index', 'index', 'admin');
//                     // }
//                 }


//                 if ($acl->has($resource)) {
//                     if (!$acl->isAllowed($role, $resource, $action)) {
//                         echo ">>>>>>>>> 0 " . $module;
//                         exit();
//                         switch ($module) {
//                             case 'admin':
                                
//                                 if (isset($identity)) {
//                                     echo ">>>>>>>>> 1";
//                                     exit();
//                                     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                     $redirector->gotoSimpleAndExit('acesso', 'index', 'admin');
//                                 }else{ // Usuário não logado
//                                     echo ">>>>>>>>> 2";
//                                     exit();
//                                     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                     $redirector->gotoSimpleAndExit('index', 'index', 'admin');                               
//                                 }
//                                 break;
//                             case 'loja':
//                                 $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                 $redirector->gotoSimpleAndExit('acesso', 'error', 'loja');
//                                 break;
//                             default:
//                                 $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                                 $redirector->gotoSimpleAndExit('acesso', 'error', 'site');
//                         }
//                     }
//                 }
//             }
//         } else {

//             switch ($module) {
//                 case 'admin':
//                     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                     $redirector->gotoSimpleAndExit('acesso', 'index', 'admin');
//                     break;
//                 case 'loja':
//                     $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                     $redirector->gotoSimpleAndExit('acesso', 'error', 'loja');
//                     break;
//                 default:
//                     // $redirector = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
//                     // $redirector->gotoSimpleAndExit('acesso', 'error', 'site');
//             }
//         }
//     }
// }
