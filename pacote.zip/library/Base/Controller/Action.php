<?php

class Base_Controller_Action extends Zend_Controller_Action
{
    public function init()
    {        
        $this->_initView();
    }

    protected function _initView()
    {
        // Verifica se foi feira uma requisição "ajax" e se for desabilita o layout
        if($this->getRequest()->isXmlHttpRequest()) {
            $this->_helper->layout()->disableLayout();
        }
    }

    public function preDispatch()
    {
        // mensagens de alerta
        $messages                 = array();
        $messages['errorTitle']   = $this->_helper->FlashMessenger->setNamespace('errorTitle')->getMessages();
        $messages['errorText']    = $this->_helper->FlashMessenger->setNamespace('errorText')->getMessages();
        $messages['successTitle'] = $this->_helper->FlashMessenger->setNamespace('successTitle')->getMessages();
        $messages['successText']  = $this->_helper->FlashMessenger->setNamespace('successText')->getMessages();
        $messages['infoTitle']    = $this->_helper->FlashMessenger->setNamespace('infoTitle')->getMessages();
        $messages['infoText']     = $this->_helper->FlashMessenger->setNamespace('infoText')->getMessages();
        $this->view->messages     = $messages;

        if (!isset($_SESSION)) {
           Zend_Session::start();
        }

        // populate form
        if (Zend_Session::namespaceIsset('form-populate')) {
            $sForm              = Zend_Session::namespaceGet('form-populate');
            $this->view->formId = $sForm['id'];
            $this->view->form   = $sForm['campos'];
            Zend_Session::namespaceUnset('form-populate');
        }
        // form id dos campos de erro
        if (Zend_Session::namespaceIsset('errorFieldsFormId')) {
            $this->view->errorFieldsFormId = Zend_Session::namespaceGet('errorFieldsFormId');
            Zend_Session::namespaceUnset('errorFieldsFormId');
        }
        // campos de erro
        if (Zend_Session::namespaceIsset('errorFields')) {
            $this->view->errorFields = Zend_Session::namespaceGet('errorFields');
            Zend_Session::namespaceUnset('errorFields');
        }
    }

    /**
     * Helper method to redirect to a specific action or controller from a
     * specific module, via a specified route(or not) with specified parameters
     *
     * @param string $controller / $url which contains http in its composition
     * @param string $action
     * @param string $module
     * @param array  $params
     * @param string $route
     * @param boolean $reset
     */
    public function redirect($controller='index', $action='index', $module='site', $params=array(), $route=null, $reset=true)
    {

        $this->_redirect = $this->_helper->getHelper('Redirector');

        $current_controller = $this->_getParam('controller');
        $current_action     = $this->_getParam('action');
        $current_module     = $this->_getParam('module');

        if ($current_controller == $controller &&
            $current_action == $action &&
            $current_module == $module)
        {
            return TRUE;
        }

        if (strstr($controller, 'http')) {
            return $this->_redirect($controller, array('code' => 301));
        }

        if ($route !== null) {
            $params = array_merge(array('action'     => $action,
                                        'controller' => $controller,
                                        'module'     => null), $params);
            return $this->_redirect->setCode(301)
                                   ->setExit(true)
                                   ->gotoRoute($params, $route, $reset);
        }

        return $this->_redirect->setCode(301)
                               ->setExit(true)
                               ->gotoSimpleAndExit($action,
                                                   $controller,
                                                   $module,
                                                   $params);
    }

    /**
     * Seta as mensagens de erro do sistema.
     * @param string $title
     * @param array $arrText
     * @return void
     */
    public function setErrorMessage($title, array $arrText)
    {
        $this->_helper->FlashMessenger->setNamespace('errorTitle')->addMessage($title);
        foreach ($arrText as $text) {
            $this->_helper->FlashMessenger->setNamespace('errorText')->addMessage($text);
        }
    }

    /**
     * Seta as mensagens de sucesso do sistema.
     * @param string $title
     * @param array $arrText
     * @return void
     */
    public function setSuccessMessage($title, array $arrText)
    {
        $this->_helper->FlashMessenger->setNamespace('successTitle')->addMessage($title);
        foreach ($arrText as $text) {
            $this->_helper->FlashMessenger->setNamespace('successText')->addMessage($text);
        }
    }

    /**
     * Seta as mensagens de informação do sistema.
     * @param string $title
     * @param array $arrText
     * @return void
     */
    public function setInfoMessage($title, array $arrText)
    {
        $this->_helper->FlashMessenger->setNamespace('infoTitle')->addMessage($title);
        foreach ($arrText as $text) {
            $this->_helper->FlashMessenger->setNamespace('infoText')->addMessage($text);
        }
    }
}
