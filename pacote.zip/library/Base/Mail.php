<?php

class Base_Mail
{
    /**
     *
     */
    public static function mail($email, $subject, $body, $from = 'Campanhas', $fromEmail = 'atendimento@inmarketing.net.br')

    {
        try {

                $config = array('auth' => 'login', 
                                    'username' => 'atendimento@inmarketing.net.br', 
                                    'password' => 'Gwb9etA323', 
                                    'port' => 587); 

                $transport = new Zend_Mail_Transport_Smtp('smtp.inmarketing.net.br', $config); 

                $mensagemEmail = $body; 

                $mail = new Zend_Mail('UTF-8'); 
                $mail->setBodyHtml($mensagemEmail); 
                $mail->setFrom('atendimento@inmarketing.net.br', $from); 
                // $mail->addBcc('pedrohenrique@santafeideias.com.br');
                $mail->addTo($email); 
                // $mail->addTo("fabiano@menttoo.com"); 
                // $mail->addTo("jeffersonojm@gmail.com"); 
                $mail->setSubject($subject); 
                $mail->send($transport); 

        } catch(Zend_Mail_Exception $e) {
            $eAnup = new Base_Exception();
            $eAnup->setErrorMessage($eAnup->getMailExceptionMessage($e));
            throw $eAnup;
        }
    }
}


