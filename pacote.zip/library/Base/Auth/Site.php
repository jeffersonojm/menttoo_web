<?php

/**
 * {@inheritdoc}
 */
class Base_Auth_Site extends Zend_Auth
{
    /**
     * Singleton pattern implementation makes "new" unavailable
     *
     * @return void
     */
    protected function __construct()
    {
        $this->setStorage(new Zend_Auth_Storage_Session('Base_Auth_Site'));
    }
}
