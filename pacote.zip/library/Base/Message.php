<?php

/**
 * Classe para unificação das mensagens do sistema
 */
class Base_Message
{
    /**
     * Mensagens de erro gerais
     */
    const ERROR_FORM                            = 'Ocorreu um erro ao submeter o formulário!';
    const ERROR_AUTENTICACAO                    = 'O email/senha informados estão incorretos ou o usuário está inativo ou removido.';
    const ERROR_USUARIO_INATIVO                 = 'Sua conta se encontra inativa. Verifique seu email para ativação.';
    const ERROR_CAMPOS_FORM                     = 'Favor preencher todos os campos';
    const ERROR_EXCLUSAO                        = 'Ocorreu um erro ao realizar a exclusão!';
    const ERROR_VIOLACAO_INT_CONSTRAINT         = 'Violação de integridade referencial.';
    const ERROR_ENVIO_EMAIL                     = 'Ocorreu um erro ao enviar o email.';
    const ERROR_SESSAO_EXPIRADA                 = 'Sua sessão expirou, acesse novamente.';
    const ERROR_ACESSO_PAGINA                   = 'Ocorreu um erro ao acessar a página.';
    /**
     * Mensagens de erro gerais dos campos de formulário
     */
    const ERROR_FIELD_CAMPO_OBRIGATORIO         = 'Campo obrigatório';
    const ERROR_FIELD_EMAIL_INVALIDO            = 'Email com formato inválido';
    const ERROR_FIELD_CPF_INVALIDO              = 'CPF com formato inválido';
    const ERROR_FIELD_CNPJ_INVALIDO             = 'CNPJ com formato inválido';
    const ERROR_FIELD_NOME_EXISTENTE            = 'Já existe um registro com este nome';
    /**
     * Mensagens de sucesso gerais
     */
    const SUCCESS_LOGOUT                        = 'Logout realizado com sucesso!';
    const SUCCESS_USUARIO_SAIU                  = 'Seu usuário saiu do sistema.';
    const SUCCESS_FORM_SUCESSO                  = 'Processo realizado com sucesso!';
    /**
     * Mensagens de info gerais
     */
    const PROCESS_SUCCESS                       = 'Processo realizando com sucesso!';
    /**
     * Prepara um array JS com as mensagens do sistema
     * @static
     * @access public
     * @return string
     */
    static public function jsMessages()
    {
        $js = 'var messages = new Array();' . "\n\t\t" .
              'messages["ERROR_FORM"]                    = "' . self::ERROR_FORM . '";' . "\n\t\t" .
              'messages["ERROR_AUTENTICACAO"]            = "' . self::ERROR_AUTENTICACAO . '";' . "\n\t\t" .
              'messages["ERROR_USUARIO_INATIVO"]         = "' . self::ERROR_USUARIO_INATIVO . '";' . "\n\t\t" .
              'messages["ERROR_CAMPOS_FORM"]             = "' . self::ERROR_CAMPOS_FORM . '";' . "\n\t\t" .
              'messages["ERROR_EXCLUSAO"]                = "' . self::ERROR_EXCLUSAO . '";' . "\n\t\t" .
              'messages["ERROR_VIOLACAO_INT_CONSTRAINT"] = "' . self::ERROR_VIOLACAO_INT_CONSTRAINT . '";' . "\n\t\t" .
              'messages["ERROR_ENVIO_EMAIL"]             = "' . self::ERROR_ENVIO_EMAIL . '";' . "\n\t\t" .
              'messages["ERROR_FIELD_CAMPO_OBRIGATORIO"] = "' . self::ERROR_FIELD_CAMPO_OBRIGATORIO . '";' . "\n\t\t" .
              'messages["ERROR_FIELD_EMAIL_INVALIDO"]    = "' . self::ERROR_FIELD_EMAIL_INVALIDO . '";' . "\n\t\t" .
              'messages["ERROR_FIELD_CPF_INVALIDO"]      = "' . self::ERROR_FIELD_CPF_INVALIDO . '";' . "\n\t\t" .
              'messages["ERROR_FIELD_CNPJ_INVALIDO"]     = "' . self::ERROR_FIELD_CNPJ_INVALIDO . '";' . "\n\t\t" .
              'messages["ERROR_FIELD_NOME_EXISTENTE"]    = "' . self::ERROR_FIELD_NOME_EXISTENTE . '";' . "\n\t\t" .
              'messages["SUCCESS_LOGOUT"]                = "' . self::SUCCESS_LOGOUT . '";' . "\n\t\t" .
              'messages["SUCCESS_USUARIO_SAIU"]          = "' . self::SUCCESS_USUARIO_SAIU . '";' . "\n\t\t" .
              'messages["SUCCESS_FORM_SUCESSO"]          = "' . self::SUCCESS_FORM_SUCESSO . '";' . "\n";
        return $js;
    }
}
