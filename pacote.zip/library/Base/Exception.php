<?php

/**
 * Classe para tratamento das exceções do sistema
 */
class Base_Exception extends Zend_Exception
{
    /**
     * @var boolean
     */
    protected $hasErrors = false;

    /**
     * @var string
     */
    protected $errorMessage = '';

    /**
     *
     */
    public static function throwError($message)
    {
        $self = new static();
        $self->setErrorMessage($message);
        throw $self;
    }

    /**
     * Seta a mensagem de erro
     * @param string $message
     * @return void
     */
    public function setErrorMessage($message)
    {
        if (!$this->hasErrors) {
            $this->hasErrors = true;
        }
        $this->errorMessage = $message;
    }

    /**
     * Retorna a mensagem de erro
     * @return string
     */
    public function getErrorMessage()
    {
        return $this->errorMessage;
    }

    /**
     * Adiciona um campo com erro e sua mensagem de alerta
     * @param string $field
     * @param string $message
     * @return void
     */
    public function addErrorField($field, $message='')
    {
        if (!$this->hasErrors) {
            $this->hasErrors = true;
        }
        $session = new Zend_Session_Namespace('errorFields');
        $session->$field = $message;
    }

    /**
     *
     */
    public function setErrorFieldsFormId($formId)
    {
        $session = new Zend_Session_Namespace('errorFieldsFormId');
        $session->form = $formId;
    }

    /**
     * Retorna se existe(m) erro(s)
     * @return boolean
     */
    public function hasErrors()
    {
        return $this->hasErrors;
    }

    /**
     * Retorna uma mensagem padrão à partir do código
     * de erro da exceção de banco
     * @param Zend_Db_Exception $e
     * @return string
     */
    public function getDbExceptionMessage(Zend_Db_Exception $e)
    {
        $msg = '';
        switch ($e->getCode()) {
            //case '23000':
                //$msg = Base_Message::ERROR_VIOLACAO_INT_CONSTRAINT;
                //$msg = 'Este registro está sendo utilizado em outra funcionalidade do site.';
                //break;
            default:
                $msg = $e->getMessage();
        }
        return $msg;
    }

    /**
     * Retorna uma mensagem padrão à partir do código
     * de erro da exceção de mail
     * @param Zend_Mail_Exception $e
     * @return string
     */
    public function getMailExceptionMessage(Zend_Mail_Exception $e)
    {
        $msg = '';
        switch ($e->getCode()) {
            default:
                $msg = Base_Message::ERROR_ENVIO_EMAIL;
        }
        return $msg;
    }
}
